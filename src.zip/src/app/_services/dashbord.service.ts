import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class DashbordService {

  constructor(private http: HttpClient) { }

  // getAlldashbordcount() {

  //     var currentUser = localStorage.getItem('User Type');
 
  //     return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcounts')
  //   }

  getAllcountspackges() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountspackges/' + userId)
  }

  getAllcountsdomainRequest() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountsdomainRequest/' + userId)
  }

  getAllcountscompanies() { 
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountscompanies/' + userId)
  }

  getAllcountsResellers() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountsResellers/' + userId)
  }

  getAllcountsUpdates() {
    var userId = localStorage.getItem('userId');
   
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountsUpdates/' + userId)
  }

  getAllcountsProducts() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountsProducts/' + userId)
  }

  getAllcountsSubscriber() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/dashboard/getAllcountsSubscriber/' + userId)
  }


}
