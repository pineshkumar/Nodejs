import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class SettingService {
  constructor(private http: HttpClient) { }


  getAllUsage() {

    return this.http.get<any>(appConfig.apiUrl + '/settings/finikartusage/getAllUsage')
    
  }

 
  deleteusage(id,name) {
    var userId=localStorage.getItem('userId');

 
    return this.http.delete<any>(appConfig.apiUrl + '/settings/finikartusage/deleteusage/' + id + '/' + userId + '/' + name)
  }
 
 
  updatetoggle(usagedata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/settings/finikartusage/updatetoggle/', { 'status': usagedata, 'id': id })
  }
  getUsagebyId(UsageId) {
    return this.http.get<any>(appConfig.apiUrl + '/settings/finikartusage/getUsagebyId/' + UsageId)
  }

  updateusage(usagedata) {
    return this.http.post<any>(appConfig.apiUrl + '/settings/finikartusage/updateusage/', usagedata)
  }
}