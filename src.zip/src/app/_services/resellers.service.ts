import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class ResellersService {
  constructor(private http: HttpClient) { }

  addresellers(resellersdata) {

    return this.http.post<any>(appConfig.apiUrl + '/resellers/addresellers', resellersdata);
  }

  getAllresellers() {
    return this.http.get<any>(appConfig.apiUrl + '/resellers/getAllresellers')
  }

  getresellersbyId(resellersId) {
    return this.http.get<any>(appConfig.apiUrl + '/resellers/getresellersbyId/' + resellersId)
  }

  updateresellers(resellersdata) {
    return this.http.post<any>(appConfig.apiUrl + '/resellers/updateresellers', resellersdata)
  }

  updatetoggle(resellersdata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/resellers/updatetoggle/', { 'status': resellersdata, 'id': id })
  }

  deleteresellers(resellersId, name) {
    var userId = localStorage.getItem('userId');
    return this.http.delete<any>(appConfig.apiUrl + '/resellers/deleteresellers/' + resellersId + '/' + userId + '/' + name)
  }




}