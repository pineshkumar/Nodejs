import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class CustompageService {

  constructor(private http: HttpClient) { }


  addcustompage(custompagedata) {
    return this.http.post<any>(appConfig.apiUrl + '/custompage/addcustompage', custompagedata);
  }

  getAllcustompage() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/custompage/getAllcustompage/' + userId)
  }

  getcustompagebyId(custompageId) {
    return this.http.get<any>(appConfig.apiUrl + '/custompage/getcustompagebyId/' + custompageId)
  }

  updatecustompage(custompagedata) {
    return this.http.post<any>(appConfig.apiUrl + '/custompage/updatecustompage', custompagedata)
  }

  updatetoggle(custompagedata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/custompage/updatetoggle/', { 'Status': custompagedata, 'id': id })
  }


  deletecustompage(custompageId, name) {
    var userId = localStorage.getItem('userId');
    return this.http.delete<any>(appConfig.apiUrl + '/custompage/deletecustompage/' + custompageId + '/' + userId + '/' + name)
  }

}
