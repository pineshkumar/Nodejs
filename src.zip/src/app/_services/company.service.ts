import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';
const HttpUploadOptions = {
  headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}

@Injectable()
export class CompanyService {
  constructor(private http: HttpClient) { }

  //for connection field from package table
  getAllPackages() {
    return this.http.get<any>(appConfig.apiUrl + '/companies/getAllPackages')
  }


  //for companies
  addcompany(companydata) {

    return this.http.post<any>(appConfig.apiUrl + '/companies/addcompany', companydata);
  }

  addproductcategories(productcategoriesdata) {
    return this.http.post<any>(appConfig.apiUrl + '/productcategories/addproductcategories', productcategoriesdata);
  }

  addproductgallery(Files, checkboxdata): Observable<any> {

    const formData: any = new FormData();
    const files: Array<File> = Files;


    for (let i = 0; i < Files.length; i++) {

      formData.append("uploads[]", files[i], files[i]['name']);
      formData.append("uploads[]", checkboxdata[i]);

    }

    return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', formData);



  }



  addagaingallery(productgallerydata) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/addagaingallery', productgallerydata);
  }


  getcurrencyname() {
    return this.http.get<any>(appConfig.apiUrl + '/currency/getcurrencyname')
  }

  // getproductname() {

  //   return this.http.get<any>(appConfig.apiUrl + '/productgallery/getproductname')
  // }


  filtercategory(categoryid) {

    return this.http.get<any>(appConfig.apiUrl + '/productgallery/filtercategory/' + categoryid)
  }


  getAllcompany() {
    return this.http.get<any>(appConfig.apiUrl + '/companies/getAllcompany')
  }

  getAllproductcategories() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/productcategories/getAllproductcategories/' + userId)
  }
  getproductcategories() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/productgallery/getproductcategories/' + userId)
  }
  getAllproductgallery() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/productgallery/getAllproductgallery/' + userId);
  }

  getcompanybyId(companyId) {
    return this.http.get<any>(appConfig.apiUrl + '/companies/getcompanybyId/' + companyId)
  }

  getproductcategoriesbyId(productcategoriesId) {

    return this.http.get<any>(appConfig.apiUrl + '/productcategories/getproductcategoriesbyId/' + productcategoriesId)
  }

  getproductgallerybyId(productgalleryId) {
    return this.http.get<any>(appConfig.apiUrl + '/productgallery/getproductgallerybyId/' + productgalleryId)
  }

  getthemebyID() {
    return this.http.get<any>(appConfig.apiUrl + '/companies/getthemebyID')
  }

  updatecompany(companydata) {

    return this.http.post<any>(appConfig.apiUrl + '/companies/updatecompany', companydata)
  }

  updateproductcategories(productcategoriesdata) {
    return this.http.post<any>(appConfig.apiUrl + '/productcategories/updateproductcategories', productcategoriesdata)
  }



  updateproductgallery(Files, checkboxdata): Observable<any> {

    const formData: any = new FormData();
    const files: Array<File> = Files;


    for (let i = 0; i < Files.length; i++) {

      formData.append("uploads[]", files[i], files[i]['name']);
      formData.append("uploads[]", checkboxdata[i]);
    }

    return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', formData);
  }

  updateagainproductgallery(productgallerydata) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/updateagainproductgallery', productgallerydata)
  }

  deletearray(productgalleryid, productgalleryimageid) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/deletearray/', { 'maindata': productgalleryid, 'imagedata': productgalleryimageid })
  }


  updatetoggle(companydata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/companies/updatetoggle/', { 'status': companydata, 'id': id })
  }

  updatetoggleone(productcategoriesdata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/productcategories/updatetoggleone/', { 'status': productcategoriesdata, 'id': id })
  }


  onwebupdatetoggle(data, id) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/onwebupdatetoggle/', { 'onweb': data, 'id': id })
  }

  onAPPupdatetoggle(data, id) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/onAPPupdatetoggle/', { 'onapp': data, 'id': id })
  }
  Statusupdatetoggle(data, id) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/statusupdatetoggle/', { 'status': data, 'id': id })
  }

  deletecompany(companyId, name) {
    var userId = localStorage.getItem('userId');


    return this.http.delete<any>(appConfig.apiUrl + '/companies/deletecompany/' + companyId + '/' + userId + '/' + name)
  }

  deleteproductcategories(productcategoriesId, name) {
    var userId = localStorage.getItem('userId');
    return this.http.delete<any>(appConfig.apiUrl + '/productcategories/deleteproductcategories/' + productcategoriesId + '/' + userId + '/' + name)
  }

  deleteproductgallery(productgalleryId, name) {
    var userId = localStorage.getItem('userId');
    return this.http.delete<any>(appConfig.apiUrl + '/productgallery/deleteproductgallery/' + productgalleryId + '/' + userId + '/' + name)
  }


  productgalleryimagestatus(imageid, imagevalue, id) {

    return this.http.post<any>(appConfig.apiUrl + '/productgallery/productgalleryimagestatus/', { 'status': imagevalue, 'id': imageid, 'objid': id })
  }

}