import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { appConfig } from '../app.config';
const HttpUploadOptions = {
    headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}
@Injectable()
export class ThirdPartyIntergration {
    constructor(private http: HttpClient) { }

    submitFacebookdetails(facebookData, companyid) {
        return this.http.post<any>(appConfig.apiUrl + '/thirdpartyintergration/submitFacebookdetails/', { 'facebookData': facebookData, 'companyid': companyid });
    }

    getDomainAndEmail() {
        var userId = localStorage.getItem('userId');

        return this.http.get<any>(appConfig.apiUrl + '/thirdpartyintergration/getDomainAndEmail/' + userId)
    }

}