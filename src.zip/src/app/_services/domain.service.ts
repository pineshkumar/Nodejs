import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';
import { TestBed } from '@angular/core/testing';

@Injectable()
export class DomainService {
    constructor(private http: HttpClient) { }


    getAllcompany() {
      return this.http.get<any>(appConfig.apiUrl + '/domains/getAllcompany')
    }

    adddomainrequest(domaindata) {
        return this.http.post<any>(appConfig.apiUrl + '/domains/adddomainrequest', domaindata);
      }

      getAllDomainRequests() {
        return this.http.get<any>(appConfig.apiUrl + '/domains/getAllDomainRequests')
      }

      getDomainRequestsbyId(domainId) {
        return this.http.get<any>(appConfig.apiUrl + '/domains/getDomainRequestsbyId/' + domainId)
      }

      updateDomainRequests(domaindata) {
        return this.http.post<any>(appConfig.apiUrl + '/domains/updateDomainRequests', domaindata)
      }
      
      deleteDomainRequests(domainId,name) {
        var userId=localStorage.getItem('userId');
        return this.http.delete<any>(appConfig.apiUrl + '/domains/deleteDomainRequests/' + domainId + '/' + userId +'/'+ name)
      }

     




}