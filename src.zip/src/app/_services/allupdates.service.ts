import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class AllupdateService {

  constructor(private http: HttpClient) { }

  // addallupdates(Files,checkboxdata): Observable<any> {

  //   const formData: any = new FormData();
  //   const files: Array<File> = Files;


  //   for (let i = 0; i < Files.length; i++) {

  //     formData.append("uploads[]", files[i]);
  //     formData.append("uploads[]", checkboxdata[i]);
  //   }

  //    //return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', {'formData':formData,'checkboxdata':checkboxdata});
  //   return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', formData);
  // }

  addallupdates(Files, checkboxdata): Observable<any> {

    const formData: any = new FormData();
    const files: Array<File> = Files;

    console.log('files ' + files);
    for (let i = 0; i < Files.length; i++) {

      formData.append("uploads[]", files[i]);
      formData.append("uploads[]", checkboxdata[i]);
    }

    //return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', {'formData':formData,'checkboxdata':checkboxdata});
    return this.http.post<any>(appConfig.apiUrl + '/uploadcheckedfiles', formData);
  }

  addagainallupdates(allupdatedata) {

    return this.http.post<any>(appConfig.apiUrl + '/allupdates/addagainallupdates', allupdatedata);
  }


  getAllallupdates() {
    var userId = localStorage.getItem('userId');
    return this.http.get<any>(appConfig.apiUrl + '/allupdates/getAllallupdates/' + userId)
  }

  updatetoggle(allupdatedata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/allupdates/updatetoggle/', { 'onweb': allupdatedata, 'id': id })
  }

  updatetoggleagain(allupdatedata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/allupdates/updatetoggleagain/', { 'onapp': allupdatedata, 'id': id })
  }

  deleteallupdates(allupdatesId, name) {
    var userId = localStorage.getItem('userId');
    return this.http.delete<any>(appConfig.apiUrl + '/allupdates/deleteallupdates/' + allupdatesId + '/' + userId + '/' + name)
  }
}