﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class PackagesService {
  constructor(private http: HttpClient) { }


  addpackage(packagedata) {
    return this.http.post<any>(appConfig.apiUrl + '/packages/addpackage', packagedata);
  }

  getAllPackages() {
    return this.http.get<any>(appConfig.apiUrl + '/packages/getAllPackages')
  }

  getPackagebyId(packageId) {
    return this.http.get<any>(appConfig.apiUrl + '/packages/getPackagebyId/' + packageId)
  }

  updatepackage(packagedata) {
    return this.http.post<any>(appConfig.apiUrl + '/packages/updatepackage', packagedata)
  }

  updatetoggle(packagedata, id) {

    return this.http.post<any>(appConfig.apiUrl + '/packages/updatetoggle/', { 'status': packagedata, 'id': id })
  }

  deletePackage(packageId, name) {
    var userId = localStorage.getItem('userId');


    return this.http.delete<any>(appConfig.apiUrl + '/packages/deletepackage/' + packageId + '/' + userId + '/' + name)
  }

}