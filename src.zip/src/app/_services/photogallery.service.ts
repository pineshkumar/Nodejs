import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';
const HttpUploadOptions = {
  headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}

@Injectable()
export class PhotogalleryService {
  constructor(private http: HttpClient) { }


  // addphotogallery(photogallerydata) {

  //     return this.http.post<any>(appConfig.apiUrl + '/photogallery/addphotogallery', photogallerydata);
  //   }


  addphotogallery(Files, flagphoto = 0): Observable<any> {
  
    const formData: any = new FormData();
    const files: Array<File> = Files;


    for (let i = 0; i < Files.length; i++) {

      formData.append("uploads[]", files[i], files[i]['name']);
      formData.append("uploads[]", flagphoto);
    }


    return this.http.post<any>(appConfig.apiUrl + '/uploadfiles', formData);

  }


  addagainphotpgallery(photogallerydata) {

    return this.http.post<any>(appConfig.apiUrl + '/photogallery/addagainphotpgallery', photogallerydata);
  }

  getAllphotogallery() {
    var userId = localStorage.getItem('userId');

    return this.http.get<any>(appConfig.apiUrl + '/photogallery/getAllphotogallery/' + userId);
  }

  deletearray(photoid, photoimageid) {
    return this.http.post<any>(appConfig.apiUrl + '/photogallery/deletearray/', { 'maindata': photoid, 'imagedata': photoimageid })
  }

  checkboxbutton(checkboxmainid, checkboximageid) {

    return this.http.post<any>(appConfig.apiUrl + '/photogallery/checkboxbutton/', { 'mainid': checkboxmainid, 'imageid': checkboximageid })
  }



}