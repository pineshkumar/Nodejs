import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';
import { sortLinear } from '@swimlane/ngx-charts/release/utils';

const HttpUploadOptions = {
  headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}

@Injectable()
export class StoretimingService {
  constructor(private http: HttpClient) { }


  getMystoretiming(companyid) {

    return this.http.get<any>(appConfig.apiUrl + '/storetiming/getmystoretiming/' + companyid)
  }


  updatestoretime(storeTimingData) {
   
    return this.http.post<any>(appConfig.apiUrl + '/storetiming/updatestoretime/', storeTimingData)
  }

  getAllDatatiming() {
  
    var userId = localStorage.getItem('userId');
    
    return this.http.get<any>(appConfig.apiUrl + '/storetiming/getAllDatatiming/' + userId)
  }



}