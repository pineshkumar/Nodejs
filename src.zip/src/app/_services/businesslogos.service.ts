import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';
const HttpUploadOptions = {
  headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
}

@Injectable()
export class BusinesslogosService {
  constructor(private http: HttpClient) { }



  addbusinesslogo(Files, flagphoto = 1): Observable<any> {
      
    const formData: any = new FormData();
    const files: Array<File> = Files;

    // for (let i = 0; i < Files.length; i++) {
    formData.append("uploads[]", files, files['name']);
    formData.append("uploads[]", flagphoto);
    // }
    return this.http.post<any>(appConfig.apiUrl + '/uploadfiles', formData);
  }

  addagainbusinesslogo(logo) {
   
    return this.http.post<any>(appConfig.apiUrl + '/businesslogo/addagainbusinesslogo', logo);
  }

  getAllbusinesslogo(userId) {
    return this.http.get<any>(appConfig.apiUrl + '/businesslogo/getallbusinesslogo/' + userId);
  }



  addBenneragain(Files, flagphoto = 2): Observable<any> {

    const formData: any = new FormData();
    const files: Array<File> = Files;
    for (let i = 0; i < Files.length; i++) {

      formData.append("uploads[]", files[i], files[i]['name']);
      formData.append("uploads[]", flagphoto);
    }


    return this.http.post<any>(appConfig.apiUrl + '/uploadfiles', formData);

  }

  addBenerLogoMultiple(BennerData) {
  
    return this.http.post<any>(appConfig.apiUrl + '/businesslogo/addBenerLogoMultiple', BennerData);
  }

  deleteBannerarray(bennerId, bennerImageid) {
   
    return this.http.post<any>(appConfig.apiUrl + '/businesslogo/deleteBannerarray/', { 'maindata': bennerId, 'imagedata': bennerImageid })
  }
  

}