﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { appConfig } from '../app.config';

@Injectable()
export class AuthenticationService {
    constructor(private http: HttpClient) { }


    login(username: string, password: string) {

       
        return this.http.post<any>(appConfig.apiUrl + '/users/authenticate', { username: username.toLowerCase(), password: password })
            .map(user => {

                // login successful if there's a jwt token in the response
                if (user.string == 'You Cannot Logged In As Your Status Is Off!') {

                }
                else {
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    localStorage.setItem('userId', user._id);
                    localStorage.setItem('email', user.email);
                    localStorage.setItem('User Type', user.userType);
                    localStorage.setItem('username', user.username);
                    localStorage.setItem('token', user.token);
                }

                return user;
            });
    }
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        localStorage.removeItem('userId');
        localStorage.removeItem('email');
        localStorage.removeItem('User Type');
        localStorage.removeItem('username');
    }

    getprofileInfo(loginId) {
        return this.http.get<any>(appConfig.apiUrl + '/users/getprofileInfo/' + loginId)
    }

    updateprofile(profiledata) {
        return this.http.post<any>(appConfig.apiUrl + '/users/updateprofile', profiledata)
    }



}