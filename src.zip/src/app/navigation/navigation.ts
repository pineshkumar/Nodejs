import { FuseNavigation } from '@fuse/types';

export const navigation: FuseNavigation[] = [


    // {
    //     id: 'dashboard',
    //     title: 'Dashboards',
    //     url: '/dashboard',
    //     type: 'item',
    //     icon: 'dashboard'
    // },
    // {
    //     id: 'domainrequests',
    //     title: 'Domain Requests',
    //     url: '/domainrequests',
    //     type: 'item',
    //     icon: 'domain'
    // },
    // {
    //     id: 'packages',
    //     title: 'Packages',
    //     url: '/packages',
    //     type: 'item',
    //     icon: 'card_giftcard'
    // },
    // {
    //     id: 'companies',
    //     title: 'Companies',
    //     url: '/companies',
    //     type: 'item',
    //     icon: 'work'
    // },
    // {
    //     id: 'resellers',
    //     title: 'Resellers',
    //     url: '/resellers',
    //     type: 'item',
    //     icon: 'people'
    // },
	// {
    //     id: 'catalogue',
    //     title: 'Manage Catalogue',
    //     type: 'collapsable',
    //     icon: 'shopping_cart',
    //     children: [
    //         {
    //             id: 'productcategories',
    //             title: 'Product Categories',
    //             type: 'item',
    //             url: '/catalogue/productcategories',
    //         },
    //         {
    //             id: 'productgallery',
    //             title: 'Product Gallery',
    //             type: 'item',
    //             url: '/catalogue/productgallery',
    //         }
    //     ]
    // },
    // {
    //     id: 'webmanager',
    //     title: 'Manage Website',
    //     type: 'collapsable',
    //     icon: 'language',
    //     children: [
    //         {
    //             id: 'allupdates',
    //             title: 'All Updates',
    //             type: 'item',
    //             url: '/webmanager/allupdates',
    //         },
    //         {
    //             id: 'photogallery',
    //             title: 'Photo Gallery',
    //             type: 'item',
    //             url: '/webmanager/photogallery',
    //         },
    //         {
    //             id: 'custompages',
    //             title: 'Custom Pages',
    //             type: 'item',
    //             url: '/webmanager/custompage',
    //         },
    //         {
    //             id: 'siteappearance',
    //             title: 'Site Appearance',
    //             type: 'item',
    //             url: '/webmanager/siteappearance',
    //         },
    //         {
    //             id: 'domainandemail',
    //             title: 'Domain and Email',
    //             type: 'item',
    //             url: '/webmanager/domainandemail',
    //         }
    //     ]
    // },
    // {
    //     id: 'thirdpartyintergration',
    //     title: 'Third Party Intergration',
    //     url: '/thirdpartyintergration',
    //     type: 'item',
    //     icon: 'insert_link'
    // },
    // {
    //     id: 'Sitehealth',
    //     title: 'Site Health',
    //     type: 'item',
    //     url: '/sitehealth',
    //     icon: 'favorite'
    // },

    // {
    //     id: 'settings',
    //     title: 'Settings',
    //     type: 'collapsable',
    //     icon: 'settings_applications',
    //     children: [
    //         {
    //             id: 'Helpandsupport',
    //             title: 'Help and Support',
    //             type: 'item',
    //             url: '/settings/helpandsupport',
    //         },
    //         {
    //             id: 'Finikartusage',
    //             title: 'FiniKart Usage',
    //             type: 'item',
    //             url: '/settings/finikartusage',
    //         }
            
            
    //     ]
    // },
   
    // {
    //     id       : 'applications',
    //     title    : 'Applications',
    //     translate: 'NAV.APPLICATIONS',
    //     type     : 'group',
    //     children : [
    //         {
    //             id       : 'sample',
    //             title    : 'Sample',
    //             translate: 'NAV.SAMPLE.TITLE',
    //             type     : 'item',
    //             icon     : 'email',
    //             url      : '/sample',
    //             badge    : {
    //                 title    : '25',
    //                 translate: 'NAV.SAMPLE.BADGE',
    //                 bg       : '#F44336',
    //                 fg       : '#FFFFFF'
    //             }
    //         }
    //     ]
    // }
];
