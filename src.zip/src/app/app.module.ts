import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import 'hammerjs';

import { FuseModule } from '@fuse/fuse.module';
import { FuseSharedModule } from '@fuse/shared.module';
import { FuseProgressBarModule, FuseSidebarModule, FuseThemeOptionsModule } from '@fuse/components';

import { fuseConfig } from 'app/fuse-config';
import { AuthGuard } from './_guards/index';
import { JwtInterceptorProvider, ErrorInterceptorProvider } from './_helpers/index';

import { AuthenticationService } from './_services/index';
import { PackagesService } from './_services/index';
import { ResellersService } from './_services/index';
import { CompanyService } from './_services/index';
import { DomainService } from './_services/index';
import { CustompageService } from './_services/index';
import { AllupdateService } from './_services/index';
import { PhotogalleryService } from './_services/index';
import { ChangePasswordService } from './_services/index';
import { SiteAppearanceService } from './_services/index';
import { SettingService } from './_services/index' ;
import { DashbordService } from './_services/index';
import { StoretimingService} from  './_services/index'
import { BusinesslogosService } from './_services/index'
import { ThirdPartyIntergration } from './_services/index'

import { AppComponent } from 'app/app.component';
import { LayoutModule } from 'app/layout/layout.module';
import { SampleModule } from 'app/main/sample/sample.module';
import { Login2Module } from 'app/main/login/login.module';
import { DashboardModule } from 'app/main/dashboard/dashboard.module';
import { DomainrequestsModule } from 'app/main/domainrequests/domainrequests.module';
import { PackagesModule } from 'app/main/packages/packages.module';
import { CompaniesModule } from 'app/main/companies/companies.module';
import { ResellersModule } from 'app/main/resellers/resellers.module';
import { ProductCategoriesModule } from 'app/main/productcategories/productcategories.module';
import { SiteAppearanceModule } from 'app/main/siteappearance/siteappearance.module';
import { DomainandemailModule } from 'app/main/domainandemail/domainandemail.module';
import { PhotoGalleryModule } from 'app/main/photogallery/photogallery.module';
import { CustomPageModule } from 'app/main/custompage/custompage.module';
import { HelpandsupportModule } from 'app/main/settings/helpandsupport/helpandsupport.module';
import { FinikartusageModule } from 'app/main/settings/finikartusage/finikartusage.module';
import { AllUpdatesModule } from 'app/main/allupdates/allupdates.module';
import { ThirdPartyModule } from 'app/main/thirdpartyintergration/thirdpartyintergration.module';
import { SitehealthModule } from 'app/main/sitehealth/sitehealth.module';
import { ProfileModule } from 'app/main/profile/profile.module';
import { ForgotPassword2Module } from 'app/main/forgotpassword/forgot-password-2.module';
import { StoreTimingModule } from 'app/main/storetiming/storetiming.module';
import { PasswordModule } from 'app/main/password/password.module';
import { ResetPasswordModule } from 'app/main/resetpassword/resetpassword.module';
import { BusinessLogoModule } from 'app/main/businesslogo/businesslogo.module';
import { from } from 'rxjs';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BnNgIdleService } from 'bn-ng-idle'; // import bn-ng-idle service


const appRoutes: Routes = [
    {
        path      : '**',
        redirectTo: 'login'
    }
];


@NgModule({
    declarations: [
        AppComponent
    ],
    imports     : [
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        RouterModule.forRoot(appRoutes, {useHash: true,onSameUrlNavigation: 'reload'}),

        TranslateModule.forRoot(),

        // Material moment date module
        MatMomentDateModule,

        // Material
        MatButtonModule,
        MatIconModule,

        // Fuse modules
        FuseModule.forRoot(fuseConfig),
        FuseProgressBarModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseThemeOptionsModule,

        // App modules
        LayoutModule,
        SampleModule,
        Login2Module,
        DashboardModule,
        DomainrequestsModule,
        PackagesModule,
        CompaniesModule,
        ResellersModule,
        ProductCategoriesModule,
        SiteAppearanceModule,
        DomainandemailModule,
        PhotoGalleryModule,
        HelpandsupportModule,
        FinikartusageModule,
        SitehealthModule,
        CustomPageModule,
        AllUpdatesModule,
        ThirdPartyModule,
		ProfileModule,
        ForgotPassword2Module,
        StoreTimingModule,
        PasswordModule,
        ResetPasswordModule,
        AngularFontAwesomeModule,
        BusinessLogoModule
    ],
    providers: [
        AuthGuard,
        AuthenticationService,
        PackagesService,
        ResellersService,
        CompanyService,
        DomainService,
        CustompageService,
        AllupdateService,
        PhotogalleryService,
        ChangePasswordService,
        SiteAppearanceService,
        JwtInterceptorProvider,
        ErrorInterceptorProvider,
        SettingService,                                                                                                
        DashbordService,
        BnNgIdleService,
        StoretimingService,
        BusinesslogosService,
        ThirdPartyIntergration
    ],
    bootstrap   : [
        AppComponent
    ]
})
export class AppModule
{
}
    