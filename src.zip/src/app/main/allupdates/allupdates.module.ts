import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule, MatPaginatorModule, MatDialogModule, MatCheckboxModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';

import { AllUpdatesComponent } from './allupdates.component';
import { AddUpdateComponent } from './addupdate/addupdate.component';
import { deleteallupdatesPopupComponent } from './allupdates.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';

const routes = [
    {
        path: 'webmanager/allupdates',
        component: AllUpdatesComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'webmanager/addupdate',
        component: AddUpdateComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'allupdates',
        component: deleteallupdatesPopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        AllUpdatesComponent,
        AddUpdateComponent,
        deleteallupdatesPopupComponent],
    imports: [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        MatCheckboxModule,
        NgxLoadingModule.forRoot({}),
        AutofocusModule
    ],
    exports: [
        AllUpdatesComponent,
        AddUpdateComponent,
        deleteallupdatesPopupComponent
    ]
})

export class AllUpdatesModule {
}
