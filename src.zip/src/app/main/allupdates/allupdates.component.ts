import { Component, OnInit, Inject, ViewChild, ViewEncapsulation, } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { AllupdateService } from '../../_services/index';

export interface PeriodicElement {

  message: string;
  onweb: string;
  onapp: string;
  timer: string;
  action: string;

}


@Component({
  selector: 'app-allupdates',
  templateUrl: './allupdates.component.html',
  styleUrls: ['./allupdates.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class AllUpdatesComponent implements OnInit {
  form: FormGroup;
  allupdates: any[];
  displayedColumns: string[] = ['image', 'message', 'onweb', 'onapp', 'timer', 'action'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog, private AllupdateService: AllupdateService) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.AllupdateService.getAllallupdates()
      .subscribe(
        data => {

          this.allupdates = data;

          const updates = data;
          const allupdates = [];
          updates.forEach(element => {
            allupdates.push(element);

          });

          this.dataSource = new MatTableDataSource(allupdates);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }

  statustoggal(status, id) {
  
    this.AllupdateService.updatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  statustoggalagain(status, id) {
   
    this.AllupdateService.updatetoggleagain(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  deleteallupdates(id, name) {
    let dialogRef = this.dialog.open(deleteallupdatesPopupComponent, {
      data: {
        allupdatesId: id,
        message: name
      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.AllupdateService.getAllallupdates()
        .subscribe(
          data => {
            this.allupdates = data;
            const updates = data;
            const allupdates = [];
            updates.forEach(element => {

              allupdates.push(element);

            });
            this.dataSource = new MatTableDataSource(allupdates);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }

}


@Component({
  selector: 'deleteallupdates-popup',
  templateUrl: './deleteallupdatespopup.html'
})
export class deleteallupdatesPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private AllupdateService: AllupdateService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) { }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/webmanager/allupdates';
  }

  delete(id, name) {
    this.AllupdateService.deleteallupdates(id, name)
      .subscribe(
        data => {
          this.snackBar.open('Updates deleted successfully', '', {
            duration: 5000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
          });
          this.router.navigate([this.returnUrl]);
        },
        error => {
          console.log(error);
          // this.alertService.error(error);
        });

  }


}
export class DialogContentExampleDialog { }
