import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule,MatPaginatorModule,MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';


import { ResellersComponent } from './resellers.component';
import { AddResellersComponent } from './addresellers/addresellers.component';
import { UpdateResellersComponent } from './updateresellers/updateresellers.component';
import { deleteresellersPopupComponent } from './resellers.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';


const routes = [
    {
        path     : 'resellers',
        component: ResellersComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'resellers/addreseller',
        component: AddResellersComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'resellers/updatereseller/:id',
        component: UpdateResellersComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'resellers',
        component: deleteresellersPopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        ResellersComponent,
        AddResellersComponent,
        UpdateResellersComponent,
        deleteresellersPopupComponent    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        AutofocusModule,
        NgxLoadingModule.forRoot({})
    ],
    exports     : [
        ResellersComponent,
        AddResellersComponent,
        UpdateResellersComponent,
        deleteresellersPopupComponent
    ]
})

export class ResellersModule
{
}
