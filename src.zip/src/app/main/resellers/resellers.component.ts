import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { ResellersService } from '../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { MatPaginator, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';


export interface PeriodicElement {

  name: string;
  address: string;
  city: string;
  phone: number;
  email: string;
  username: string;
  accesscode: string;
  status: Boolean;
  dateadded: string;
  datemodified: string;
  action: string;
}



@Component({
  selector: 'app-resellers',
  templateUrl: './resellers.component.html',
  styleUrls: ['./resellers.component.scss'],
  animations: fuseAnimations
})


export class ResellersComponent implements OnInit {
  // displayedColumns: string[] = ['position', 'name', 'address', 'city', 'phone', 'email', 'username', 'accesscode', 'status', 'dateadded', 'datemodified', 'action'];
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  allresellers: any[];
  displayedColumns: string[] = ['name', 'address', 'city', 'phone', 'email', 'username', 'accesscode', 'status', 'dateadded', 'datemodified', 'action'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: any) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  constructor(public dialog: MatDialog, private ResellersService: ResellersService) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.ResellersService.getAllresellers()
      .subscribe(
        data => {
          this.allresellers = data;
          const resellers = data;
          const allresellers = [];
          resellers.forEach(element => {
            var date = new Date(element.dateadded);
            // element.dateadded = date.toUTCString();
            element.dateadded = date.toDateString();
          
            var date = new Date(element.datemodified);
            // element.datemodified = date.toUTCString();
            element.datemodified = date.toDateString();
           
            allresellers.push(element);

          });
          this.dataSource = new MatTableDataSource(allresellers);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }

  statustoggal(status, id) {
   
    this.ResellersService.updatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }


  deleteresellers(id, name) {
    let dialogRef = this.dialog.open(deleteresellersPopupComponent, {
      data: {
        resellersId: id,
        firstname: name
      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.ResellersService.getAllresellers()
        .subscribe(
          data => {
            this.allresellers = data;
            const resellers = data;
            const allresellers = [];
            resellers.forEach(element => {

              var date = new Date(element.dateadded);
              // element.dateadded = date.toUTCString();
              element.dateadded = date.toDateString();
              
              var date = new Date(element.datemodified);
              // element.datemodified = date.toUTCString();
              element.datemodified = date.toDateString();
            

              allresellers.push(element);

            });
            this.dataSource = new MatTableDataSource(allresellers);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }

}


@Component({
  selector: 'deleteresellers-popup',
  templateUrl: './deleteresellerspopup.html'
})
export class deleteresellersPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private ResellersService: ResellersService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {
   

  }
  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/resellers';
  }

  delete(id, name) {
    this.ResellersService.deleteresellers(id, name)
      .subscribe(
        data => {
          this.snackBar.open('Reseller deleted successfully', '', {
            duration: 5000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
          });
          this.router.navigate([this.returnUrl]);
        },
        error => {
          console.log(error);
          // this.alertService.error(error);
        });

  }


}

export class DialogContentExampleDialog { }
