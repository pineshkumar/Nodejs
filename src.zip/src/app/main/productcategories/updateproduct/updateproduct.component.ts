import { Component, OnDestroy, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularEditorConfig } from '@kolkov/angular-editor';

import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { CompanyService } from '../../../_services/index';
import { MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';
import { id } from '@swimlane/ngx-charts/release/utils';


@Component({
    selector: 'app-updateproduct',
    templateUrl: '../updateproduct/updateproduct.component.html',
    styleUrls: ['../updateproduct/updateproduct.component.scss'],
    animations: fuseAnimations
})
export class UpdateProductComponent implements OnInit, OnDestroy {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    form: FormGroup;
    htmlContent = '';

    fileSelected: File;
    productcategories: string[] = [''];
    returnUrl: string;
    prioritytype: number;
    urls = new Array<string>();
    filesToUpload: Array<File> = [];
    images: any;
    imageObgid: any;
    checkvideo: string;
    showinghiding: any;
    checkboxdata = new Array();
    show = false;
    currentclass: string = 'hidefield';
    currencies: any;
    requireshipping: any;



    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };

    editorConfig: AngularEditorConfig = {

        editable: true,
        spellcheck: true,
        height: '25rem',
        minHeight: '5rem',
        placeholder: 'Enter text here...',
        translate: 'no',
        uploadUrl: 'v1/images', // if needed
        customClasses: [ // optional
            {
                name: "quote",
                class: "quote",
            },
            {
                name: 'redText',
                class: 'redText'
            },
            {
                name: "titleText",
                class: "titleText",
                tag: "h1",
            },
        ]
    };


    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private CompanyService: CompanyService,
        public snackBar: MatSnackBar,
        private sanitizer: DomSanitizer
    ) {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }

    toggleTemplate(): void {
        if (this.loadingTemplate) {
            this.loadingTemplate = null;
        } else {
            this.loadingTemplate = this.customLoadingTemplate;
        }
    }

    public showAlert(): void {
        alert('ngx-loading rocks!');
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Reactive Form
        this.form = this._formBuilder.group({
            image: [''],
            youtube: [''],
            catName: ['', Validators.required],
            proName: ['', Validators.required],
            description: ['', Validators.required],
            currencyname: ['', Validators.required],
            productprice: ['', Validators.required],
            discountprice: [''],
            shippingcharge: [''],
            transactionprice: [''],
            netamount: ['', Validators.required],
            onlinelink: [''],
            priority: ['', Validators.required],
            onweb: true,
            onapp: true,
            productavailability: true,
            freeshipping: true,
            facebook: true,
            twitter: true,
            checkboxtoggle: false,
            userId: [localStorage.getItem('userId')],
        });
        this.route.params.subscribe(params => {
            this.CompanyService.getproductcategories()
                .subscribe(
                    data => {
                        this.productcategories = data;


                    },
                    error => {
                        console.log(error);

                    });

            this.CompanyService.getcurrencyname()
                .subscribe(
                    data => {
                        this.currencies = data;
                    },
                    error => {
                        console.log(error);

                    });

        });
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/catalogue/productgallery';

        this.route.params.subscribe(params => {
            this.CompanyService.getproductgallerybyId(params.id)
                .subscribe(
                    data => {
                     
                        this.images = data.image

                        this.imageObgid = data._id


                        this.prioritytype = +data.priority;
                        this.form = this._formBuilder.group({

                            image: [this.images],
                            youtube: [data.youtube],
                            catName: [data.catNameid, Validators.required],
                            proName: [data.proName, Validators.required],
                            description: [data.description, Validators.required],
                            currencyname: [data.currencynameid],
                            productprice: [data.productprice, Validators.required],
                            discountprice: [data.discountprice],
                            shippingcharge: [data.shippingcharge],
                            transactionprice: [data.transactionprice],
                            netamount: [data.netamount, Validators.required],
                            onlinelink: [data.onlinelink],
                            priority: [this.prioritytype, Validators.required],
                            onweb: [data.onweb],
                            onapp: [data.onapp],
                            productavailability: [data.productavailability],
                            freeshipping: [data.freeshipping],
                            facebook: [data.facebook],
                            twitter: [data.twitter],
                            checkboxtoggle: [data.checkboxtoggle],
                            userId: [localStorage.getItem('userId')],

                        });
                    },
                    error => {
                        console.log(error);

                    });

        });


    }

    fileChangeEvent(fileInput: any) {
        // console.log(fileInput.target.files);
        // if (fileInput.target.files && fileInput.target.files[0]) {
        //     var filesAmount = fileInput.target.files.length;
        //     for (let i = 0; i < filesAmount; i++) {
        //         var reader = new FileReader();
        //         reader.onload = (fileInput: any) => {
        //             this.urls.push(fileInput.target.result);
        //             this.checkboxdata.push(false)

        //         }
        //         reader.readAsDataURL(fileInput.target.files[i]);
        //         this.filesToUpload.push(fileInput.target.files[i]);
        //     }

        //     //this.filesToUpload=fileInput.target.files;
        //     // console.log(this.checkboxdata)
        // }

        var imagefiles = fileInput.target.files;

        if (fileInput.target.files && fileInput.target.files[0]) {
            var filesAmount = fileInput.target.files.length;


            for (let i = 0; i < filesAmount; i++) {
                var testreader = new FileReader();
                testreader.onload = (fileInput: any) => {

                    this.urls.push(fileInput.target.result);

                    this.checkboxdata.push(false);

                    this.filesToUpload.push(imagefiles[i]);

                }
                testreader.readAsDataURL(fileInput.target.files[i]);
            }
        }

    }
    close(urls, event, index, i) {

        urls.splice(i, 1);
        var temp = new Array<File>();
        for (var j = 0; j < this.filesToUpload.length; j++) {
            if (j != i) {
                temp.push(this.filesToUpload[j]);
            }
        }
        this.filesToUpload = temp;

    }

    delete(urls, event, index, i, _id) {
        this.route.params.subscribe(params => {
            //this.form.value._id = params.id;
            urls.splice(i, 1);
            this.CompanyService.deletearray(params.id, _id)
                .subscribe(
                    data => {
                    },
                    error => {
                    });
        })
    }

    checkboxclick($event, index, id) {



        this.checkboxdata.forEach((element, i) => {
            this.checkboxdata[i] = false;
        });

        this.checkboxdata[index] = $event.target.checked
        $('.image-list').on('change', function () {
            $('.image-list').not(this).prop('checked', false);
        });


        var imageid = id;
        var imagevalue = $event.target.checked
        var id = this.imageObgid
        this.CompanyService.productgalleryimagestatus(imageid, imagevalue, id)
            .subscribe(

                data => {

                    // this.snackBar.open('Product category deleted successfully', '', {
                    //     duration: 5000,
                    //     horizontalPosition: this.horizontalPosition,
                    //     verticalPosition: this.verticalPosition,
                    // });
                    //   this.router.navigate([this.returnUrl]);
                },
                error => {
                    console.log(error);
                    // this.alertService.error(error);
                });




    }

    clickVet($event: any) {
        //this.currentclass='test';
        let shippingtoggle = this.form.get("freeshipping");
        if (shippingtoggle.value == true) {
            this.currentclass = 'showfield';
        }
        else {
            this.currentclass = 'hidefield';
        }
        //console.log(test.value);

    }


    updateproductgallery() {
        this.loading = true;

        this.route.params.subscribe(params => {
            this.form.value._id = params.id;


            if ($("#one input:checkbox:checked").length == 0) {

                // console.log('true');
                // any one is checked
                // }
                // if(jQuery.inArray(true, this.checkboxdata) == -1  ) {
                this.loading = false;
                this.snackBar.open('Please check an image', '', {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });

            } else if (this.filesToUpload.length > 0) {


                this.CompanyService.updateproductgallery(this.filesToUpload, this.checkboxdata)
                    .subscribe(
                        data => {

                            this.loading = false;
                            this.form.value.imageuploaded = data

                            this.CompanyService.updateagainproductgallery(this.form.value)

                                .subscribe(
                                    data => {
                                        this.loading = false;
                                  
                                        if (data.string == 'Product Name is already exixt') {
                                            this.snackBar.open('Product Name is already exixt', '', {
                                                duration: 3000,
                                                horizontalPosition: this.horizontalPosition,
                                                verticalPosition: this.verticalPosition,
                                            });
                                        }else{
                                            this.snackBar.open('Product updated successfully', '', {
                                                duration: 3000,
                                                horizontalPosition: this.horizontalPosition,
                                                verticalPosition: this.verticalPosition,
                                            });

                                            this.router.navigate([this.returnUrl]);
                                        }


                                    },
                                    error => {
                                        console.log(error);
                                        this.loading = false;
                                      
                                        this.snackBar.open('Something went wrong', '', {
                                            duration: 3000,
                                            horizontalPosition: this.horizontalPosition,
                                            verticalPosition: this.verticalPosition,
                                        });
                                    });

                        });

            } else {
                this.CompanyService.updateagainproductgallery(this.form.value)

                    .subscribe(
                        data => {
                            this.loading = false;
                        
                            if (data.string == 'Product Name is already exixt') {
                                this.snackBar.open('Product Name is already exixt', '', {
                                    duration: 3000,
                                    horizontalPosition: this.horizontalPosition,
                                    verticalPosition: this.verticalPosition,
                                });
                            }else{
                                this.snackBar.open('Product updated  successfully', '', {
                                    duration: 3000,
                                    horizontalPosition: this.horizontalPosition,
                                    verticalPosition: this.verticalPosition,
    
                                });
                                this.router.navigate([this.returnUrl]);
                            }

                        },
                        error => {
                            console.log(error);
                            this.loading = false;
                        
                            this.snackBar.open('Something went wrong', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,

                            });

                        });
            }
        })

    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


}
