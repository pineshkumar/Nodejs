import { Component, Inject, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../../_services/index';
import { fuseAnimations } from '@fuse/animations';

export interface PeriodicElement {
  catName: string;
  description: string;
  status: Boolean;
  action: string;

}


@Component({
  selector: 'app-productcategories',
  templateUrl: './productcategories.component.html',
  styleUrls: ['./productcategories.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class ProductCategoriesComponent implements OnInit {

  allproductcategories: any[];
  displayedColumns: string[] = ['catName', 'description', 'status', 'action'];
  dataSource;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  constructor(public dialog: MatDialog, private CompanyService: CompanyService) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.CompanyService.getAllproductcategories()
      .subscribe(
        data => {
          // console.log(data);
          this.allproductcategories = data;
          const productcategories = data;
          const allproductcategories = [];
          productcategories.forEach(element => {

            allproductcategories.push(element);

          });
          this.dataSource = new MatTableDataSource(allproductcategories);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }

  statustoggal(status, id) {
  
    this.CompanyService.updatetoggleone(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  deleteproductcategories(id, name) {
    let dialogRef = this.dialog.open(deleteproductcategoriesPopupComponent, {
      data: {
        productcategoriesId: id,
        catName: name

      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.CompanyService.getAllproductcategories()
        .subscribe(
          data => {
            this.allproductcategories = data;
            const productcategories = data;
            const allproductcategories = [];
            productcategories.forEach(element => {

              allproductcategories.push(element);

            });
            this.dataSource = new MatTableDataSource(allproductcategories);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }

}


@Component({
  selector: 'deleteproductcategories-popup',
  templateUrl: './deleteproductcategoriespopup.html'
})
export class deleteproductcategoriesPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private CompanyService: CompanyService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {
   
  }

  ngOnInit() {

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/catalogue/productcategories';
  }

  delete(id, name) {
   

    //'Assign another category to gallery then delete the product category'
    this.CompanyService.deleteproductcategories(id, name)
      .subscribe(
        data => {

          if (data) {
            this.snackBar.open('Assign another category to gallery then delete the product category', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
          } else {

            this.snackBar.open('Product category deleted successfully', '', {
              duration: 5000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });

            this.router.navigate([this.returnUrl]);

          }

        },

        error => {

          console.log(error);
          // this.alertService.error(error);
        });

  }


}





export class DialogContentExampleDialog { }
