import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule, MatPaginatorModule, MatDialogModule, MatCheckboxModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AngularEditorModule } from '@kolkov/angular-editor';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';

import { ProductCategoriesComponent } from './productcategories.component';
import { AddProductCategoryComponent } from './addpproductcategory/addpproductcategory.component';
import { UpdateProductCategoryComponent } from './updateproductcategory/updateproductcategory.component';
import { ProductGalleryComponent } from './productgallery/productgallery.component';
import { AddProductComponent } from './addproduct/addproduct.component';
import { UpdateProductComponent } from './updateproduct/updateproduct.component';
import { deleteproductcategoriesPopupComponent } from './productcategories.component';
import { deleteproductgalleryPopupComponent } from './productgallery/productgallery.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';


const routes = [
    {
        path: 'catalogue/productcategories',
        component: ProductCategoriesComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'catalogue/addproductcategory',
        component: AddProductCategoryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'catalogue/updateproductcategory/:id',
        component: UpdateProductCategoryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'catalogue/productgallery',
        component: ProductGalleryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'catalogue/addproduct',
        component: AddProductComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'catalogue/updateproduct/:id',
        component: UpdateProductComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'updateproductcategory',
        component: deleteproductcategoriesPopupComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'productgallery',
        component: deleteproductgalleryPopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        ProductCategoriesComponent,
        AddProductCategoryComponent,
        UpdateProductCategoryComponent,
        ProductGalleryComponent,
        AddProductComponent,
        UpdateProductComponent,
        deleteproductcategoriesPopupComponent,
        deleteproductgalleryPopupComponent],
    imports: [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        MatCheckboxModule,
        AutofocusModule,
        AngularEditorModule,
        NgxLoadingModule.forRoot({})
    ],
    exports: [
        ProductCategoriesComponent,
        AddProductCategoryComponent,
        UpdateProductCategoryComponent,
        ProductGalleryComponent,
        AddProductComponent,
        UpdateProductComponent,
        deleteproductcategoriesPopupComponent,
        deleteproductgalleryPopupComponent
    ]
})

export class ProductCategoriesModule {
}
