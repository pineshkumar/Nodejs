import { Component, OnDestroy, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { CompanyService } from '../../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector: 'app-addproduct',
    templateUrl: '../addproduct/addproduct.component.html',
    styleUrls: ['../addproduct/addproduct.component.scss'],
    animations: fuseAnimations
})
export class AddProductComponent implements OnInit, OnDestroy {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    form: FormGroup;
    fileSelected: File;

    productcategories: string[] = [''];
    currencies: any;
    returnUrl: string;
    urls = new Array<string>();
    filesToUpload: Array<File> = [];
    show = false;
    checkboxdata = new Array();
    isCollapsed: boolean = true;
    requireshipping: boolean = false;
    currentclass: string = 'hidefield';
    requirelink: any;

    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private CompanyService: CompanyService,
        private route: ActivatedRoute,
        private router: Router,
        public snackBar: MatSnackBar,
        private sanitizer: DomSanitizer,

    ) {
        // Set the private defaults
        this._unsubscribeAll = new Subject();

    }

    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }

    //   toggleTemplate(): void {
    //     if (this.loadingTemplate) {
    //       this.loadingTemplate = null;
    //     } else {
    //       this.loadingTemplate = this.customLoadingTemplate;
    //     }
    //   }

    public showAlert(): void {
        alert('ngx-loading rocks!');
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */

    ngOnInit(): void {

        // Reactive Form
        this.form = this._formBuilder.group({
            image: [''],
            youtube: [''],
            catName: ['', Validators.required],
            proName: ['', Validators.required],
            description: ['', Validators.required],
            currencyname: ['', Validators.required],
            productprice: ['', Validators.required],
            discountprice: [''],
            shippingcharge: [''],
            transactionprice: [''],
            netamount: ['', Validators.required],
            onlinelink: [''],
            priority: ['', Validators.required],
            onweb: true,
            onapp: true,
            productavailability: true,
            freeshipping: true,
            facebook: true,
            twitter: true,
            subscribe: true,
            checkboxtoggle: false,
            status: true,
            companyid: [localStorage.getItem('userId')],
            userId: [localStorage.getItem('userId')],
        });

        this.route.params.subscribe(params => {
            this.CompanyService.getproductcategories()
                .subscribe(
                    data => {
                        this.productcategories = data;
                    },
                    error => {
                        console.log(error);

                    });

            this.CompanyService.getcurrencyname()
                .subscribe(
                    data => {

                        this.currencies = data;
                    },
                    error => {
                        console.log(error);

                    });
            this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/catalogue/productgallery';

        });


    }

    fileChangeEvent(fileInput: any) {
      
        var imagefiles = fileInput.target.files;
        if (fileInput.target.files && fileInput.target.files[0]) {
            var filesAmount = fileInput.target.files.length;


            for (let i = 0; i < filesAmount; i++) {
                var testreader = new FileReader();
                testreader.onload = (fileInput: any) => {

                    this.urls.push(fileInput.target.result);

                    this.checkboxdata.push(false);

                    this.filesToUpload.push(imagefiles[i]);
                }
                testreader.readAsDataURL(fileInput.target.files[i]);
            }
        }
    }
    close(urls, event, index, i) {

        urls.splice(i, 1);
        var temp = new Array<File>();
        for (var j = 0; j < this.filesToUpload.length; j++) {
            if (j != i) {
                temp.push(this.filesToUpload[j]);
            }
        }
        this.filesToUpload = temp;

    }

    checkboxclick($event, index) {

        this.checkboxdata.forEach((element, i) => {
            this.checkboxdata[i] = false;
        });

        this.checkboxdata[index] = $event.target.checked;
        $('.image-list').on('change', function () {
            $('.image-list').not(this).prop('checked', false);

        });

    }

    clickVet($event: any) {
        //this.currentclass='test';
        let shippingtoggle = this.form.get("freeshipping");
        if (shippingtoggle.value == true) {
            this.currentclass = 'showfield';
        }
        else {
            this.currentclass = 'hidefield';
        }
        

    }

    addproductgallery() {



        if (this.form.value.discountprice > this.form.value.productprice) {
            this.loading = false;
            this.snackBar.open('Discount price should be smaller then product price', '', {
                duration: 3000,
                horizontalPosition: this.horizontalPosition,
                verticalPosition: this.verticalPosition,
            });
        }
        else if (this.form.value.checkboxtoggle == false) {
            if (this.filesToUpload.length == 0) {
                this.loading = false;
                this.snackBar.open('Please select at least one image', '', {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
            }
            else if (jQuery.inArray(true, this.checkboxdata) == -1) {
                this.loading = false;
                this.snackBar.open('Please check an image', '', {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
            }
            else if (this.filesToUpload.length > 0) {

            
                this.CompanyService.addproductgallery(this.filesToUpload, this.checkboxdata)

                    .subscribe(
                        data => {
                            this.loading = false;
                            this.form.value.image = data
                            // this.loading = true;
                          

                            this.loading = false;
                            this.CompanyService.addagaingallery(this.form.value)

                                .subscribe(
                                    data => {
                                        this.loading = false;
                                        if (data.string == "Proname Is Already Exist Please Enter Another Proname Name!") {
                                            this.snackBar.open('Proname Is Already Exist Please Enter Another Proname Name!', '', {
                                                duration: 3000,
                                                horizontalPosition: this.horizontalPosition,
                                                verticalPosition: this.verticalPosition,
                                            });
                                        } else {

                                            this.snackBar.open('Product added successfully', '', {
                                                duration: 3000,
                                                horizontalPosition: this.horizontalPosition,
                                                verticalPosition: this.verticalPosition,
                                            });
                                            this.router.navigate([this.returnUrl]);
                                        }

                                        // this.form.reset();
                                        // this.form.clearValidators();
                                    },
                                    error => {
                                        console.log(error);
                                        this.loading = false;
                                        this.snackBar.open('Something went wrong', '', {
                                            duration: 3000,
                                            horizontalPosition: this.horizontalPosition,
                                            verticalPosition: this.verticalPosition,
                                        });
                                        this.router.navigate([this.returnUrl]);
                                    });
                        });

            }
        }

        else {
            this.CompanyService.addagaingallery(this.form.value)

                .subscribe(
                    data => {
                        this.loading = false;
                        this.snackBar.open('Product added successfully', '', {
                            duration: 3000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });
                        // this.form.reset();
                        // this.form.clearValidators();
                    },
                    error => {
                        this.loading = false;
                        this.snackBar.open('Something went wrong', '', {
                            duration: 3000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });
                        this.router.navigate([this.returnUrl]);
                    });
        }
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


}
