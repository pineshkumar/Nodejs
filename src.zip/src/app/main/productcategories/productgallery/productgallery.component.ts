import { Component, Inject, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { fuseAnimations } from '@fuse/animations';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../../../_services/index';


export interface PeriodicElement {


  proName: string;
  catName: string;
  priority: string;
  netamount: string;
  views: number;
  status: boolean;
  image: string;
  onweb: boolean;
  onapp: boolean;
  action: string;
}


@Component({
  selector: 'app-productgallery',
  templateUrl: '../productgallery/productgallery.component.html',
  styleUrls: ['../productgallery/productgallery.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class ProductGalleryComponent implements OnInit {
  productcategories: any;
  form: FormGroup;
  allproductgallery: any[];
  displayedColumns: string[] = ['image', 'proName', 'catName', 'priority', 'netamount', 'views', 'status', 'onweb', 'onapp', 'action'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: any) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(
    public dialog: MatDialog,
    private CompanyService: CompanyService,
    private _formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
  ) { }


  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.form = this._formBuilder.group({

      catName: [''],

    });

    this.route.params.subscribe(params => {
      this.CompanyService.getproductcategories()
        .subscribe(
          data => {

            this.productcategories = data;

          },
          error => {
            console.log(error);

          });


    });


    this.CompanyService.getAllproductgallery()
      .subscribe(
        data => {

          this.allproductgallery = data;
          const productgallery = data;
          const allproductgallery = [];
          productgallery.forEach(element => {

            if (element.priority == '0') {
              element.priority = 'High';
            }
            else if (element.priority == '1') {
              element.priority = 'Normal';
            }
            else {
              element.priority = 'Low';
            }
            allproductgallery.push(element);
         
            for (var i in element.image) {

              if (element.image[i].checkbox == 'true') {
              element.mainimage = element.image[i].url

              }}


          });
        
          this.dataSource = new MatTableDataSource(allproductgallery);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }



  onwebstatustoggal(status, id) {

    this.CompanyService.onwebupdatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }


  onappstatustoggal(status, id) {

    this.CompanyService.onAPPupdatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  statusstatustoggal(status, id) {

    this.CompanyService.Statusupdatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  filter(_id) {
   
    this.CompanyService.filtercategory(_id)
      .subscribe(
        data => {
         


          this.allproductgallery = data;
          const productgallery = data;
          const allproductgallery = [];
          productgallery.forEach(element => {

            allproductgallery.push(element);
           
         
          });
          this.dataSource = new MatTableDataSource(allproductgallery);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error)
        });
  }

  deleteproductgallery(id, name) {
    let dialogRef = this.dialog.open(deleteproductgalleryPopupComponent, {
      data: {
        productgalleryId: id,
        proName: name
      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.CompanyService.getAllproductgallery()
        .subscribe(
          data => {
            this.allproductgallery = data;
            const productgallery = data;
            const allproductgallery = [];
            productgallery.forEach(element => {
           
              allproductgallery.push(element);

            });
            this.dataSource = new MatTableDataSource(allproductgallery);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }

}

@Component({
  selector: 'deleteproductgallery-popup',
  templateUrl: './deleteproductgallerypopup.html'
})
export class deleteproductgalleryPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private CompanyService: CompanyService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {


  }
  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/catalogue/productgallery';
  }

  delete(id, name) {

    this.CompanyService.deleteproductgallery(id, name)
      .subscribe(
        data => {

          this.snackBar.open('Product gallery deleted successfully', '', {
            duration: 5000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
          });
          this.router.navigate([this.returnUrl]);

        },
        error => {
          console.log(error);
        });




  }


}
export class DialogContentExampleDialog { }
