import { Component, OnInit , ViewChild} from '@angular/core';
import {MatPaginator,MatTableDataSource,MatDialog} from '@angular/material';
import { fuseAnimations } from '@fuse/animations';

export interface PeriodicElement {
  position: number;
  name: string;
  address: string;
  city: string;
  phone: number;
  email: string;
  username: string;
  accesscode: string;
  status: string;
  dateadded: string;
  datemodified: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Ritesh', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},

  {position: 2, name: 'Vishal', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},

  {position: 3, name: 'Nikita', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},


  {position: 4, name: 'Hemangi', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},


  {position: 5, name: 'Mayank', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},

  {position: 6, name: 'Swati', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},

  {position: 7, name: 'Nilesh', address: 'satellite',city: 'ahmedabad',phone: 9895820150, email: 'mitalujenia@finlitetech.com', username: 'Ujenia', accesscode: 'NXTIVh', status: 'enable', dateadded: '23-10-2018',datemodified: '23-10-2018',  action: 'H'},
 
];


@Component({
  selector: 'app-sitehealth',
  templateUrl: './sitehealth.component.html',
  styleUrls: ['./sitehealth.component.scss'],
  animations   : fuseAnimations
})
export class SitehealthComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'address', 'city', 'phone', 'email', 'username', 'accesscode', 'status', 'dateadded', 'datemodified', 'action'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
   @ViewChild(MatPaginator) paginator: MatPaginator;
  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog) {}

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }

}
export class DialogContentExampleDialog {}
