import { Component, OnInit, ViewChild, Inject, OnDestroy, ɵConsole } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { fuseAnimations } from '@fuse/animations';
import { SiteAppearanceService } from '../../_services/index';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';

export interface PeriodicElement {

}



@Component({
  selector: 'app-siteappearance',
  templateUrl: './siteappearance.component.html',
  styleUrls: ['./siteappearance.component.scss'],
  animations: fuseAnimations,

})
export class SiteAppearanceComponent implements OnInit, OnDestroy {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  returnUrl: string;
  dataSource;
  themes: any;
  form: FormGroup;

  private _unsubscribeAll: Subject<any>;
  /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */

  constructor(
    private _formBuilder: FormBuilder,
    public dialog: MatDialog,
    private SiteAppearanceService: SiteAppearanceService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar,
  ) {
    this._unsubscribeAll = new Subject();
  }



  ngOnInit() {

    this.form = this._formBuilder.group({
      themename: ['']

    });

    this.route.params.subscribe(params => {
      this.SiteAppearanceService.getsiteappearance()
        .subscribe(
          data => {

            console.log('data jargi');
            console.log(data);
            this.themes = data;
          
          },
          error => {
          
            console.log(error);

          });
    });

    var UserId = localStorage.getItem('userId');
 
    this.SiteAppearanceService.getsiteappearancebyitsID(UserId)
      .subscribe(
        data => {
       
          this.form = this._formBuilder.group({
            themename: [data.themeid],
          });
        },
        error => {
          console.log(error);

        });

  }

  updatesiteappearance(){

    
    this.form.value.UserId = localStorage.getItem('userId');
      this.SiteAppearanceService.updatesiteappearance(this.form.value)
      .subscribe(
          data => {
               
              this.snackBar.open('Site appearance updated successfully!','', {
                  duration: 3000,
                  horizontalPosition: this.horizontalPosition,
                  verticalPosition: this.verticalPosition,
                });
           
          },
          error => {
             
              console.log(error);
          });
  }


  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }


}

