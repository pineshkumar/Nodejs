import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule, MatPaginatorModule, MatDialogModule, MatCheckboxModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { AutofocusModule } from 'angular-autofocus-fix';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
//import { IgxTimePickerModule } from "igniteui-angular";
import { TimePickerModule } from '@syncfusion/ej2-angular-calendars';
import { StoreTimingComponent } from './storetiming.component';
import { changestoretimingPopupComponent } from './storetiming.component';
import { FormsModule } from '@angular/forms';
//import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';


const routes = [
    {
        path: 'storetimings',
        component: StoreTimingComponent
    },
    {
        path: 'changestoretiming',
        component: changestoretimingPopupComponent,
    },
];

@NgModule({
    declarations: [
        StoreTimingComponent, changestoretimingPopupComponent],
    imports: [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        MatCheckboxModule,
        FormsModule,
        TimePickerModule
        //IgxTimePickerModule
        // NgxMaterialTimepickerModule
    ],
    exports: [
        StoreTimingComponent,
        changestoretimingPopupComponent
    ]
})

export class StoreTimingModule {
}
