import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { StoretimingService } from '../../_services/index';
import { copyStyles } from '@angular/animations/browser/src/util';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

import { FormsModule } from '@angular/forms';

import { enableRipple } from '@syncfusion/ej2-base';

//enable ripple style
enableRipple(true);
import { TimePicker } from '@syncfusion/ej2-calendars';
import { jsonpCallbackContext } from '@angular/common/http/src/module';


// let timeObj: TimePicker = new TimePicker({
//   value: new Date(),
//   format: 'HH:mm',
//   placeholder: 'Select a time'
// });
// timeObj.appendTo('#timepicker');
//timeObj.show();

export interface PeriodicElement {
  days: string;
  position: number;
  openingtime: string;
  closingtime: string;

}





@Component({
  selector: 'app-storetiming',
  templateUrl: './storetiming.component.html',
  styleUrls: ['./storetiming.component.scss']
})
export class StoreTimingComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  displayedColumns: string[] = ['days', 'status', 'openingtime', 'closingtime'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  storetiming: any[];
  show: false;
  form: FormGroup;
  returnUrl: string;
  timingData: any;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  constructor(public dialog: MatDialog,
    private StoretimingService: StoretimingService,
    private _formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar, ) {

  }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }



  ngOnInit() {

    this.form = this._formBuilder.group({
      // days: ['', Validators.required],
      status: ['', Validators.required],
      days: this._formBuilder.array([this._formBuilder.group({ openingtime: '' })]),
      closingtime: ['', Validators.required],
      userId: [localStorage.getItem('userId')]

    });



    this.route.params.subscribe(params => {
      this.StoretimingService.getAllDatatiming()
        .subscribe(
          data => {
            // console.log('Thisismydata')
            //  console.log('Thisismydata ' + data)
            // console.log(JSON.parse(JSON.stringify(data[0].days)))
            this.timingData = JSON.parse(JSON.stringify(data[0].days));
            // console.log('this.timingData '+this.timingData)
          },
          error => {
            console.log(error);

          });
    });


    // this.dataSource.paginator = this.paginator;

    var companyid = localStorage.getItem('userId');

    this.StoretimingService.getMystoretiming(companyid)
      .subscribe(
        data => {
          const store = data[0].days;

          const storetiming = [];
          store.forEach(element => {

            storetiming.push(element);
            this.form = this._formBuilder.group({
              status: [element.status],
              openingtime: [element.openingtime],
              closingtime: [element.closingtime],
              userId: [localStorage.getItem('userId')]

            });

          });


          this.dataSource = new MatTableDataSource(storetiming);
        },
        error => {

          console.log(error);

        });
  }



  updatestoretime() {
    // console.log('valuecomponent')
    // console.log(this.form.value)
    // console.log(' this.timingData on submit ')
    // console.log(JSON.parse(JSON.stringify(this.timingData)));

    this.route.params.subscribe(params => {

      this.StoretimingService.updatestoretime(JSON.parse(JSON.stringify(this.timingData)))
        .subscribe(
          data => {
            this.snackBar.open('Store Timing updated successfully!', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
            this.router.navigate([this.returnUrl]);

          },
          error => {

            console.log(error);
          });
    });
  }

}


@Component({
  selector: 'changestoretiming-popup',
  templateUrl: './changestoretimingpopup.html'
})
export class changestoretimingPopupComponent {
  returnUrl: string;

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {
    //console.log(data);

  }

  ngOnInit() {

    // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/catalogue/productcategories';
    //   let timeObj: TimePicker = new TimePicker({
    //     placeholder: 'Select a time'
    // });
    // timeObj.appendTo('#timepicker');
    // timeObj.show();


  }

}
export class DialogContentExampleDialog { }
