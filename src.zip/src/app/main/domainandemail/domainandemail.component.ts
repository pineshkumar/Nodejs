import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { ThirdPartyIntergration } from '../../_services/index';

// export interface PeriodicElement {
//   domain: string;
//   dateadded: string;
//   validtill: string;

// }

// const ELEMENT_DATA: PeriodicElement[] = [
//   { domain: 'Ritesh', dateadded: '23-10-2018', validtill: '23-10-2018', },
// ];


@Component({
  selector: 'app-domainandemail',
  templateUrl: './domainandemail.component.html',
  styleUrls: ['./domainandemail.component.scss'],
  animations: fuseAnimations
})
export class DomainandemailComponent implements OnInit {
  DomainAndEmail: any;
  createddate: any;
  validdate: any;
  // displayedColumns: string[] = ['domainname', 'dateadded', 'validtill',];
  dataSource;
  //  = new MatTableDataSource(ELEMENT_DATA)
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog,
    private ThirdPartyIntergration: ThirdPartyIntergration) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    // this.dataSource.paginator = this.paginator;

    this.ThirdPartyIntergration.getDomainAndEmail()
      .subscribe(
        data => {

          var date = new Date(data[0].createddate);
          var month = ('0' + (date.getMonth() + 1)).slice(-2);
          var dates = ('0' + date.getDate()).slice(-2);
          var year = date.getFullYear() + data[0].companies.packageName[0].years;
          var ExpiryDate = year + '/' + month + '/' + dates;

          this.DomainAndEmail = data[0].domainName;
          this.createddate = data[0].createddate;
          this.validdate = ExpiryDate
        },
        error => {
          console.log(error);
        });


  }

}
export class DialogContentExampleDialog { }
