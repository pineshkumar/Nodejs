import { Component, Inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { DomainService } from '../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { formatDate } from "@angular/common";

export interface PeriodicElement {

  companyname: string;
  domain: string;
  // subdomain: string;
  package: string;
  activatedate: string;
  expirydate: string;
  websitestatus: string;
  createddate: string;
  action: string;
}

@Component({
  selector: 'app-domainrequests',
  templateUrl: './domainrequests.component.html',
  styleUrls: ['./domainrequests.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class DomainrequestsComponent implements OnInit {
  alldomains: any[];
  displayedColumns: string[] = ['companyname', 'domain', 'package', 'activatedate', 'expirydate', 'websitestatus', 'createddate', 'action'];
  dataSource;


  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog, private DomainService: DomainService, private route: ActivatedRoute,
    private router: Router, public snackBar: MatSnackBar) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }



  ngOnInit() {



    const format = 'yyyy/MM/dd';
    const myDate = new Date();
    const locale = 'en-US';
    const currentdate = formatDate(myDate, format, locale);

    this.DomainService.getAllDomainRequests()
      .subscribe(
        data => {

          this.alldomains = data;
         
          const domains = data;
          const alldomains = [];

          domains.forEach(element => {
            var date = new Date(element.createddate);
            var month = ('0' + (date.getMonth() + 1)).slice(-2);
            var dates = ('0' + date.getDate()).slice(-2);
            var year = date.getFullYear() + element.company.packageName[0].years;
            var ExpiryDate = year + '/' + month + '/' + dates;

            var WebsiteStatus = '';
            if (ExpiryDate == currentdate) {

              WebsiteStatus = 'InActive';
            } else {

              WebsiteStatus = 'Active';
            }

            element.createddate = date.toDateString();
            element.ExpiryDate = ExpiryDate;
            element.websitestatus = WebsiteStatus;
            alldomains.push(element);

          });

          this.dataSource = new MatTableDataSource(alldomains);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });
  }

  deleteDomainRequests(id, name) {

    const format = 'yyyy/MM/dd';
    const myDate = new Date();
    const locale = 'en-US';
    const currentdate = formatDate(myDate, format, locale);

    let dialogRef = this.dialog.open(deletedomainrequestsPopupComponent, {

      data: {
        usageId: id,
        pagename: name
      },
      width: '500px'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.DomainService.getAllDomainRequests()
        .subscribe(
          data => {
            this.alldomains = data;
            const domains = data;
            const alldomains = [];
            domains.forEach(element => {
              var date = new Date(element.createddate);

              var month = ('0' + (date.getMonth() + 1)).slice(-2);
              var dates = ('0' + date.getDate()).slice(-2);
              var year = date.getFullYear() + element.company.packageName[0].years;
              var ExpiryDate = year + '/' + month + '/' + dates;

              var WebsiteStatus = '';
              if (ExpiryDate == currentdate) {
                WebsiteStatus = 'InActive';
              } else {

                WebsiteStatus = 'Active';
              }

              element.createddate = date.toDateString();
              element.ExpiryDate = ExpiryDate;
              element.websitestatus = WebsiteStatus;
              alldomains.push(element);

            });
            this.dataSource = new MatTableDataSource(alldomains);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }
}

@Component({
  selector: 'deletedomainrequests-popup',
  templateUrl: './deletedomainrequestspopup.html'
})
export class deletedomainrequestsPopupComponent {
  returnUrl: string;

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private DomainService: DomainService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {
    
  }
  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/domainrequests';
  }

  delete(id, name) {

    this.DomainService.deleteDomainRequests(id, name)
      .subscribe(
        data => {

          this.snackBar.open('Domain request deleted successfully', '', {
            duration: 5000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
          });

          this.router.navigate([this.returnUrl]);

        },
        error => {
          console.log(error);
          // this.alertService.error(error);
        });
  }
}


export class DialogContentExampleDialog { }