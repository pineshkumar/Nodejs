import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule,MatAutocompleteModule ,MatRippleModule,MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule,MatPaginatorModule,MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';

import { DomainrequestsComponent } from './domainrequests.component';
import { AddDomainRequestComponent } from './adddomainrequest/adddomainrequest.component';
import { UpdateDomainRequestComponent } from './updatedomainrequest/updatedomainrequest.component';
import { deletedomainrequestsPopupComponent } from './domainrequests.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';
import { from } from 'rxjs';


const routes = [
    {
        path     : 'domainrequests',
        component: DomainrequestsComponent,
        canActivate: [AuthGuard]
    },
	{
        path     : 'domainrequests/adddomainrequests',
        component: AddDomainRequestComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'domainrequests/updateDomainRequests/:id',
        component: UpdateDomainRequestComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'domainrequests',
        component: deletedomainrequestsPopupComponent,
        canActivate: [AuthGuard]
    }
   
];

@NgModule({
    declarations: [
        DomainrequestsComponent,
        AddDomainRequestComponent,
        UpdateDomainRequestComponent,
        deletedomainrequestsPopupComponent,
        
    ],
    imports     : [
        RouterModule.forChild(routes),
        MatAutocompleteModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        AutofocusModule,
        MatRippleModule,
        // MatDialogModule,
        MatDialogModule,
        NgxLoadingModule.forRoot({})
    ],
    exports     : [
        DomainrequestsComponent,
        AddDomainRequestComponent,
        UpdateDomainRequestComponent,
        deletedomainrequestsPopupComponent
        
    ]
})

export class DomainrequestsModule
{
}
