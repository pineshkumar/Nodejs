import { Component, OnInit, ViewChild, OnDestroy, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject, from } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';;
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatPaginator, MatTableDataSource, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';
import { BusinesslogosService } from '../../_services/index'

@Component({
  selector: 'app-businesslogo',
  templateUrl: './businesslogo.component.html',
  styleUrls: ['./businesslogo.component.scss'],
  animations: fuseAnimations
})
export class BusinessLogoComponent implements OnInit, OnDestroy {
  form: FormGroup;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  returnUrl: string;
  urls = new Array<string>();
  filesToUpload: Array<File> = [];
  filesToUploadBanner: Array<File> = [];
  faviconfileupload: Array<File> = []
  url: string;
  faviconurl: string;
  fileinputid: string;

  images: any;

  @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
  @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
  public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
  public loading = false;
  public primaryColour = PrimaryWhite;
  public secondaryColour = SecondaryGrey;
  public coloursEnabled = false;
  public loadingTemplate: TemplateRef<any>;
  public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };


  // onSelectFile(event) {

  //   if (event.target.files && event.target.files[0]) {
  //     var reader = new FileReader();

  //     reader.readAsDataURL(event.target.files[0]); // read file as data url

  //     reader.onload = (event) => { // called once readAsDataURL is completed
  //       // this.url = event.target.result;
  //     }
  //   }
  // }

  private _unsubscribeAll: Subject<any>;
  /**
* Constructor
*
* @param {FormBuilder} _formBuilder
*/
  constructor(
    private _formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar,
    private BusinesslogosService: BusinesslogosService
  ) {
    this._unsubscribeAll = new Subject();
  }

  public toggleColours(): void {
    this.coloursEnabled = !this.coloursEnabled;

    if (this.coloursEnabled) {
      this.primaryColour = PrimaryRed;
      this.secondaryColour = SecondaryBlue;
    } else {
      this.primaryColour = PrimaryWhite;
      this.secondaryColour = SecondaryGrey;
    }
  }

  //   toggleTemplate(): void {
  //     if (this.loadingTemplate) {
  //       this.loadingTemplate = null;
  //     } else {
  //       this.loadingTemplate = this.customLoadingTemplate;
  //     }
  //   }

  public showAlert(): void {
    alert('ngx-loading rocks!');
  }

  ngOnInit(): void {
    this.form = this._formBuilder.group({
      bannerImage: [''],
    });

    var userId = localStorage.getItem('userId');

    this.BusinesslogosService.getAllbusinesslogo(userId)
      .subscribe(
        data => {
          this.url = data[0].imagelogo[0].url;
          this.faviconurl = data[0].faviconlogo[0].url;
          this.images = data[0].bannerImage;
        },
        error => {

          console.log('error');
          console.log(error);

        });



  }

  fileChangeEvent(fileInput: any) {

    this.fileinputid = fileInput.target.id
    if (fileInput.target.files && fileInput.target.files[0]) {
      var filesAmount = fileInput.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (fileInput: any) => {
          this.url = fileInput.target.result;
        }
        reader.readAsDataURL(fileInput.target.files[i]);

        this.filesToUpload.push(fileInput.target.files[i]);


      }
    }

  }


  onSelectFile(fileInput1: any) {

    this.fileinputid = fileInput1.target.id
    if (fileInput1.target.files && fileInput1.target.files[0]) {
      var filesAmount = fileInput1.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (fileInput1: any) => {
          this.faviconurl = fileInput1.target.result;
        }
        reader.readAsDataURL(fileInput1.target.files[i]);



        this.faviconfileupload.push(fileInput1.target.files[i]);


      }
    }

  }

  fileChangeEventBanner(fileInputbanner: any) {

    this.fileinputid = fileInputbanner.target.id
    var imagefiles = fileInputbanner.target.files;
    if (fileInputbanner.target.files && fileInputbanner.target.files[0]) {
      var filesAmount = fileInputbanner.target.files.length;


      for (let i = 0; i < filesAmount; i++) {
        var testreader = new FileReader();
        testreader.onload = (fileInputbanner: any) => {

          this.urls.push(fileInputbanner.target.result);

          this.filesToUploadBanner.push(imagefiles[i]);
        }
        testreader.readAsDataURL(fileInputbanner.target.files[i]);
      }
    }
  }
  close(urls, event, index, i) {

    urls.splice(i, 1);
    var temp = new Array<File>();
    for (var j = 0; j < this.filesToUploadBanner.length; j++) {
      if (j != i) {
        temp.push(this.filesToUploadBanner[j]);
      }
    }
    this.filesToUploadBanner = temp;

  }

 
  delete(images, event, index, i, _id) {
    
    var userId = localStorage.getItem('userId');
    images.splice(i, 1);
    
    this.BusinesslogosService.deleteBannerarray(userId, _id)

      .subscribe(
        data => {
        
        },
        error => {
          
        });

  }


  /**
    * On destroy
    */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }


  addbusinesslogo() {
    this.loading = true;

    if (this.fileinputid == 'fileInput') {

      let logo: any = this.filesToUpload[this.filesToUpload.length - 1];

      this.BusinesslogosService.addbusinesslogo(logo)
        .subscribe(data => {
          this.loading = false;
          this.form.value.image = data[0];
          this.form.value.userId = localStorage.getItem('userId');

          this.BusinesslogosService.addagainbusinesslogo(this.form.value)
            .subscribe(
              data => {
                this.loading = false;
                this.snackBar.open('Business logo successfully update ', '', {
                  duration: 3000,
                  horizontalPosition: this.horizontalPosition,
                  verticalPosition: this.verticalPosition,
                });
                this.fileinputid = '';
              },
              error => {
                this.loading = false;
                console.log(error);

              });
        })
    } else if (this.fileinputid == 'fileInput1') {

      let faviconfile: any = this.faviconfileupload[this.faviconfileupload.length - 1];


      this.BusinesslogosService.addbusinesslogo(faviconfile)
        .subscribe(data => {
          this.loading = false;
          this.form.value.faviconimage = data[0];
          this.form.value.userId = localStorage.getItem('userId');

          this.BusinesslogosService.addagainbusinesslogo(this.form.value)
            .subscribe(
              data => {
                this.loading = false;
                this.snackBar.open('favicon image successfully update ', '', {
                  duration: 3000,
                  horizontalPosition: this.horizontalPosition,
                  verticalPosition: this.verticalPosition,
                });
                this.fileinputid = '';
              },
              error => {
                console.log(error);
                this.loading = false;
              });
        })

    } else if (this.fileinputid == 'fileInputbanner') {
      this.loading = false;

      this.BusinesslogosService.addBenneragain(this.filesToUploadBanner)

        .subscribe(
          data => {

            this.loading = false;
            this.form.value.bannerImage = data
            this.form.value.userId = localStorage.getItem('userId');

            this.BusinesslogosService.addBenerLogoMultiple(this.form.value)

              .subscribe(
                data => {
                  this.loading = false;
                  this.snackBar.open('Banner Added', '', {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                  });
                  // window.location.reload();
                  // setTimeout(location.reload.bind(location), 1000);
                  window.setTimeout(function(){location.reload()},800)
                },
                error => {
                  console.log(error);
                  this.loading = false;
                  this.snackBar.open('Something went wrong', '', {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                  });
                });
          });

    } else {
      this.loading = false;
      this.snackBar.open('Please select image ', '', {
        duration: 3000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });

    }
  }
}


