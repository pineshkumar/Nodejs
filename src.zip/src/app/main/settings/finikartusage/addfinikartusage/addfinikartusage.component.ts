import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';

@Component({
    selector   : 'app-finikartusage',
    templateUrl: '../addfinikartusage/addfinikartusage.component.html',
    styleUrls  : ['../addfinikartusage/addfinikartusage.component.scss'],
    animations   : fuseAnimations
})
export class AddFinikartusageComponent implements OnInit, OnDestroy
{
    form: FormGroup;

    
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Reactive Form
        this.form = this._formBuilder.group({
          
            pagename : ['', Validators.required],
            description  : ['', Validators.required],
			
            Status   : ['', Validators.required],
           
		});

        
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    
}
