import { Component, OnDestroy, OnInit, ViewChild, TemplateRef  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { SettingService } from '../../../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
import { MatDialog,MAT_DIALOG_DATA,MatSnackBar,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition,MatTooltip  } from '@angular/material';

const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector   : 'app-updatefinikartusage',
    templateUrl: '../updatefinikartusage/updatefinikartusage.component.html',
    styleUrls  : ['../updatefinikartusage/updatefinikartusage.component.scss'],
    animations   : fuseAnimations,
    
})

export class UpdateFinikartusageComponent implements OnInit, OnDestroy

{
    form: FormGroup;
    htmlContent = '';
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    returnUrl: string;

    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };
  


  name = 'ng2-ckeditor';
  ckeConfig: any;
  mycontent: string;
  log: string = '';
  @ViewChild("myckeditor") ckeditor: any;
    // Private
    private _unsubscribeAll: Subject<any>;
    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private SettingService: SettingService,
        private route: ActivatedRoute,
        private router: Router,
      
      public snackBar: MatSnackBar,
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }
    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.mycontent = `<p>My html content</p>`;

        this.ckeConfig = {
            allowedContent: false,
            extraPlugins: 'divarea',
            forcePasteAsPlainText: true
          };
        this.form = this._formBuilder.group({
            pagename : ['', Validators.required],
            htmlContent : ['', Validators.required],
            Status:true,
            userId  : [localStorage.getItem('userId')]
		});

      
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/settings/finikartusage';
        this.route.params.subscribe(params => {
            this.SettingService.getUsagebyId(params.id)
            .subscribe(
                data => {
                  
                    this.form = this._formBuilder.group({
                        
                        pagename : [data.pagename, Validators.required],
                        htmlContent  : [data.description, Validators.required],
                        Status:[data.status, Validators.required],
                        userId  : [localStorage.getItem('userId')],
                    });
                    
                   // this.router.navigate([this.returnUrl]);
                },
                error => {
                    console.log(error);
                   // this.alertService.error(error);
                });
            
           
             });        
    }

    updateusage() {
        this.loading = true;
        this.route.params.subscribe(params => {
            this.form.value._id = params.id;

    
            this.SettingService.updateusage(this.form.value)
            .subscribe(
                data => {
                      
                      
                      this.snackBar.open('Finikart usage page updated successfully!', '', {
                        duration: 3000,
                        horizontalPosition: this.horizontalPosition,
                        verticalPosition: this.verticalPosition,
                      });

                       this.router.navigate([this.returnUrl]);
                   
                },
                error => {
                    this.loading = false;
                    console.log(error);


                });
        });
    }





    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    
}
