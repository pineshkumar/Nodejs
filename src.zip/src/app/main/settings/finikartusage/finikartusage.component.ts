import { Component, OnInit , ViewChild,Inject} from '@angular/core';
import {MatPaginator,MatTableDataSource,MatDialog} from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { SettingService } from '../../../_services/index';
import { from } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import {MAT_DIALOG_DATA,MatSnackBar,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition} from '@angular/material';



export interface PeriodicElement {
  position: number;
  pagename: string;
  status: string;
  dateadded: string;
  action: string;
  
}


const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, pagename: 'About Us', status: 'enable', dateadded: '23-10-2018', action: 'H'},
  {position: 2, pagename: 'FAQs', status: 'enable', dateadded: '23-10-2018', action: 'H'},
  {position: 3, pagename: 'Terms of Use', status: 'enable', dateadded: '23-10-2018', action: 'H'},
  {position: 4, pagename: 'Privacy Policy', status: 'enable', dateadded: '23-10-2018', action: 'H'},
 
];


@Component({
  selector: 'app-finikartusage',
  templateUrl: '../finikartusage/finikartusage.component.html',
  styleUrls: ['../finikartusage/finikartusage.component.scss'],
  animations   : fuseAnimations
})
export class FinikartusageComponent implements OnInit {
  allfinicartusage: any[];
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  displayedColumns: string[] = ['pagename', 'status', 'dateadded','action'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
 
  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  constructor(public dialog: MatDialog , private SettingService: SettingService,private route: ActivatedRoute,
    private router: Router, public snackBar: MatSnackBar) {
   
 
  }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;

  
    this.SettingService.getAllUsage()
            .subscribe(
                data => {
                 
                    const useage = data;
                    const allfinicartusage = [];
                    useage.forEach(element => {

                      allfinicartusage.push(element);
                     
                  }); 
                  this.dataSource = new MatTableDataSource(allfinicartusage);
                  this.dataSource.paginator = this.paginator;
                },
                error => {
                 
                    console.log(error);
                });
  }

  statustoggal(status,id){
   
    this.SettingService.updatetoggle(status.checked,id)
    .subscribe(
      data => {
        this.snackBar.open('Status change successfully', '', {
          duration: 3000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
      });
      },
      error => {
          console.log(error);
      });
      }
      

  deleteusage(id,name) {

    let dialogRef = this.dialog.open(deletefinikartusagePopupComponent, {
      data: {
        usageId: id,
        pagename : name
      },
      width: '500px'
  });

  dialogRef.afterClosed().subscribe(result => {
      this.SettingService.getAllUsage()
      .subscribe(
        data => {
          this.allfinicartusage = data;
          const useage = data;
          const allfinicartusage = [];
          useage.forEach(element => {

            allfinicartusage.push(element);
           
        });
       
          this.dataSource = new MatTableDataSource(allfinicartusage);
          this.dataSource.paginator = this.paginator;
        },
        error => {
            console.log(error);
        });
  });

  }
}

@Component({
  selector: 'deletefinikartusage-popup',
  templateUrl: './deletefinikartusagepopup.html'
})
export class deletefinikartusagePopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
      private route: ActivatedRoute,
      private router: Router,
      public snackBar: MatSnackBar,
      private SettingService: SettingService
  ) {
      //console.log(data);

  }
  ngOnInit() {
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/packages';
  }

  delete(id,name) {
   
   
    this.SettingService.deleteusage(id,name)
    .subscribe(
        data => {

          this.snackBar.open('Usage deleted successfully', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
          });
          
        
        },
        error => {
            console.log(error);
            
        });    
  }

}









export class DialogContentExampleDialog {}
