import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule,MatPaginatorModule,MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';

import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { FinikartusageComponent } from '../finikartusage/finikartusage.component';
import { AddFinikartusageComponent } from '../finikartusage//addfinikartusage/addfinikartusage.component';
import { UpdateFinikartusageComponent } from '../finikartusage//updatefinikartusage/updatefinikartusage.component';
import { deletefinikartusagePopupComponent } from './finikartusage.component';
import { AuthGuard } from '../../../_guards/index';
import { CKEditorModule } from 'ng2-ckeditor';



const routes = [
    {
        path     : 'settings/finikartusage',
        component: FinikartusageComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'finikartusage/addfinikartusage',
        component: AddFinikartusageComponent,
        canActivate: [AuthGuard]

    },
    {
        path     : 'finikartusage/updatefinikartusage/:id',
        component: UpdateFinikartusageComponent,
        canActivate: [AuthGuard]

    },
    {
        path     : 'settings/finikartusage',
        component: deletefinikartusagePopupComponent,
        canActivate: [AuthGuard]

    }
];

@NgModule({
    declarations: [
        FinikartusageComponent,AddFinikartusageComponent,UpdateFinikartusageComponent,deletefinikartusagePopupComponent    ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        CKEditorModule

    ],
    exports     : [
        FinikartusageComponent,
        AddFinikartusageComponent,
        UpdateFinikartusageComponent,
        deletefinikartusagePopupComponent
    ]
})

export class FinikartusageModule
{
}
