import {MatDialog} from '@angular/material';
import { fuseAnimations } from '@fuse/animations';

import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';


/**
 * @title Dialog with header, scrollable content and actions
 */
@Component({
  selector: 'app-helpandsupport',
  templateUrl: '../helpandsupport/helpandsupport.component.html',
  styleUrls: ['../helpandsupport/helpandsupport.component.scss'],
  animations   : fuseAnimations
})

export class HelpandsupportComponent implements OnInit, OnDestroy
{
    form: FormGroup;

    
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Reactive Form
        this.form = this._formBuilder.group({
          Name : ['Ritesh'],
          Contact  : ['9898989898'],
          Email  : ['abc@gmail.com'],
			
		});

        
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    
}


