import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule,MatPaginatorModule,MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

import { PhotoGalleryComponent } from './photogallery.component';
import { AddImageComponent } from './addimage/addimage.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';
import { deleterephotogalleryPopupComponent } from './photogallery.component';

const routes = [
    {
        path     : 'webmanager/photogallery',
        component: PhotoGalleryComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'webmanager/addimage',
        component: AddImageComponent,
        canActivate: [AuthGuard]
    },
    {
        path     : 'photogallery',
        component: deleterephotogalleryPopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        PhotoGalleryComponent,
        AddImageComponent,
        deleterephotogalleryPopupComponent  ],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        NgxLoadingModule.forRoot({}),
        
    ],
    exports     : [
        PhotoGalleryComponent,
        AddImageComponent,
        deleterephotogalleryPopupComponent
    ]
})

export class PhotoGalleryModule
{

    
}
