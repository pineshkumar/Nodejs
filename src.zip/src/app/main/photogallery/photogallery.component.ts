import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, Inject, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { PhotogalleryService } from '../../_services/index';

export interface PeriodicElement {

  image: string;
}


@Component({
  selector: 'app-photogallery',
  templateUrl: './photogallery.component.html',
  styleUrls: ['./photogallery.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
})
export class PhotoGalleryComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  form: FormGroup;
  images: any;
  deletebuttonhide:string;
  allphotogallery: any[];
  displayedColumns: string[] = ['image'];
  checkbox: any;
  //checkedphotos: any = {};
  //temp = new Array();
  temp: [];
  checkedphotos = new Array();
  // dataSource;
  constructor(
    public dialog: MatDialog,
    private PhotogalleryService: PhotogalleryService,
    private _formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar,
  ) { }


  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.form = this._formBuilder.group({
      checkbox: false
    });
    this.PhotogalleryService.getAllphotogallery()
      .subscribe(
        data => {
         
          this.allphotogallery = data;
          const photogallery = data;
          const allphotogallery = [];
          this.images = data.image;
       
           if(data.image.length == '0') {
            this.deletebuttonhide = 'true';
           
           } else {
            this.deletebuttonhide = 'false';
           }
         
          
          //      photogallery.image.forEach(element => {
          //  this.images = data;
          //       allphotogallery.push(element);
       

          //    });

          // this.dataSource = new MatTableDataSource(allphotogallery);
          // this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }

  close(images, event, index, i, _id) {
  
    var userId = localStorage.getItem('userId');
    images.splice(i, 1);
    this.PhotogalleryService.deletearray(userId, _id)

      .subscribe(
        data => {

          this.PhotogalleryService.getAllphotogallery()
          .subscribe(
            data => {
             
              this.allphotogallery = data;
              const photogallery = data;
              const allphotogallery = [];
              this.images = data.image;
             
               if(data.image.length == '0') {
                this.deletebuttonhide = 'true';
               
               } else {
                this.deletebuttonhide = 'false';
               }
            },
            error => {
              console.log(error);
            });

        },
        error => {
        });

  }

  checkboxselect(event, id) {

    if (event.target.checked == true) {
      this.checkedphotos.push(id);
    }
    else {
      this.checkedphotos.splice($.inArray(id, this.checkedphotos), 1);


    }

  }

  deletephotos() {


    if ($('input.checkphoto:checked').length > 0) {
      let dialogRef = this.dialog.open(deleterephotogalleryPopupComponent, {
        data: {
          //resellersId: id,
        
        },
        width: '450px'
      });
      dialogRef.afterClosed().subscribe(result => {
        // var temp = new Array<File>();
        // for (var j = 0; j < this.checkedphotos.length; j++) {
        //   this.images.splice(j, 1);
        // }
        var userId = localStorage.getItem('userId');
        this.PhotogalleryService.checkboxbutton(userId, this.checkedphotos)

          .subscribe(
            data => {
              window.location.reload();
              
            },
            error => {
            });
      })
    }
    else {

      this.snackBar.open('Please select checkbox to delete image ', '', {
        duration: 3000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });
  
    }
  };
}

@Component({
  selector: 'deletephotogallery-popup',
  templateUrl: './deletephotogallerypopup.html'
})
export class deleterephotogalleryPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private PhotogalleryService: PhotogalleryService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {
    

  }
  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/webmanager/photogallery';
  }
}

export class DialogContentExampleDialog { }
