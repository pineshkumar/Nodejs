import { Component, Input, OnDestroy, ViewChild, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { NavigationEnd, NavigationStart, Router, ActivatedRoute } from '@angular/router';
import { FusePerfectScrollbarDirective } from '@fuse/directives/fuse-perfect-scrollbar/fuse-perfect-scrollbar.directive';
import { FuseSidebarService } from '@fuse/components/sidebar/sidebar.service';
import { CompanyService } from 'app/_services';
import { navigation } from 'app/navigation/navigation';
import { FuseNavigationService } from '@fuse/components/navigation/navigation.service';

@Component({
    selector: 'fuse-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class FuseNavbarComponent implements OnDestroy {
    private fusePerfectScrollbar: FusePerfectScrollbarDirective;

    @ViewChild(FusePerfectScrollbarDirective) set directive(theDirective: FusePerfectScrollbarDirective) {
        if (!theDirective) {
            return;
        }

        this.fusePerfectScrollbar = theDirective;

        this.navigationServiceWatcher =
            this.navigationService.onItemCollapseToggled.subscribe(() => {
                this.fusePerfectScrollbarUpdateTimeout = setTimeout(() => {
                    this.fusePerfectScrollbar.update();
                }, 310);
            });
    }

    @Input() layout;
    navigation: any;
    custom: any;
    custom2: any;
    navigationServiceWatcher: Subscription;
    fusePerfectScrollbarUpdateTimeout;

    constructor(
        private sidebarService: FuseSidebarService,
        private navigationService: FuseNavigationService,
        private route: ActivatedRoute,
        private router: Router,
        private company: CompanyService
    ) {
        
        var custom = [
            {
                id: 'dashboard',
                title: 'Dashboards',
                url: '/dashboard',
                type: 'item',
                icon: 'dashboard'
            },
            {
                id: 'domainrequests',
                title: 'Domain Requests',
                url: '/domainrequests',
                type: 'item',
                icon: 'domain'
            },
            {
                id: 'packages',
                title: 'Packages',
                url: '/packages',
                type: 'item',
                icon: 'card_giftcard'
            },
            {
                id: 'companies',
                title: 'Companies',
                url: '/companies',
                type: 'item',
                icon: 'work'
            },
            {
                id: 'resellers',
                title: 'Resellers',
                url: '/resellers',
                type: 'item',
                icon: 'people'
            }
        ];
        var custom2 = [
            {
                id: 'catalogue',
                title: 'Manage Catalogue',
                type: 'collapsable',
                icon: 'shopping_cart',
                children: [
                    {
                        id: 'productcategories',
                        title: 'Product Categories',
                        type: 'item',
                        url: '/catalogue/productcategories',
                    },
                    {
                        id: 'productgallery',
                        title: 'Product Gallery',
                        type: 'item',
                        url: '/catalogue/productgallery',
                    }
                ]
            },
            {
                id: 'webmanager',
                title: 'Manage Website',
                type: 'collapsable',
                icon: 'language',
                children: [
                    {
                        id: 'allupdates',
                        title: 'All Updates',
                        type: 'item',
                        url: '/webmanager/allupdates',
                    },
                    {
                        id: 'photogallery',
                        title: 'Photo Gallery',
                        type: 'item',
                        url: '/webmanager/photogallery',
                    },
                    {
                        id: 'custompages',
                        title: 'Custom Pages',
                        type: 'item',
                        url: '/webmanager/custompage',
                    },
                    {
                        id: 'siteappearance',
                        title: 'Site Appearance',
                        type: 'item',
                        url: '/webmanager/siteappearance',
                    },
                    {
                        id: 'domainandemail',
                        title: 'Domain and Email',
                        type: 'item',
                        url: '/webmanager/domainandemail',
                    }
                ]
            },
            {
                id: 'thirdpartyintergration',
                title: 'Third Party Intergration',
                url: '/thirdpartyintergration',
                type: 'item',
                icon: 'insert_link'
            },
            {
                id: 'Sitehealth',
                title: 'Site Health',
                type: 'item',
                url: '/sitehealth',
                icon: 'favorite'
            },
        
            {
                id: 'settings',
                title: 'Settings',
                type: 'collapsable',
                icon: 'settings_applications',
                children: [
                    {
                        id: 'Helpandsupport',
                        title: 'Help and Support',
                        type: 'item',
                        url: '/settings/helpandsupport',
                    },
                    {
                        id: 'Finikartusage',
                        title: 'FiniKart Usage',
                        type: 'item',
                        url: '/settings/finikartusage',
                    }
                    
                    
                ]
            }
        ];

        router.events.subscribe(
            (event) => {

                if (event instanceof NavigationEnd) {
                    //compId = sessionStorage.getItem("companyId");
                    //realId = sessionStorage.getItem("realmId");
                    
                    var custom = [
                        {
                            id: 'dashboard',
                            title: 'Dashboards',
                            url: '/dashboard',
                            type: 'item',
                            icon: 'dashboard'
                        },
                        {
                            id: 'domainrequests',
                            title: 'Domain Requests',
                            url: '/domainrequests',
                            type: 'item',
                            icon: 'domain'
                        },
                        {
                            id: 'packages',
                            title: 'Packages',
                            url: '/packages',
                            type: 'item',
                            icon: 'card_giftcard'
                        },
                        {
                            id: 'companies',
                            title: 'Companies',
                            url: '/companies',
                            type: 'item',
                            icon: 'work'
                        },
                        {
                            id: 'resellers',
                            title: 'Resellers',
                            url: '/resellers',
                            type: 'item',
                            icon: 'people'
                        }
                    ];
                    var custom2 = [
                        {
                            id: 'catalogue',
                            title: 'Manage Catalogue',
                            type: 'collapsable',
                            icon: 'shopping_cart',
                            children: [
                                {
                                    id: 'productcategories',
                                    title: 'Product Categories',
                                    type: 'item',
                                    url: '/catalogue/productcategories',
                                },
                                {
                                    id: 'productgallery',
                                    title: 'Product Gallery',
                                    type: 'item',
                                    url: '/catalogue/productgallery',
                                }
                            ]
                        },
                        {
                            id: 'webmanager',
                            title: 'Manage Website',
                            type: 'collapsable',
                            icon: 'language',
                            children: [
                                {
                                    id: 'allupdates',
                                    title: 'All Updates',
                                    type: 'item',
                                    url: '/webmanager/allupdates',
                                },
                                {
                                    id: 'photogallery',
                                    title: 'Photo Gallery',
                                    type: 'item',
                                    url: '/webmanager/photogallery',
                                },
                                {
                                    id: 'custompages',
                                    title: 'Custom Pages',
                                    type: 'item',
                                    url: '/webmanager/custompage',
                                },
                                {
                                    id: 'siteappearance',
                                    title: 'Site Appearance',
                                    type: 'item',
                                    url: '/webmanager/siteappearance',
                                },
                                {
                                    id: 'domainandemail',
                                    title: 'Domain and Email',
                                    type: 'item',
                                    url: '/webmanager/domainandemail',
                                }
                            ]
                        },
                        {
                            id: 'thirdpartyintergration',
                            title: 'Third Party Intergration',
                            url: '/thirdpartyintergration',
                            type: 'item',
                            icon: 'insert_link'
                        },
                        {
                            id: 'Sitehealth',
                            title: 'Site Health',
                            type: 'item',
                            url: '/sitehealth',
                            icon: 'favorite'
                        },
                    
                        {
                            id: 'settings',
                            title: 'Settings',
                            type: 'collapsable',
                            icon: 'settings_applications',
                            children: [
                                {
                                    id: 'Helpandsupport',
                                    title: 'Help and Support',
                                    type: 'item',
                                    url: '/settings/helpandsupport',
                                },
                                {
                                    id: 'Finikartusage',
                                    title: 'FiniKart Usage',
                                    type: 'item',
                                    url: '/settings/finikartusage',
                                }
                                
                                
                            ]
                        }
                    ];
                    if (localStorage.getItem('User Type')=='Super Admin') {
                        this.navigation = custom;
                    } else {
                        this.navigation = custom2;
                    }
                }
            });

        if (localStorage.getItem('User Type')=='Super Admin') {
            this.navigation = custom;
        } else {
            this.navigation = custom2;
        }
        this.layout = 'vertical';

    }
    ngOnInit() {

        this.toggleSidebarFolded('navbar');
    }
    ngOnDestroy() {
        if (this.fusePerfectScrollbarUpdateTimeout) {
            clearTimeout(this.fusePerfectScrollbarUpdateTimeout);
        }

        if (this.navigationServiceWatcher) {
            this.navigationServiceWatcher.unsubscribe();
        }
    }

    toggleSidebarOpened(key) {
        this.sidebarService.getSidebar(key).toggleOpen();
    }

    toggleSidebarFolded(key) {
        this.sidebarService.getSidebar(key).toggleFold();
    }
}
