import { Component, OnInit , ViewChild,Inject} from '@angular/core';
import {MatPaginator,MatTableDataSource,MatDialog,MAT_DIALOG_DATA,MatSnackBar,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition} from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { CustompageService } from '../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';


export interface PeriodicElement {

  Name: string;
  Status: boolean;
  dateadded: string;
  action: string;
}


@Component({
  selector: 'app-custompage',
  templateUrl: './custompage.component.html',
  styleUrls: ['./custompage.component.scss'],
  animations   : fuseAnimations
})

export class CustompageComponent implements OnInit {
  allcustompage: any[];
  displayedColumns: string[] = ['Name', 'Status', 'dateadded', 'action'];
  dataSource;
   @ViewChild(MatPaginator) paginator: MatPaginator;
  
  applyFilter(filterValue: any) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog,private CustompageService: CustompageService) {}

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    this.CustompageService.getAllcustompage()
    .subscribe(
        data => {
        
            this.allcustompage = data;
            const custompage = data;
            const allcustompage = [];
            custompage.forEach(element => {
            var date =new Date(element.dateadded);
            // element.dateadded = date.toUTCString();
            element.dateadded = date.toDateString();
          
            allcustompage.push(element);
          });
          this.dataSource = new MatTableDataSource(allcustompage);
          this.dataSource.paginator = this.paginator;
          },
          error => {
          console.log(error);
      });
     
  }

  statustoggal(Status,id){
  
    this.CustompageService.updatetoggle(Status.checked,id)
    .subscribe(
      data => {
          
      },
      error => {
          console.log(error);
      });
      }

  deletecustompage(id, name) {
    let dialogRef = this.dialog.open(deletecustompagePopupComponent, {
        data: {
          custompageId: id,
          Name: name
        },
        width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
        this.CustompageService.getAllcustompage()
        .subscribe(
          data => {
              this.allcustompage = data;
              const custompage = data;
              const allcustompage = [];
              custompage.forEach(element => {
                var date =new Date(element.dateadded);
                // element.dateadded = date.toUTCString();
                element.dateadded = date.toDateString();
               
                allcustompage.push(element);
               
            });
            this.dataSource = new MatTableDataSource(allcustompage);
            this.dataSource.paginator = this.paginator;
          },
          error => {
              console.log(error);
          });
    });
}
}

@Component({
  selector: 'deletecustompage-popup',
  templateUrl: './deletecustompagepopup.html'
})
export class deletecustompagePopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
    

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
      private CustompageService: CustompageService,
      private route: ActivatedRoute,
      private router: Router,
      public snackBar: MatSnackBar
      
  ) {
    

  }
  ngOnInit() {
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/webmanager/custompage';
  }

  delete(id,name) {
    
      this.CustompageService.deletecustompage(id,name)
          .subscribe(
              data => {
                this.snackBar.open('Custom page deleted successfully', '', {
                    duration: 5000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
                  this.router.navigate([this.returnUrl]);
              },
              error => {
                  console.log(error);
                  // this.alertService.error(error);
              });

  }


}
export class DialogContentExampleDialog {}
