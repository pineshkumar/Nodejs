import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule, MatPaginatorModule, MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';

import { CustompageComponent } from './custompage.component';
import { AddCustompageComponent } from './addcustompage/addcustompage.component';
import { UpdateCustompageComponent } from './updatecustompage/updatecustompage.component';
import { deletecustompagePopupComponent } from './custompage.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';

import { CKEditorModule } from 'ng2-ckeditor';


const routes = [
    {
        path: 'webmanager/custompage',
        component: CustompageComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'custompage/addcustompage',
        component: AddCustompageComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'custompage/updatecustompage/:id',
        component: UpdateCustompageComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'custompage',
        component: deletecustompagePopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        CustompageComponent,
        AddCustompageComponent,
        UpdateCustompageComponent,
        deletecustompagePopupComponent
    ],
    imports: [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        AutofocusModule,
        AngularEditorModule,
        NgxLoadingModule.forRoot({}),
        AngularFontAwesomeModule,
        CKEditorModule
    ],
    exports: [
        CustompageComponent,
        AddCustompageComponent,
        UpdateCustompageComponent,
        deletecustompagePopupComponent
    ]
})

export class CustomPageModule {
}
