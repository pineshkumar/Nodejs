import { Component, OnDestroy, OnInit , ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { CustompageService } from '../../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-addcustompage',
  templateUrl: '../addcustompage/addcustompage.component.html',
  styleUrls: ['../addcustompage/addcustompage.component.scss'],
  animations: fuseAnimations
})
export class AddCustompageComponent implements OnInit, OnDestroy {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  form: FormGroup;
  returnUrl: string;
  htmlContent = '';

  @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
  @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
  public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
  public loading = false;
  public primaryColour = PrimaryWhite;
  public secondaryColour = SecondaryGrey;
  public coloursEnabled = false;
  public loadingTemplate: TemplateRef<any>;
  public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };
  
  
  name = 'ng2-ckeditor';
  ckeConfig: any;
  mycontent: string;
  log: string = '';
  @ViewChild("myckeditor") ckeditor: any;

  
  // Private
  private _unsubscribeAll: Subject<any>;

  /**
   * Constructor
   *
   * @param {FormBuilder} _formBuilder
   */
  constructor(
    private _formBuilder: FormBuilder,
    private CustompageService: CustompageService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar
  ) {
    // Set the private defaults
    this._unsubscribeAll = new Subject();
  }

  public toggleColours(): void {
    this.coloursEnabled = !this.coloursEnabled;

    if (this.coloursEnabled) {
        this.primaryColour = PrimaryRed;
        this.secondaryColour = SecondaryBlue;
    } else {
        this.primaryColour = PrimaryWhite;
        this.secondaryColour = SecondaryGrey;
    }
}

//   toggleTemplate(): void {
//     if (this.loadingTemplate) {
//       this.loadingTemplate = null;
//     } else {
//       this.loadingTemplate = this.customLoadingTemplate;
//     }
//   }

public showAlert(): void {
    alert('ngx-loading rocks!');
}
  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Reactive Form
    this.form = this._formBuilder.group({

      Name: ['', Validators.required],
      htmlContent:['', Validators.required],
      companyid  : [localStorage.getItem('userId')],
      userId: [localStorage.getItem('userId')],
      Status: true

    });

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/webmanager/custompage';
  }


  addcustompage() {
    this.loading = true;
    this.CustompageService.addcustompage(this.form.value)

      .subscribe(
        data => {
          this.loading = false;
          if (data.string == 'Page Name already extis') {
            this.snackBar.open('Page name already extis', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
          } else {
            this.snackBar.open('Custom page added successfully!', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
            this.router.navigate([this.returnUrl]);
          }

        },
        error => {
          this.loading = false;
          console.log(error);
        });
  }
  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }


}
