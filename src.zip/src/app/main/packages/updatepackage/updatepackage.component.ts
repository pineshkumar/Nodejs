import { Component, OnDestroy, OnInit, ViewChild, TemplateRef  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { PackagesService } from '../../../_services/index';
import { MatDialog,MAT_DIALOG_DATA,MatSnackBar,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition,MatTooltip  } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector   : 'app-updatepackage',
    templateUrl: '../updatepackage/updatepackage.component.html',
    styleUrls  : ['../updatepackage/updatepackage.component.scss'],
    animations   : fuseAnimations
})
export class UpdatePackagesComponent implements OnInit, OnDestroy
{
    form: FormGroup;
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    returnUrl: string;
    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };
    
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private PackagesService: PackagesService,
        public snackBar: MatSnackBar,
        private sanitizer: DomSanitizer
        
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }

    //   toggleTemplate(): void {
    //     if (this.loadingTemplate) {
    //       this.loadingTemplate = null;
    //     } else {
    //       this.loadingTemplate = this.customLoadingTemplate;
    //     }
    //   }

    public showAlert(): void {
        alert('ngx-loading rocks!');
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Reactive Form
        this.form = this._formBuilder.group({
            packageName : ['', Validators.required],
            years  : ['', Validators.required],
            price  : ['', Validators.required],
            status:true,
            userId  : [localStorage.getItem('userId')]
        });

        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/packages';
        
        this.route.params.subscribe(params => {
            this.PackagesService.getPackagebyId(params.id)
            .subscribe(
                data => {
                
                    this.form = this._formBuilder.group({
                        
                        packageName : [data.packageName, Validators.required],
                        years  : [data.years, Validators.required],
                        price  : [data.price, Validators.required],
                        status:[data.status, Validators.required],
                        userId  : [localStorage.getItem('userId')],
                    });
                    
                   // this.router.navigate([this.returnUrl]);
                },
                error => {
                    console.log(error);
                   // this.alertService.error(error);
                });
            
           
             });

        
    }

    updatepackage() {
        this.loading = true;
        this.route.params.subscribe(params => {
            this.form.value._id = params.id;
            this.PackagesService.updatepackage(this.form.value)
                .subscribe(
                    data => {
                        this.loading = false;

                        if (data.string == 'Package Name Is Already Exist Please Enter Another Package Name!') {
                            this.snackBar.open('Package Name Is Already Exist Please Enter Another Package Name!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                        } else {
                            this.snackBar.open('Package updated successfully!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                            this.router.navigate([this.returnUrl]);
                        }
                    },
                    error => {
                        this.loading = false;
                        console.log(error);
                    });
        });
    }

    

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    
}
