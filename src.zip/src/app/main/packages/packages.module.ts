import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule,MatPaginatorModule,MatDialogModule,MatSnackBarModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';


import { PackagesComponent } from './packages.component';
import { deletePackagePopupComponent } from './packages.component';
import { AddPackagesComponent } from './addpackage/addpackage.component';
import { UpdatePackagesComponent } from './updatepackage/updatepackage.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';

const routes = [
    {
        path     : 'packages',
        component: PackagesComponent,
        canActivate: [AuthGuard]
    },
	{
        path     : 'packages/addpackage',
        component: AddPackagesComponent,
        canActivate: [AuthGuard]
    },
	{
        path     : 'packages/update/:id',
        component: UpdatePackagesComponent,
        canActivate: [AuthGuard]
    },
	{
        path     : 'packages',
        component: deletePackagePopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        PackagesComponent,
		AddPackagesComponent,
        UpdatePackagesComponent,
        deletePackagePopupComponent		],
    imports     : [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        AutofocusModule,
        NgxLoadingModule.forRoot({})
    ],
    exports     : [
        PackagesComponent,
		AddPackagesComponent,
        UpdatePackagesComponent,
        deletePackagePopupComponent
    ]
})

export class PackagesModule
{
}
