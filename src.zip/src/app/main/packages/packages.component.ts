import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { PackagesService } from '../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';

export interface PeriodicElement {
    name: string;
    price: number;
    position: number;
    Years: number;

}

@Component({
    selector: 'app-packages',
    templateUrl: './packages.component.html',
    styleUrls: ['./packages.component.scss'],
    animations: fuseAnimations
})
export class PackagesComponent implements OnInit {
    allpackages: any[];
    displayedColumns: string[] = ['name', 'price', 'Years', 'status', 'action'];
    dataSource;
    @ViewChild(MatPaginator) paginator: MatPaginator;

    applyFilter(filterValue: any) {
        this.dataSource.filter = filterValue.trim().toLowerCase();

        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }
    constructor(public dialog: MatDialog,
        private PackagesService: PackagesService) { }

    openDialog() {
        const dialogRef = this.dialog.open(DialogContentExampleDialog);

        dialogRef.afterClosed().subscribe(result => {
            console.log(`Dialog result: ${result}`);
        });
    }

    ngOnInit() {
        this.PackagesService.getAllPackages()
            .subscribe(
                data => {

                    this.allpackages = data;
                    const packages = data;
                    const allpackages = [];
                    packages.forEach(element => {

                        allpackages.push(element);
                         console.log(element)
                    });

                    this.dataSource = new MatTableDataSource(allpackages);
                    this.dataSource.paginator = this.paginator;
                },
                error => {
                    console.log(error);
                });
    }


    //   statustoggal(status,id){

    //     this.PackagesService.updatetoggle(status.checked,id)
    //     .subscribe(
    //       data => {
    //           if(data){
    //             this.snackBar.open('You cannot toggle this status as it is assigned to an company', '', {
    //                 duration: 3000,
    //                 horizontalPosition: this.horizontalPosition,
    //                 verticalPosition: this.verticalPosition,
    //             });
    //           }else{
    //             this.snackBar.open(' deleted ', '', {
    //                 duration: 5000,
    //                 horizontalPosition: this.horizontalPosition,
    //                 verticalPosition: this.verticalPosition,
    //             });

    //             this.router.navigate([this.returnUrl]);
    //           }
    //       },
    //       error => {
    //           console.log(error);
    //       });
    //       }

    dcl() {
        alert("Your Message");
    }

    statustoggal(status, id) {

        this.PackagesService.updatetoggle(status.checked, id)
            .subscribe(
                data => {

                    if (data.string == 'You cannot toggle this status as it is assigned to an company') {
                        alert('You cannot toggle this status as it is assigned to an company')
                        this.PackagesService.getAllPackages()
                        .subscribe(
                            data => {
            
                                this.allpackages = data;
                                const packages = data;
                                const allpackages = [];
                                packages.forEach(element => {
            
                                    allpackages.push(element);
                                     console.log(element)
                                });
            
                                this.dataSource = new MatTableDataSource(allpackages);
                                this.dataSource.paginator = this.paginator;
                            },
                            error => {
                                console.log(error);
                            });



                    } else {
                        alert('Toggle Success')
                    }
                },
                error => {
                    console.log(error);
                });
    }


    deletepackage(id, name) {

        let dialogRef = this.dialog.open(deletePackagePopupComponent, {
            data: {
                packageId: id,
                packageName: name
            },
            width: '450px'
        });
        dialogRef.afterClosed().subscribe(result => {
            this.PackagesService.getAllPackages()
                .subscribe(
                    data => {
                        this.allpackages = data;
                        const packages = data;
                        const allpackages = [];
                        packages.forEach(element => {

                            allpackages.push(element);

                        });
                        this.dataSource = new MatTableDataSource(allpackages);
                        this.dataSource.paginator = this.paginator;
                    },
                    error => {
                        console.log(error);
                    });
        });
    }

}

@Component({
    selector: 'deletepackage-popup',
    templateUrl: './deletepackagepopup.html'
})
export class deletePackagePopupComponent {
    returnUrl: string;
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';


    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
        private PackagesService: PackagesService,
        private route: ActivatedRoute,
        private router: Router,
        public snackBar: MatSnackBar

    ) {
        //console.log(data);

    }
    ngOnInit() {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/packages';
    }

    // else if(data.string == 'You cannot toggle this status as it is assigned to an company'){
    //     this.snackBar.open('You cannot toggle this status as it is assigned to an company','', {
    //     duration: 3000,
    //     horizontalPosition: this.horizontalPosition,
    //     verticalPosition: this.verticalPosition,
    //        });
    //   }

    delete(id, name) {

        this.PackagesService.deletePackage(id, name)
            .subscribe(
                data => {
                    if (data) {

                        this.snackBar.open('Assign another package to company then delete the package', '', {
                            duration: 3000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });
                    } else {
                        this.snackBar.open('Package deleted successfully', '', {
                            duration: 5000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });

                        this.router.navigate([this.returnUrl]);
                    }
                },
                error => {
                    console.log(error);
                    // this.alertService.error(error);
                });

    }

}
export class DialogContentExampleDialog { }
