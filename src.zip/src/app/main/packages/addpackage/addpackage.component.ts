import { Component, OnDestroy, OnInit, ViewChild, TemplateRef  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { PackagesService } from '../../../_services/index';
import { fuseAnimations } from '@fuse/animations';
import { MatDialog,MAT_DIALOG_DATA,MatSnackBar,MatSnackBarHorizontalPosition,MatSnackBarVerticalPosition,MatTooltip  } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector   : 'app-addpackage',
    templateUrl: '../addpackage/addpackage.component.html',
    styleUrls  : ['../addpackage/addpackage.component.scss'],
    animations   : fuseAnimations
})
export class AddPackagesComponent implements OnInit, OnDestroy
{
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    form: FormGroup;
    returnUrl: string;

    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };
    
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private PackagesService: PackagesService,
        private route: ActivatedRoute,
        private router: Router,
        public snackBar: MatSnackBar,
        private sanitizer: DomSanitizer
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }

    //   toggleTemplate(): void {
    //     if (this.loadingTemplate) {
    //       this.loadingTemplate = null;
    //     } else {
    //       this.loadingTemplate = this.customLoadingTemplate;
    //     }
    //   }

    public showAlert(): void {
        alert('ngx-loading rocks!');
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */

     
    ngOnInit(): void
    {
        // Reactive Form
        this.form = this._formBuilder.group({
            packageName : ['', Validators.required],
            price : ['', Validators.required],
            years  : ['', Validators.required],
            userId  : [localStorage.getItem('userId')],
            status:true
			
        });
        // console.log(localStorage.getItem('currentUser'))
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/packages';

        
    }
    
    

    addpackage(){
        this.loading = true;
 
 
        this.PackagesService.addpackage(this.form.value)
            .subscribe(
                data => {

                    this.loading = false;
                  if(data.string == "Package Name Is Already Exist Please Enter Another Package Name!") {
                    this.snackBar.open('Package name is already exist please enter another package name!', '', {
                        duration: 3000,
                        horizontalPosition: this.horizontalPosition,
                        verticalPosition: this.verticalPosition,
                    });
                  } else {
                    this.snackBar.open('Package added successfully!','', {
                        duration: 3000,
                        horizontalPosition: this.horizontalPosition,
                        verticalPosition: this.verticalPosition,
                      });
                      this.router.navigate([this.returnUrl]);
                  } 
                },
                error => {
                    this.loading = false;
                    console.log(error);
                });             
    }
9
    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    
}
