import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { fuseAnimations } from '@fuse/animations';
import { AuthService } from "angularx-social-login";
import { FacebookLoginProvider, SocialUser } from "angularx-social-login";
import { ThirdPartyIntergration } from '../../_services/index';
import { TwitterService } from 'ngx-twitter-api';

@Component({
  selector: 'app-thirdpartyintergration',
  templateUrl: './thirdpartyintergration.component.html',
  styleUrls: ['./thirdpartyintergration.component.scss'],
  animations: fuseAnimations
})
export class ThirdPartyComponent implements OnInit {
  dataSource;
  public facebookUser: SocialUser;
  private loggedIn: boolean;

  title = 'app works!';
  result = '';
  http: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  constructor(public dialog: MatDialog,
    private authService: AuthService,
    private ThirdPartyIntergration: ThirdPartyIntergration,
    private twitter: TwitterService) { }

  // signInWithGoogle(): void {
  //   this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
  // }

  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
  }

  signOut(): void {
    this.authService.signOut();
  }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit() {
    // this.dataSource.paginator = this.paginator;
  }



  getHomeTimeline() {
  
    this.twitter.get(

      'https://api.twitter.com/1.1/statuses/home_timeline.json',
      {
        count: 5
      },
      {
        consumerKey: 'LFw8Svi1jhRDr1hpGIxfJwI2d',
        consumerSecret: 'wTpGBNlHwO2ecdWLBbIeBjjGhMiC08rrtkzWQzZwY6NuWZiaet'
      },
      {
        token: '1138307218703437824-F5GpcnReHjNLo49K738lWBTtgqnoZc',
        tokenSecret: '7UG2nb6c0owzNAZWkMBCcbQOXQeyFD6MhZgX6b5mO9D20'
      }
    ).subscribe((res) => {
      console.log(res)
      // // this.result = res.json().map(tweet => tweet.text);
      // return this.http.get('http://localhost:4200/#/thirdpartyintergration')
      //   .map((res) => res.json());
      // this.http.get('http://localhost:4200/#/thirdpartyintergration')
      //   .map(res => res.json());
      // .map((res: Response) => res.json())
    });
  }


  socialSignIn() {

    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID).then((userData) => {

      this.facebookUser = userData

      var facebookObject = {
        facebookId: this.facebookUser.id,
        fullName: this.facebookUser.name,
        firstName: this.facebookUser.firstName,
        lastName: this.facebookUser.lastName,
        email: this.facebookUser.email,
        photoUrl: this.facebookUser.photoUrl,
        provider: this.facebookUser.provider,
      };


      var companyid = localStorage.getItem('userId')
      this.ThirdPartyIntergration.submitFacebookdetails(facebookObject, companyid)
        .subscribe(
          data => {

          },
          error => {

            console.log(error);
          });
    })


  }

}
export class DialogContentExampleDialog { }
