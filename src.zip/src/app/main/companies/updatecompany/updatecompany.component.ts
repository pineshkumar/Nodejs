import { Component, OnDestroy, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { CompanyService } from '../../../_services/index';
import { MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingComponent } from 'ngx-loading';
const PrimaryWhite = '#ffffff';
const SecondaryGrey = '#ccc';
const PrimaryRed = '#dd0031';
const SecondaryBlue = '#006ddd';
import { DomSanitizer } from '@angular/platform-browser';



@Component({
    selector: 'app-updatecompany',
    templateUrl: '../updatecompany/updatecompany.component.html',
    styleUrls: ['../updatecompany/updatecompany.component.scss'],
    animations: fuseAnimations
})
export class UpdateCompanyComponent implements OnInit, OnDestroy {
    form: FormGroup;
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    returnUrl: string;
    packages: string[] = [''];
    hide = true;
    @ViewChild('ngxLoading') ngxLoadingComponent: NgxLoadingComponent;
    @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
    public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
    public loading = false;
    public primaryColour = PrimaryWhite;
    public secondaryColour = SecondaryGrey;
    public coloursEnabled = false;
    public loadingTemplate: TemplateRef<any>;
    public config = { animationType: ngxLoadingAnimationTypes.none, primaryColour: this.primaryColour, secondaryColour: this.secondaryColour, tertiaryColour: this.primaryColour, backdropBorderRadius: '3px' };

    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private CompanyService: CompanyService,
        public snackBar: MatSnackBar,
        private sanitizer: DomSanitizer
    ) {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    public toggleColours(): void {
        this.coloursEnabled = !this.coloursEnabled;

        if (this.coloursEnabled) {
            this.primaryColour = PrimaryRed;
            this.secondaryColour = SecondaryBlue;
        } else {
            this.primaryColour = PrimaryWhite;
            this.secondaryColour = SecondaryGrey;
        }
    }

    //   toggleTemplate(): void {
    //     if (this.loadingTemplate) {
    //       this.loadingTemplate = null;
    //     } else {
    //       this.loadingTemplate = this.customLoadingTemplate;
    //     }
    //   }

    public showAlert(): void {
        alert('ngx-loading rocks!');
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Reactive Form
        this.form = this._formBuilder.group({
            businessName: ['', Validators.required],
            packageName: ['', Validators.required],
            domainName: ['', Validators.required],
            email: ['', Validators.required],
            userName: ['', Validators.required],
            Password: ['', [Validators.required, Validators.minLength(6)]],
            resellercode: [''],
            status: true,
            userId: [localStorage.getItem('userId')]
        });

        this.route.params.subscribe(params => {
            this.CompanyService.getAllPackages()
                .subscribe(
                    data => {
               
                        this.packages = data;
                    },
                    error => {
                        console.log(error);

                    });
            //  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/companies';
        });


        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/companies';


        this.route.params.subscribe(params => {
            this.CompanyService.getcompanybyId(params.id)
                .subscribe(
                    data => {
                       
                       

                        this.form = this._formBuilder.group({

                            businessName: [data.businessName, Validators.required],
                            packageName: [data.packageid, Validators.required],
                            domainName: [data.domainName, Validators.required],
                            email: [data.email, [Validators.required, Validators.email]],
                            userName: [data.username, Validators.required],
                            Password: [''],
                            resellercode: [data.accesscode],
                            status: [data.status, Validators.required],
                            userId: [localStorage.getItem('userId')],

                        });
                    },
                    error => {
                        console.log(error);

                    });

        });

    }


    updatecompany() {
        this.loading = true;
        this.route.params.subscribe(params => {
            this.form.value._id = params.id;
          
            this.form.value.email = this.form.value.email.toLowerCase();
            this.form.value.userName = this.form.value.userName.toLowerCase();
            this.CompanyService.updatecompany(this.form.value)
                .subscribe(
                    data => {
                        this.loading = false;
                        if (data.string == 'Email Address Is Already Exist Please Enter Another Email Address!') {
                            this.snackBar.open('Email address is already exist please enter another email address!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                        } else if (data.string == 'Business Name Is Already Exist Please Enter Another Business Name!') {
                            this.snackBar.open('Business Name Is Already Exist Please Enter Another Business Name!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                        }
                        else if (data.string == 'User Name Is Already Exist Please Enter Another User Name!') {
                            this.snackBar.open('User name is already exist please enter another user name!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                        }
                        else {
                            this.snackBar.open('Company updated successfully!', '', {
                                duration: 3000,
                                horizontalPosition: this.horizontalPosition,
                                verticalPosition: this.verticalPosition,
                            });
                            this.router.navigate([this.returnUrl]);
                        }
                    },
                    error => {
                        this.loading = false;
                        console.log(error);
                    });
        });
    }



    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


}
