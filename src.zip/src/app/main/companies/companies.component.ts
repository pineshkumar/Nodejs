import { Component, Inject, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { CompanyService } from '../../_services/index';
import { MatSnackBar, MatSnackBarHorizontalPosition, MAT_DIALOG_DATA, MatSnackBarVerticalPosition, MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';


export interface PeriodicElement {
  businessName: string;
  domainName: string;
  packageName: string;
  resellercode: string;
  date_added: string;
  date_modified: string;
  status: Boolean;
  action: string;
}



@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class CompaniesComponent implements OnInit {

  allcompanies: any[];
  displayedColumns: string[] = ['businessName', 'domainName', 'packageName', 'resellercode', 'date_added', 'date_modified', 'status', 'action'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  constructor(public dialog: MatDialog, private CompanyService: CompanyService) { }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


  ngOnInit() {

    this.CompanyService.getAllcompany()
      .subscribe(
        data => {

          this.allcompanies = data;
          const companies = data;
          const allcompanies = [];
          companies.forEach(element => {
            var date = new Date(element.dateadded);
            // element.date_added = date.toUTCString();
            element.date_added = date.toDateString();
            // console.log(element.dateadded);
            var date = new Date(element.datemodified);
            // element.date_modified = date.toUTCString();
            element.date_modified = date.toDateString();
            // console.log(element.dateadded);
            allcompanies.push(element);

          });
          this.dataSource = new MatTableDataSource(allcompanies);
          this.dataSource.paginator = this.paginator;
        },
        error => {
          console.log(error);
        });

  }

  statustoggal(status, id) {
    console.log(status.checked);
    console.log(id);
    this.CompanyService.updatetoggle(status.checked, id)
      .subscribe(
        data => {

        },
        error => {
          console.log(error);
        });
  }

  deletecompany(id, name) {
    let dialogRef = this.dialog.open(deletecompaniesPopupComponent, {
      data: {
        companyId: id,
        businessName: name

      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.CompanyService.getAllcompany()
        .subscribe(
          data => {
            this.allcompanies = data;
            const companies = data;
            const allcompanies = [];
            companies.forEach(element => {

              var date = new Date(element.dateadded);
              // element.date_added = date.toUTCString();
              element.date_added = date.toDateString();
              // console.log(element.dateadded);
              var date = new Date(element.datemodified);
              // element.date_modified = date.toUTCString();
              element.date_modified = date.toDateString();
              // console.log(element.dateadded);

              allcompanies.push(element);

            });
            this.dataSource = new MatTableDataSource(allcompanies);
            this.dataSource.paginator = this.paginator;
          },
          error => {
            console.log(error);
          });
    });
  }

}




@Component({
  selector: 'deletecompanies-popup',
  templateUrl: './deletecompaniespopup.html'
})
export class deletecompaniesPopupComponent {
  returnUrl: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private CompanyService: CompanyService,
    private route: ActivatedRoute,
    private router: Router,
    public snackBar: MatSnackBar

  ) {


  }
  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/companies';
  }

  delete(id, name) {

    this.CompanyService.deletecompany(id, name)
      .subscribe(
        data => {
          if (data) {

            this.snackBar.open('Assign another company to domain then delete the company', '', {
              duration: 3000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
          } else {
            this.snackBar.open('Companies deleted successfully', '', {
              duration: 5000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
            this.router.navigate([this.returnUrl]);
          }
        },
        error => {
          console.log(error);
          // this.alertService.error(error);
        });

  }


}
export class DialogContentExampleDialog { }
