import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatMenuModule, MatSelectModule, MatTableModule, MatTabsModule, MatPaginatorModule, MatDialogModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';
// import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
// import { MatSelectFilterModule } from 'mat-select-filter';


import { FuseSharedModule } from '@fuse/shared.module';
import { FuseSidebarModule } from '@fuse/components';
import { FuseWidgetModule } from '@fuse/components/widget/widget.module';
import { MatInputModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AutofocusModule } from 'angular-autofocus-fix';



import { CompaniesComponent } from './companies.component';
import { AddCompanyComponent } from './addcompany/addcompany.component';
import { UpdateCompanyComponent } from './updatecompany/updatecompany.component';
import { deletecompaniesPopupComponent } from './companies.component';
import { AuthGuard } from './../../_guards/index';
import { NgxLoadingModule } from 'ngx-loading';


const routes = [
    {
        path: 'companies',
        component: CompaniesComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'companies/addcompany',
        component: AddCompanyComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'companies/updatecompany/:id',
        component: UpdateCompanyComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'companies',
        component: deletecompaniesPopupComponent,
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        CompaniesComponent,
        AddCompanyComponent,
        UpdateCompanyComponent,
        deletecompaniesPopupComponent],
    imports: [
        RouterModule.forChild(routes),

        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatMenuModule,
        MatSelectModule,
        MatTableModule,
        MatTabsModule,
        MatInputModule,
        NgxChartsModule,
        MatPaginatorModule,
        MatDialogModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseWidgetModule,
        MatSlideToggleModule,
        // NgxMatSelectSearchModule,
        // MatSelectFilterModule,
        AutofocusModule,
        NgxLoadingModule.forRoot({})

    ],
    exports: [
        CompaniesComponent,
        AddCompanyComponent,
        UpdateCompanyComponent,
        deletecompaniesPopupComponent
    ]
})

export class CompaniesModule {
}
