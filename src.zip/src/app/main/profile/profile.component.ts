import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { fuseAnimations } from '@fuse/animations';
import { AuthenticationService } from '../../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatTooltip } from '@angular/material';

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss'],
    animations: fuseAnimations
})
export class ProfileComponent implements OnInit, OnDestroy {

    form: FormGroup;
    // businessCategory: number;
    lat: number;
    lng: number;
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    returnUrl: string;
    packagename:any[];
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private AuthenticationService: AuthenticationService,
        public snackBar: MatSnackBar,
    ) {
        // Set the private defaults
        this.lat = -34.397;
        this.lng = 150.644;

        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        var user = JSON.parse(localStorage.getItem('currentUser'));

        // Reactive Form
        this.form = this._formBuilder.group({
            name: [''],
            businessname: [''],
            packageName: [''],
            domainName: [''],
            email: ['', [Validators.required, Validators.email]],
            description:['', Validators.required],
            userName: [''],
            resellercode: [''],
            address: [''],
            City: [''],
            latitude: [''],
            longitude: [''],
            country: [''],
            pincode: ['', { validators: [Validators.maxLength(6), Validators.minLength(6)] }],
            primarynumber: ['', { validators: [Validators.maxLength(10), Validators.required, Validators.minLength(10)] }],
            alternativenumber: ['', { validators: [Validators.maxLength(10), Validators.minLength(10)] }],
            otherwebsite: [''],
            facebookurl: [''],
            twitterurl: [''],

        });

        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/profile';

        this.route.params.subscribe(params => {
            this.AuthenticationService.getprofileInfo(user._id)
                .subscribe(
                    data => {

                          var data = data[0];
                          const custompage = data.packages.packageName;
                          const allcustompage = [];
                          custompage.forEach(element => {   
                           if(element._id == data.packageid) {
                              
                            this.packagename = element.packageName
                           }
                            allcustompage.push(element);
                          })

                          this.form = this._formBuilder.group({

                            name: [data.firstname],
                            businessname: [data.businessName],
                            packageName: [ this.packagename],
                            domainName: [data.domainName],
                            email: [data.email, [Validators.required, Validators.email]],
                            description: [data.description],
                            userName: [data.username],
                            resellercode: [data.accesscode],
                            address: [data.address],
                            City: [data.city],
                            latitude: [data.latitude],
                            longitude: [data.longitude],
                            country: [data.country],
                            pincode: [data.pinCode, { validators: [Validators.maxLength(6), Validators.minLength(6)] }],
                            primarynumber: [data.primaryNumber, { validators: [Validators.maxLength(10), Validators.required, Validators.minLength(10)] }],
                            alternativenumber: [data.alternativeNumber, { validators: [Validators.maxLength(10), Validators.minLength(10)] }],
                            otherwebsite: [data.otherWebsite],
                            facebookurl: [data.facebookUrl],
                            twitterurl: [data.twitterUrl],

                        });
                    },
                    error => {
                        console.log(error);

                    });

        });
    }

    readLocalStorageValue(key) {
        return localStorage.getItem(key);
    }

    updateprofile() {
        var user = JSON.parse(localStorage.getItem('currentUser'));
        this.route.params.subscribe(params => {
            this.form.value._id = user._id;
           
            this.AuthenticationService.updateprofile(this.form.value)
                .subscribe(
                    data => {
                        this.snackBar.open('Profile updated successfully!', '', {
                            duration: 3000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });
                        this.router.navigate([this.returnUrl]);
                    },
                    error => {
                       
                        console.log(error);
                        this.snackBar.open('Please try again!', '', {
                            duration: 3000,
                            horizontalPosition: this.horizontalPosition,
                            verticalPosition: this.verticalPosition,
                        });
                        this.router.navigate([this.returnUrl]);

                    });
        });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


}
