import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { delay, filter, take, takeUntil } from 'rxjs/operators';

import { FuseConfigService } from '@fuse/services/config.service';
import { FuseNavigationService } from '@fuse/components/navigation/navigation.service';
import { FusePerfectScrollbarDirective } from '@fuse/directives/fuse-perfect-scrollbar/fuse-perfect-scrollbar.directive';
import { FuseSidebarService } from '@fuse/components/sidebar/sidebar.service';

@Component({
    selector     : 'navbar-vertical-style-2',
    templateUrl  : './style-2.component.html',
    styleUrls    : ['./style-2.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NavbarVerticalStyle2Component implements OnInit, OnDestroy
{
    fuseConfig: any;
    navigation: any;
    layout;
    // Private
    private _fusePerfectScrollbar: FusePerfectScrollbarDirective;
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FuseConfigService} _fuseConfigService
     * @param {FuseNavigationService} _fuseNavigationService
     * @param {FuseSidebarService} _fuseSidebarService
     * @param {Router} _router
     */
    constructor(
        private _fuseConfigService: FuseConfigService,
        private _fuseNavigationService: FuseNavigationService,
        private _fuseSidebarService: FuseSidebarService,
        private _router: Router
    )
    {

       
        // Set the private defaults
        this._unsubscribeAll = new Subject();
        var custom = [
            {
                id: 'dashboard',
                title: 'Dashboards',
                url: '/dashboard',
                type: 'item',
                icon: 'dashboard'
            },
            {
                id: 'domainrequests',
                title: 'Domain Requests',
                url: '/domainrequests',
                type: 'item',
                icon: 'domain'
            },
            {
                id: 'packages',
                title: 'Packages',
                url: '/packages',
                type: 'item',
                icon: 'card_giftcard'
            },
            {
                id: 'companies',
                title: 'Companies',
                url: '/companies',
                type: 'item',
                icon: 'work'
            },
            {
                id: 'resellers',
                title: 'Resellers',
                url: '/resellers',
                type: 'item',
                icon: 'people'
            }
        ];
        var custom2 = [
            {
                id: 'catalogue',
                title: 'Manage Catalogue',
                type: 'collapsable',
                icon: 'shopping_cart',
                children: [
                    {
                        id: 'productcategories',
                        title: 'Product Categories',
                        type: 'item',
                        url: '/catalogue/productcategories',
                    },
                    {
                        id: 'productgallery',
                        title: 'Product Galleries',
                        type: 'item',
                        url: '/catalogue/productgallery',
                    }
                ]
            },
            {
                id: 'webmanager',
                title: 'Manage Website',
                type: 'collapsable',
                icon: 'language',
                children: [
                    {
                        id: 'allupdates',
                        title: 'All Updates',
                        type: 'item',
                        url: '/webmanager/allupdates',
                    },
                    {
                        id: 'photogallery',
                        title: 'Photo Gallery',
                        type: 'item',
                        url: '/webmanager/photogallery',
                    },
                    {
                        id: 'custompages',
                        title: 'Custom Pages',
                        type: 'item',
                        url: '/webmanager/custompage',
                    },
                    {
                        id: 'siteappearance',
                        title: 'Site Appearance',
                        type: 'item',
                        url: '/webmanager/siteappearance',
                    },
                    {
                        id: 'domainandemail',
                        title: 'Domain and Email',
                        type: 'item',
                        url: '/webmanager/domainandemail',
                    }
                ]
            },
            {
                id: 'thirdpartyintergration',
                title: 'Third Party Integration',
                url: '/thirdpartyintergration',
                type: 'item',
                icon: 'insert_link'
            },
            {
                id: 'Sitehealth',
                title: 'Site Health',
                type: 'item',
                url: '/sitehealth',
                icon: 'favorite'
            },
        
            {
                id: 'settings',
                title: 'Settings',
                type: 'collapsable',
                icon: 'settings_applications',
                children: [
                    {
                        id: 'Helpandsupport',
                        title: 'Help and Support',
                        type: 'item',
                        url: '/settings/helpandsupport',
                    },
                    {
                        id: 'Finikartusage',
                        title: 'FiniKart Usage',
                        type: 'item',
                        url: '/settings/finikartusage',
                    }
                    
                    
                ]
            }
        ];

        _router.events.subscribe(
            (event) => {

                if (event instanceof NavigationEnd) {
                    
                    var custom = [
                        {
                            id: 'dashboard',
                            title: 'Dashboards',
                            url: '/dashboard',
                            type: 'item',
                            icon: 'dashboard'
                        },
                        {
                            id: 'domainrequests',
                            title: 'Domain Requests',
                            url: '/domainrequests',
                            type: 'item',
                            icon: 'domain'
                        },
                        {
                            id: 'packages',
                            title: 'Packages',
                            url: '/packages',
                            type: 'item',
                            icon: 'card_giftcard'
                        },
                        {
                            id: 'companies',
                            title: 'Companies',
                            url: '/companies',
                            type: 'item',
                            icon: 'work'
                        },
                        {
                            id: 'resellers',
                            title: 'Resellers',
                            url: '/resellers',
                            type: 'item',
                            icon: 'people'
                        },
                        {
                            id: 'settings',
                            title: 'Settings',
                            type: 'collapsable',
                            icon: 'settings_applications',
                            children: [
                                {
                                    id: 'Finikartusage',
                                    title: 'FiniKart Usage',
                                    type: 'item',
                                    url: '/settings/finikartusage',
                                }
                                
                                
                            ]
                        }
                    ];
                    var custom2 = [
                        {
                            id: 'dashboard',
                            title: 'Dashboards',
                            url: '/dashboard',
                            type: 'item',
                            icon: 'dashboard'
                        },
                        {
                            id: 'catalogue',
                            title: 'Manage Catalogue',
                            type: 'collapsable',
                            icon: 'shopping_cart',
                            children: [
                                {
                                    id: 'productcategories',
                                    title: 'Product Categories',
                                    type: 'item',
                                    url: '/catalogue/productcategories',
                                },
                                {
                                    id: 'productgallery',
                                    title: 'Product Gallery',
                                    type: 'item',
                                    url: '/catalogue/productgallery',
                                }
                            ]
                        },
                        {
                            id: 'webmanager',
                            title: 'Manage Website',
                            type: 'collapsable',
                            icon: 'language',
                            children: [
                                {
                                    id: 'allupdates',
                                    title: 'All Updates',
                                    type: 'item',
                                    url: '/webmanager/allupdates',
                                },
                                {
                                    id: 'photogallery',
                                    title: 'Photo Gallery',
                                    type: 'item',
                                    url: '/webmanager/photogallery',
                                },
                                {
                                    id: 'custompages',
                                    title: 'Custom Pages',
                                    type: 'item',
                                    url: '/webmanager/custompage',
                                },
                                {
                                    id: 'siteappearance',
                                    title: 'Site Appearance',
                                    type: 'item',
                                    url: '/webmanager/siteappearance',
                                },
                                {
                                    id: 'domainandemail',
                                    title: 'Domain and Email',
                                    type: 'item',
                                    url: '/webmanager/domainandemail',
                                }
                            ]
                        },
                        {
                            id: 'thirdpartyintergration',
                            title: 'Third Party Integration',
                            url: '/thirdpartyintergration',
                            type: 'item',
                            icon: 'insert_link'
                        },
                        {
                            id: 'Sitehealth',
                            title: 'Site Health',
                            type: 'item',
                            url: '/sitehealth',
                            icon: 'favorite'
                        },
                    
                        {
                            id: 'settings',
                            title: 'Settings',
                            type: 'collapsable',
                            icon: 'settings_applications',
                            children: [
                                {
                                    id: 'Helpandsupport',
                                    title: 'Help and Support',
                                    type: 'item',
                                    url: '/settings/helpandsupport',
                                }
                                
                                
                            ]
                        }
                    ];
                    if (localStorage.getItem('User Type')=='Super Admin') {

                        
                        this.navigation = custom;
                    } else if (localStorage.getItem('User Type')=='Company') {
                     
                        this.navigation = custom2;                        
                    }
                }
            });

        if (localStorage.getItem('User Type')=='Super Admin') {
            this.navigation = custom;
        } else if (localStorage.getItem('User Type')=='Company') {
            this.navigation = custom2;
     }
        this.layout = 'vertical';
    }

    @ViewChild(FusePerfectScrollbarDirective)
    set directive(theDirective: FusePerfectScrollbarDirective)
    {
        if ( !theDirective )
        {
            return;
        }

        this._fusePerfectScrollbar = theDirective;

        // Update the scrollbar on collapsable item toggle
        this._fuseNavigationService.onItemCollapseToggled
            .pipe(
                delay(500),
                takeUntil(this._unsubscribeAll)
            )
            .subscribe(() => {
                this._fusePerfectScrollbar.update();
            });

        // Scroll to the active item position
        this._router.events
            .pipe(
                filter((event) => event instanceof NavigationEnd),
                take(1)
            )
            .subscribe(() => {
                    setTimeout(() => {

                        const activeNavItem: any = document.querySelector('navbar .nav-link.active');

                        if ( activeNavItem )
                        {
                            const activeItemOffsetTop       = activeNavItem.offsetTop,
                                  activeItemOffsetParentTop = activeNavItem.offsetParent.offsetTop,
                                  scrollDistance            = activeItemOffsetTop - activeItemOffsetParentTop - (48 * 3);

                            this._fusePerfectScrollbar.scrollToTop(scrollDistance);
                        }
                    });
                }
            );
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    // Directive
   

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit() {
        console.log('hello');
        
        this.toggleSidebarOpened('navbar');
    }
    ngOnDestroy() {
        // if (this.fusePerfectScrollbarUpdateTimeout) {
        //     clearTimeout(this.fusePerfectScrollbarUpdateTimeout);
        // }

        // if (this.navigationServiceWatcher) {
        //     this.navigationServiceWatcher.unsubscribe();
        // }
    }

    toggleSidebarOpened(key) {
        this._fuseSidebarService.getSidebar(key).toggleOpen();
    }

    toggleSidebarFolded(key) {
        this._fuseSidebarService.getSidebar(key).toggleFold();
    }
}
