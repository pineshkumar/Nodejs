var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var storetiming = require('../controllers/storetimings/stroretimings.model');// get our mongoose model
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};

service.getmystoretiming = getmystoretiming;
service.updatestoretime = updatestoretime;
service.getAllDatatiming = getAllDatatiming;

function getAllDatatiming(id) {
    var deferred = Q.defer();
    var id = new mongoose.Types.ObjectId(id);
    storetiming.find({ companyid: id },function (err, data) {
        if (!err) {
            deferred.resolve(data);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function getmystoretiming(id) {
    var deferred = Q.defer();
    storetiming.find({ companyid: id }, function (err, storetiming) {
        if (!err) {
            deferred.resolve(storetiming);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}




function updatestoretime(storeTimingData) {
    
    var deferred = Q.defer();

    storetiming.findById(storeTimingData._id, function (err, StoreTiming) {


        // if (!err) {

        //     custompage.Name = custompagedata.Name;
        //     custompage.htmlContent = custompagedata.htmlContent;
        //     custompage.Status = custompagedata.Status;

        //     custompage.save(function (err) {
        //         if (!err) {
        //             deferred.resolve(custompage);
        //         } else {
        //             deferred.reject(err.name + ': ' + err.message);
        //         }
        //     });

        // } else {
        //     deferred.reject(err.name + ': ' + err.message);
        // }

        // var savelogs = new logs({

        //     logid: [{
        //         userid: new mongoose.Types.ObjectId(custompagedata.userId),
        //         targetid: new mongoose.Types.ObjectId(custompage._id),
        //     }],
        //     description: 'Custom Page ' + custompagedata.Name + ' Updated',
        //     action: 'Custom Page'
        // });
        // savelogs.save(function (err, logs) {
        //     if (!err) {
        //         deferred.resolve(savelogs);
        //     } else {
        //         console.log(err);
        //         deferred.reject(err.name + ': ' + err.message);
        //     }
        // });


    });



    return deferred.promise;
}

module.exports = service;