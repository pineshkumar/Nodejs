var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var users = require('../controllers/Users/users.model');// get our mongoose model
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.addagainbusinesslogo = addagainbusinesslogo;
service.getallbusinesslogo = getallbusinesslogo;
service.addBenerLogoMultiple = addBenerLogoMultiple;
service.deleteBannerarray = deleteBannerarray;

function addagainbusinesslogo(logo) {

    var deferred = Q.defer();


    if (logo.image) {
        var imageData = [];

        imageData.push({ 'url': logo.image })
        users.findOneAndUpdate({ _id: logo.userId }, {

            imagelogo: imageData,

        }, function (err, logos) {
            if (err) {
                deferred.reject(error);
                console.log('error');
            }
            else {

                deferred.resolve(logos);
            }

        });
        return deferred.promise;
    } else {
        var faviconData = [];
        faviconData.push({ 'url': logo.faviconimage })
        users.findOneAndUpdate({ _id: logo.userId }, {


            faviconlogo: faviconData
        }, function (err, logos) {
            if (err) {
                deferred.reject(error);
                console.log('error');
            }
            else {

                deferred.resolve(logos);
            }

        });
        return deferred.promise;

    }

}



function getallbusinesslogo(userId) {

    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(userId);

    users.find({ _id: userId }, function (err, logos) {
        if (!err) {
            deferred.resolve(logos);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ dateadded: -1 });
    return deferred.promise;

}




function addBenerLogoMultiple(logo) {
    var deferred = Q.defer();


    users.findOne({ _id: logo.userId }, function (err, thisData) {
    
        if (thisData.bannerImage.length) {
         
            var bannerData = [];

            if (logo.bannerImage) {
                for (let i = 0; i < logo.bannerImage.length; i++) {
                    bannerData.push({ 'url': logo.bannerImage[i] })
                }
            }
           
            users.findOneAndUpdate({ _id: logo.userId },
                {

                    $push: {
                        bannerImage: bannerData
                    }

                    //bannerImage: bannerData
                }, function (err, Photogallery) {

                    if (err) {
                        console.log(err)
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else {
                        deferred.resolve(Photogallery);
                    }
                });

        } else {

           
            var bannerData = [];

            for (let i = 0; i < logo.bannerImage.length; i++) {
                bannerData.push({ 'url': logo.bannerImage[i] })
            }
            users.findOneAndUpdate({ _id: logo.userId },
                {
                    bannerImage: bannerData
                }, function (err, Photogallery) {

                    if (err) {
                        console.log(err)
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else {
                        deferred.resolve(Photogallery);
                    }
                });

        }

    });



    return deferred.promise;
}




function deleteBannerarray(bennerId) {

    var MainId = new mongoose.Types.ObjectId(bennerId.maindata);
    var LogoId = new mongoose.Types.ObjectId(bennerId.imagedata);

    var deferred = Q.defer();

    users.findOne({ _id: MainId }).then(function (getData) {

        getData.bannerImage.pull({ _id: LogoId });
        getData.save().then(function (err,getData) {
            //do something smart
            if (!err) {              
                deferred.resolve(getData);
            }
            else
            {
                deferred.reject(err);
            }
        });
    });


    return deferred.promise;
}


module.exports = service;

