var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var siteappearance = require('../controllers/siteappearance/siteappearance.model');// get our mongoose model
var users = require('../controllers/Users/users.model')
var mongoose = require('mongoose');
var productsgallery = require('../controllers/productgallery/productgallery.model');
var productcategories = require('../controllers/productcategories/productcategories.model')
var querys = require('../controllers/query/querys.model')
var allupdates = require('../controllers/allupdates/allupdates.model');
var Gallery = require('../controllers/photogallery/photogallery.model');
var user = require('../controllers/Users/users.model')
var banknotes = require ('../controllers/currency/currency.model')
var service = {};

service.getallproducts = getallproducts;

service.getReservedBusinessName = getReservedBusinessName;
// service.addcontactdetail = addcontactdetail;
service.getproduct = getproduct;
service.addquerydetail = addquerydetail;
service.getproductcategorieslist = getproductcategorieslist;
service.getselectproductlist = getselectproductlist;
service.getupdatesproductslist = getupdatesproductslist;
service.getupdateproduct = getupdateproduct;
service.getgallerylist = getgallerylist;
service.updateproductvalue = updateproductvalue;
service.updateallproductvalue = updateallproductvalue;
service.getlogos = getlogos;
service.gethomegallerylist = gethomegallerylist;
service.gethomeupdatesproductslist = gethomeupdatesproductslist;
service.gethomeselectproductlist = gethomeselectproductlist;
service.gethomeproductslist = gethomeproductslist;

service.gethomepagebanner = gethomepagebanner;
service.gethomepageagainproductslist = gethomepageagainproductslist;
service.getagainupdatesproductslist = getagainupdatesproductslist;
service.getagainproductlist = getagainproductlist;


function getallproducts(companyid) {
    var deferred = Q.defer();


    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(companyid);
    productsgallery.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },
            {
                $lookup: {
                    from: "banknotes",
                    localField: "currencynameid",
                    foreignField: "_id",
                    as: "currencyname"
                }   
            },
       
        { $sort: { dateadded: -1 } }]).exec(function (err, allproducts) {

            if (!err) {

                deferred.resolve(allproducts);
            } else {
               
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}

function getReservedBusinessName(usersid) {

    var deferred = Q.defer();
    users.find({ _id: usersid }, function (err, getName) {

        if (!err) {
            deferred.resolve(getName);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function getproduct(productid) {
    // console.log('id');
    //  console.log(productid);
    var deferred = Q.defer();
    var proid = new mongoose.Types.ObjectId(productid);
    productsgallery.aggregate([
        { "$match": { "_id": proid } },
        { $unwind: '$image' },
         { $match: { 'image.checkbox': 'true' } },

         { 
            $lookup: {
                from: "productcategories",
                localField: "catNameid" ,
                foreignField: "_id",
                as: "catName"
            }
           
        },

        { $sort: { dateadded: -1 } }]).exec(function (err, product) {

            if (!err) {


                deferred.resolve(product);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;
}



function addquerydetail(detail) {
    var deferred = Q.defer();
    var savequerys = new querys({
        companyid: new mongoose.Types.ObjectId(detail.companyid),
        productid: new mongoose.Types.ObjectId(detail.productid),
        message: detail.Message,
        email: detail.email,
    });
    savequerys.save(function (err, savequerys) {
        if (!err) {
            deferred.resolve(savequerys);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })

    return deferred.promise;

}



function getproductcategorieslist(companyid) {


    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(companyid);
    productsgallery.distinct("catNameid", { companyid: userId }, function (err, productcategoryArray) {

        if (!err) {
          
            productcategories.find({ companyid: userId ,'_id' : {'$in' : productcategoryArray}}, function (err, productcategoryList) {

                if (!err) {
                    
                    deferred.resolve(productcategoryList);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
            })
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })

    return deferred.promise;
}



function getselectproductlist(productid) {


    var deferred = Q.defer();

    var productid = new mongoose.Types.ObjectId(productid);
    productsgallery.aggregate([
        { "$match": { "catNameid": productid } },
        { $unwind: '$image' },


        { $sort: { dateadded: -1 } }]).exec(function (err, selectproducts) {

            if (!err) {


                deferred.resolve(selectproducts);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;
}


function getupdatesproductslist(companyid) {
    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(companyid);
    allupdates.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },

        { $sort: { dateadded: -1 } }]).exec(function (err, Productlist) {

            if (!err) {


                deferred.resolve(Productlist);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;


}



function getupdateproduct(productid) {

    var deferred = Q.defer();

    var proid = new mongoose.Types.ObjectId(productid);
    allupdates.aggregate([
        { "$match": { "_id": proid } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },

        { $sort: { dateadded: -1 } }]).exec(function (err, UpdateProduct) {

            if (!err) {


                deferred.resolve(UpdateProduct);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}


function getgallerylist(userId) {
    var deferred = Q.defer();
    Gallery.find({ userId: userId }, function (err, gallerylist) {

        if (!err) {
            deferred.resolve(gallerylist);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function updateproductvalue(count, id) {

    var view = count + 1

    var deferred = Q.defer();
    productsgallery.findOneAndUpdate({ _id: id },
        {

            view: view

        }, function (err, products) {

            if (!err) {


                //  deferred.resolve(products);
                var currencynameid = new mongoose.Types.ObjectId(products.currencynameid);
                banknotes.aggregate([
                    { "$match": { "_id": currencynameid } },
                   
                    { $sort: { dateadded: -1 } }]).exec(function (err, currencyname) {
            
                        if (!err) {
                           
                             var singleproducts = currencyname.concat(products);
                            
                             deferred.resolve(singleproducts);
                       
                            } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });
                return deferred.promise;


            } else {

                deferred.reject(err.name + ': ' + err.message);
            }
        })
    return deferred.promise;

    // var deferred = Q.defer();

    // var proid = new mongoose.Types.ObjectId(id);
    // productsgallery.aggregate([
    //     { "$match": { "_id": proid } },
    //     // { $unwind: '$image' },
    //     // { $match: { 'image.checkbox': 'true' } },
    //     {$match:{"view":view}},
    //     { $sort: { dateadded: -1 } }]).exec(function (err, product) {

    //         if (!err) {


    //             deferred.resolve(product);
    //         } else {
    //             console.log(err);
    //             deferred.reject(err.name + ': ' + err.message);
    //         }
    //     });
    // return deferred.promise;
}




function updateallproductvalue(count, id) {
    var view = count + 1
    var deferred = Q.defer();

    allupdates.findOneAndUpdate({ _id: id },
        {
            view: view
        }, function (err, UpdatesProducts) {
            if (!err) {

                deferred.resolve(UpdatesProducts);
            } else {

                deferred.reject(err.name + ': ' + err.message);
            }
        })
    return deferred.promise;
}


function getlogos(userId) {

    var userId = new mongoose.Types.ObjectId(userId);
    var deferred = Q.defer();
    user.find({ _id: userId }, function (err, logos) {

        if (!err) {

            deferred.resolve(logos);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;



}



function gethomegallerylist(userId) {


    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(userId);
    Gallery.aggregate([
        {
            '$match': {
                'userId': userId
            }
        },
        { '$unwind': '$image' },
        {
            '$sort': {
                'image.dateadded': -1
            }
        }, {
            '$group': {
                '_id': null,
                'image': {
                    '$push': '$image'
                }
            }
        },
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 8] },
                'totalImages': { '$size': '$image' }
            }
        },

        { $sort: { dateadded: -1 } }]).exec(function (err, gallerylist) {

            if (!err) {
                 

                deferred.resolve(gallerylist);
               
            } else {
               
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;


}



function gethomeupdatesproductslist(companyid) {
    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(companyid);
    allupdates.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },
        {
            '$sort': {
                'image.dateadded': -1
                     }
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        'message': '$message',
                        'view':'$view',
                        'images': '$image'
                    }
                }
            }
        },
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 8] },
                'totalImages': { '$size': '$image' }
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, productsgallery) {

            if (!err) {


                deferred.resolve(productsgallery);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;
}



function gethomeselectproductlist(productid) {

    var deferred = Q.defer();

    var productid = new mongoose.Types.ObjectId(productid);
    productsgallery.aggregate([
        { "$match": { "catNameid": productid } },
        { $unwind: '$image' },
        {
            '$sort': {
                'image.dateadded': -1
            }
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        'proName': '$proName',
                        'images': '$image'
                    }
                }
            }
        },
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 8] },
                'totalImages': { '$size': '$image' }
            }
        },

        { $sort: { dateadded: -1 } }]).exec(function (err, productsgallery) {

            if (!err) {


                deferred.resolve(productsgallery);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;



}


function gethomeproductslist(companyid) {
   

    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(companyid);
    productsgallery.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        
        { $match: { 'image.checkbox': 'true' } },
       
        {
            '$sort': {
                'image.dateadded': -1
            }
        },
        { 
            $lookup: {
                from: "banknotes",
                localField: "currencynameid" ,
                foreignField: "_id",
                as: "currencynameDetails.currencyname"
            }
           
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        'companyid' : '$companyid',
                        'productprice':'$productprice',
                        'proName': '$proName',
                        'description':'$description',
                        'view':'$view',
                        'dateadded':'$dateadded',
                        'catNameid' : '$catNameid',
                        'currencynameid':'$currencynameid',
                        'currencyname':'$currencynameDetails.currencyname',
                        'images': '$image'
                    }  
                }
                
            },
        },
        
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 8] },
                'totalImages': { '$size': '$image' }
            }
        },
        
        
        { $sort: { dateadded: -1 } }]).exec(function (err, Productlist) {

            if (!err) {

                deferred.resolve(Productlist);
            } else {
                console.log('errrrr');
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;
}



function gethomepagebanner(userId) {
  
    var userId = new mongoose.Types.ObjectId(userId);
    var deferred = Q.defer();
    
    user.find({ _id: userId }, function (err, banner) {

        if (!err) {

            deferred.resolve(banner);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;
}



function gethomepageagainproductslist(companyid) {
     
   
    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(companyid);
    productsgallery.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },
        {
            '$sort': {
                'image.dateadded': -1
            }
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        // 'companyid' : '$companyid',
                        // 'proName': '$proName',
                        // 'description':'$description',
                        // 'view':'$view',
                        // 'dateadded':'$dateadded',
                        'images': '$image'
                    }
                }
            }
        },
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 2] },
                'totalImages': { '$size': '$image' }
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, againproduct) {

            if (!err) {

                deferred.resolve(againproduct);
            } else {
                console.log('errrrr');
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}


function getagainupdatesproductslist(companyid) {
    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(companyid);
    allupdates.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
         { $match: { 'image.checkbox': 'true' } },
        {
            '$sort': {
                'image.dateadded': -1
            }
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        'message' : '$message',
                        // 'productprice':'$productprice',
                        // 'proName': '$proName',
                        // 'description':'$description',
                        'view':'$view',
                        // 'dateadded':'$dateadded',
                        'images': '$image'
                    }
                }
            }
        },
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 4] },
                'totalImages': { '$size': '$image' }
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, updateproductsgallery) {

            if (!err) {

                deferred.resolve(updateproductsgallery);
            } else {
                console.log('errrrr');
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}


function getagainproductlist(catNameid , productid) {



    
    var deferred = Q.defer();
    var id = new mongoose.Types.ObjectId(catNameid);
    productsgallery.aggregate([
        // { _id: { $ne: productid } },
        { "$match": { "catNameid": id } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },
       
        // {
        //     '$sort': {
        //         'image.dateadded': -1
        //     }
        // },
        { 
            $lookup: {
                from: "banknotes",
                localField: "currencynameid" ,
                foreignField: "_id",
                as: "currencynameDetails.currencyname"
            }
           
        },
        {
            '$group': {
                '_id': null,
                'image': {
                    '$push': {
                        '_id' : '$_id',
                        'companyid' : '$companyid',
                        'productprice':'$productprice',
                        'proName': '$proName',
                        'description':'$description',
                        'view':'$view',
                        'dateadded':'$dateadded',
                        'currencynameid':'$currencynameid',
                        'currencyname':'$currencynameDetails.currencyname',
                        'catNameid' : '$catNameid',
                        'images': '$image'
                    }

                    
                }
                
            }
        },
        
        {
            '$project': {
                'images': { '$slice': ['$image', 0, 4] },
                'totalImages': { '$size': '$image' }
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, Productlist) {

            if (!err) {

                deferred.resolve(Productlist);
            } else {
                console.log('errrrr');
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;
    

}

module.exports = service;