﻿var config = require('../config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var Users = require('../controllers/Users/users.model');// get our mongoose model
var packages = require('../controllers/packages/packages.model');

var mongoose = require('mongoose');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.authenticate = authenticate;
service.getprofileInfo = getprofileInfo;
service.updateprofile = updateprofile;

function authenticate(username, password) {

    var deferred = Q.defer();
    Users.findOne({
        $and: [
            { $or: [{ "email": username }, { "username": username }] },
        ]
    }
        , function (err, user) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }

            if (user && bcrypt.compareSync(password, user.password)) {

                if (user.status == true) {
                    deferred.resolve({
                        _id: user._id,
                        email: user.email,
                        userType: user.userType,
                        username: user.username,
                        token: jwt.sign({ sub: user._id }, config.secret)
                    });

                } else {

                    var data = {};
                    data.string = 'You Cannot Logged In As Your Status Is Off!';

                    deferred.resolve(data);

                }

            } else {

                deferred.resolve();
            }
        });

    return deferred.promise;

}

function getprofileInfo(loginId) {

//    console.log('loginID');
//    console.log(loginId);

    var deferred = Q.defer();
    var loginId = new mongoose.Types.ObjectId(loginId);

    // Users.findOne(loginId, function (err, user) {
    //     if (!err) {
    //         deferred.resolve(user);
    //         console.log('users');
    //         console.log(user);
    //     } else {
    //         deferred.reject(err.name + ': ' + err.message);
    //     }
    // });
    // return deferred.promise;
    Users.aggregate([
        { "$match":{ "$and": [{ "_id": loginId }] }},
        
     
        {
            
  $lookup: {
      
    from: "packages",
    localField: "packages.packageid",
    foreignField: "packageid",
    as: "packages.packageName",
    
  }
  },
       { $sort : { createddate : -1 } }]).exec(function (err, companies) {
        if (!err) {
            deferred.resolve(companies);
        } else {
            console.log('err');
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}

function updateprofile(profiledata) {
   
    var deferred = Q.defer();

    Users.findById(profiledata._id, function (err, users) {
       
        if (!err) {
            users.firstname = profiledata.name;
            users.businessName = profiledata.businessname;
            // users.packageid = profiledata.packageName;
            users.description = profiledata.description;
            users.domainName = profiledata.domainName;
            users.email = profiledata.email;
            users.username = profiledata.userName;
            users.accesscode = profiledata.resellercode;
            users.address = profiledata.address;
            users.city = profiledata.City;
            users.latitude = profiledata.latitude;
            users.longitude = profiledata.longitude;
            users.country = profiledata.country;
            users.pinCode = profiledata.pincode;
            users.primaryNumber = profiledata.primarynumber;
            users.alternativeNumber = profiledata.alternativenumber;
            users.otherWebsite = profiledata.otherwebsite;
            users.facebookUrl = profiledata.facebookurl;
            users.twitterUrl = profiledata.twitterurl;
            users.date_modified = Date.now();

            users.save(function (err) {
                if (!err) {
                    deferred.resolve(users);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;
}

module.exports = service;
