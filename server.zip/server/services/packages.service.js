﻿var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var packages = require('../controllers/packages/packages.model');// get our mongoose model
var companies = require('../controllers/Users/users.model');
var logs = require('../controllers/logs/logs.model');
var mongoose = require('mongoose');
var nodemailer = require('nodemailer');
var sesTransport = require('nodemailer-ses-transport');
var smtpPassword = require('aws-smtp-credentials');
var AWS = require('aws-sdk');
AWS.config.update({ accessKeyId: 'AKIAJDASXIM5S7ELYWWQ', secretAccessKey: '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', region: 'us-east-1' });
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.addpackage = addpackage;
service.getAllPackages = getAllPackages;
service.getPackagebyId = getPackagebyId;
service.updatepackage = updatepackage;
service.updatetoggle = updatetoggle;
service.deletepackage = deletepackage;


//   function callback(error, info) {
//     if (error) {
//       console.log(error);
//     } else {
//       console.log('Message sent: ' + info.response);
//     }
//   }

function addpackage(packagedata) {
    // console.log(packagedata);
    var deferred = Q.defer();
    var pkg = new RegExp("^" + packagedata.packageName + "$", "i")
    packages.find({ packageName: pkg }, function (err, companiesget) {

        if (companiesget.length > 0) {
            var data = {};
            data.string = 'Package Name Is Already Exist Please Enter Another Package Name!';


            deferred.resolve(data);

        } else {

            var savePackage = new packages({

                packageName: packagedata.packageName,
                price: packagedata.price,
                years: packagedata.years,
                status: packagedata.status
            });

            savePackage.save(function (err, savePackage) {
                if (!err) {
                    deferred.resolve(savePackage);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(packagedata.userId),
                        targetid: new mongoose.Types.ObjectId(savePackage._id),
                    }],

                    description: 'Package ' + packagedata.packageName + ' Added',
                    action: 'Add'
                });

                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });
            });
            return deferred.promise;

        }
    });
    return deferred.promise;

}

function getAllPackages() {
    var deferred = Q.defer();

    // Verify email address in SES, Don't remove -----

    // var verifyEmailPromise = new AWS.SES({apiVersion: '2010-12-01'}).verifyEmailIdentity({EmailAddress: "swatisuthar@finlitetech.com"}).promise();
    // verifyEmailPromise.then(
    //     function(data) {
    //       console.log("Email verification initiated");
    //      }).catch(
    //       function(err) {
    //       console.error(err, err.stack);
    //     });

    //  mailOptions.subject = 'Nodemailer SES transporter';

    //Send e-mail using SMTP, Don't remove -----

    // var mailOptions = {
    //     from: 'admin@finikart.com',
    //     to: 'swatisuthar1494@gmail.com,swatisuthar@finlitetech.com',
    //     text: 'This is some text',
    //     html: '<b>This is some HTML</b>',
    //   };

    // mailOptions.subject = 'Nodemailer SMTP transporter';
    // var smtpTransporter = nodemailer.createTransport({
    // port: 465,
    // host: 'email-smtp.us-east-1.amazonaws.com',
    // secure: true,
    // auth: {
    //     user: 'AKIAJDASXIM5S7ELYWWQ',
    //     pass: smtpPassword('UvXNHbCMRcDVlHOjZjjsncDg90LNmjYmqbIvUqoL'),
    // },
    // debug: true
    // });

    // smtpTransporter.sendMail(mailOptions, callback);

    packages.find(function (err, packages) {
        if (!err) {
            deferred.resolve(packages);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ date_added: -1 });
    return deferred.promise;

}

function getPackagebyId(packageId) {
    var deferred = Q.defer();
    var PackageId = new mongoose.Types.ObjectId(packageId);

    packages.findOne(PackageId, function (err, packages) {
        if (!err) {
            deferred.resolve(packages);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}

function updatepackage(packagedata) {
    var deferred = Q.defer();
    var pkg = new RegExp("^" + packagedata.packageName + "$", "i")
    packages.find({ $and: [{ packageName: pkg }, { _id: { $ne: packagedata._id } }] }, function (err, getpackages) {


        if (getpackages.length > 0) {
            var data = {};
            data.string = 'Package Name Is Already Exist Please Enter Another Package Name!';
            deferred.resolve(data);
        }
        else {

            packages.findById(packagedata._id, function (err, packages) {
                if (!err) {

                    packages.packageName = packagedata.packageName;
                    packages.price = packagedata.price;
                    packages.years = packagedata.years;
                    packages.status = packagedata.status;
                    packages.date_modified = Date.now();

                    packages.save(function (err) {
                        if (!err) {
                            deferred.resolve(packages);
                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(packagedata.userId),
                        targetid: new mongoose.Types.ObjectId(packages._id),
                    }],
                    description: 'Package ' + packagedata.packageName + ' Updated',
                    action: 'Package'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            });

        }
    });

    return deferred.promise;
}


function updatetoggle(packagedata) {

    var packagecompanyid = new mongoose.Types.ObjectId(packagedata.id);

    var deferred = Q.defer();
    companies.find({ packageid: packagecompanyid }, function (err, companiesget) {

        if (companiesget.length > 0) {
            var data = {};
            data.string = 'You cannot toggle this status as it is assigned to an company';
            deferred.resolve(data);
        } else {
            packages.findById(packagedata.id, function (err, packages) {
                if (!err) {
                    packages.status = packagedata.status;
                    packages.date_modified = Date.now();

                    packages.save(function (err) {
                        if (!err) {
                            deferred.resolve(packages);

                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(packagedata.userId),
                        targetid: new mongoose.Types.ObjectId(packages._id),
                    }],
                    description: 'Status ' + packagedata.status + ' Updated',
                    action: 'Package'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            });

        }
    })
    return deferred.promise;
}


function deletepackage(packageId, userId, name) {


    var packagecompanyid = new mongoose.Types.ObjectId(packageId);
    var deferred = Q.defer();
    companies.find({ packageid: packagecompanyid }, function (err, companiesget) {
        //   console.log(companiesget.length);

        if (companiesget.length > 0) {
            var data = {};
            data.string = 'Assign another package to company then delete the package';
            deferred.resolve(data);

        } else {
            var savelogs = new logs({

                logid: [{
                    userid: new mongoose.Types.ObjectId(userId),
                    targetid: new mongoose.Types.ObjectId(packageId._id),
                }],
                description: 'Packages ' + name + ' Deleted',
                action: 'Delete'
            });
            savelogs.save(function (err, logs) {
                if (!err) {
                    deferred.resolve(savelogs);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

            packages.deleteOne(
                { _id: new mongoose.Types.ObjectId(packageId) },
                function (err) {
                    if (err) {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else {
                        var data = {};
                        data.string = 'Package deleted successfully';
                        deferred.resolve();
                    }
                });
        }
    });
    return deferred.promise;

}

module.exports = service;
