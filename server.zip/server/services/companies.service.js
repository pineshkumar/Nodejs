﻿var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var logs = require('../controllers/logs/logs.model');
var productcategories = require('../controllers/productcategories/productcategories.model');
var companies = require('../controllers/Users/users.model');
var domains = require('../controllers/domains/domains.model');// get our mongoose model
var resellers = require('../controllers/resellers/resellers.model');
var packages = require('../controllers/packages/packages.model');
var productgallery = require('../controllers/productgallery/productgallery.model');
var currency = require('../controllers/currency/currency.model');
var siteappearance = require('../controllers/siteappearance/siteappearance.model');// get our mongoose model
var subscriber = require('../controllers/subscriber/subscriber.model');
var store = require('../controllers/storetimings/stroretimings.model')


var fs = require('fs');


// var nodemailer = require('nodemailer');
// var sesTransport = require('nodemailer-ses-transport');
// var smtpPassword = require('aws-smtp-credentials');
var nodemailer = require('nodemailer');

var mongoose = require('mongoose');
var fs = require('file-system');
var AWS = require('aws-sdk');
// var express = require('express');
// var router = express.Router();
var multer = require('multer');
const sharp = require('sharp');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');
var upload = multer({//multer settings
    //  storage: storage
});
var service = {};


service.addcompany = addcompany;
service.getAllcompany = getAllcompany;
service.getcompanybyId = getcompanybyId;
service.updatecompany = updatecompany;
service.updatetoggle = updatetoggle;
service.updatetoggleone = updatetoggleone;
service.deletecompany = deletecompany;

service.getAllPackages = getAllPackages;
service.addagaingallery = addagaingallery;

service.addproductcategories = addproductcategories;
service.getAllproductcategories = getAllproductcategories;
service.getproductcategoriesbyId = getproductcategoriesbyId;
service.updateproductcategories = updateproductcategories;
service.deleteproductcategories = deleteproductcategories;

service.filtercategory = filtercategory;
service.getAllproductgallery = getAllproductgallery;
service.getproductgallerybyId = getproductgallerybyId;
service.updateagainproductgallery = updateagainproductgallery;
service.deletearray = deletearray;
service.deleteproductgallery = deleteproductgallery;

// service.getproductname = getproductname;
service.getproductcategories = getproductcategories;
service.getcurrencyname = getcurrencyname;
service.getthemebyID = getthemebyID;

service.Statusupdatetoggle = Statusupdatetoggle;
service.onAPPupdatetoggle = onAPPupdatetoggle;
service.onwebupdatetoggle = onwebupdatetoggle;
service.productgalleryimagestatus = productgalleryimagestatus


// function callback(error, info) {
//     if (error) {
//         console.log(error);
//     } else {
//         console.log('Message sent: ' + info.response);
//     }
// }

// var transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//            user: 'swatisuthar1494@gmail.com',
//            pass: 'swati1494'
//        }
//    });

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'swatisuthar1494@gmail.com',
        pass: 'swati1494'
    }
});

function getthemebyID() {
    var deferred = Q.defer();


    siteappearance.findOne(function (err, gettheme) {

        if (!err) {
            deferred.resolve(gettheme);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}



function addcompany(companydata) {

    var deferred = Q.defer();

    var cmpemail = new RegExp("^" + companydata.email + "$", "i")
    companies.find({ email: cmpemail }, function (err, companiesget) {


        if (companiesget.length > 0) {

            var data = {};
            data.string = 'Email Address Is Already Exist Please Enter Another Email Address!';
            deferred.resolve(data);

        } else if (companydata.userName) {
            var cmpUname = new RegExp("^" + companydata.userName + "$", "i")
            companies.find({ username: cmpUname }, function (err, companiesget) {
                if (companiesget.length > 0) {
                    var data = {};
                    data.string = 'User Name Is Already Exist Please Enter Another User Name!';
                    deferred.resolve(data);
                } else if (companydata.businessName) {
                    var cmpbusinessName = new RegExp("^" + companydata.businessName + "$", "i")
                    companies.find({ businessName: cmpbusinessName }, function (err, companiesget) {
                        if (companiesget.length > 0) {
                            var data = {};
                            data.string = 'Business Name Is Already Exist Please Enter Another Business Name!';
                            deferred.resolve(data);
                        }
                        else {
                            var hashUserPassword = bcrypt.hashSync(companydata.Password, 10);
                            var savecompany = new companies({

                                businessName: companydata.businessName,
                                packageid: new mongoose.Types.ObjectId(companydata.packageName),
                                themeid: new mongoose.Types.ObjectId(companydata.themeid),
                                domainName: companydata.domainName,
                                email: companydata.email,
                                username: companydata.userName,
                                password: hashUserPassword,
                                accesscode: companydata.resellercode,
                                userType: 'Company',
                                status: companydata.status,
                            });


                            if (companydata.resellercode) {
                                resellers.find({ accesscode: companydata.resellercode }, function (err, resellersget) {

                                    if (resellersget.length > 0) {

                                        savecompany.save(function (err, savecompany) {
                                            if (!err) {
                                                deferred.resolve(savecompany);
                                            } else {
                                                console.log('err');
                                                deferred.reject(err.name + ': ' + err.message);
                                            }

                                            var savelogs = new logs({

                                                logid: [{
                                                    userid: new mongoose.Types.ObjectId(companydata.userId),
                                                    targetid: new mongoose.Types.ObjectId(savecompany._id),
                                                }],
                                                description: 'Company ' + companydata.businessName + ' Added',
                                                action: 'Add'
                                            });
                                            savelogs.save(function (err, logs) {
                                                if (!err) {
                                                    deferred.resolve(savelogs);
                                                } else {
                                                    console.log(err);
                                                    deferred.reject(err.name + ': ' + err.message);
                                                }
                                            });

                                            var savestoretiming = new store({
                                                companyid: savecompany._id,
                                                days: [
                                                    {
                                                        day: 'Monday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    }, {

                                                        day: 'Tuesday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    },
                                                    {
                                                        day: 'Wednesday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    },
                                                    {
                                                        day: 'Thursday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    }, {
                                                        day: 'Friday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    },
                                                    {
                                                        day: 'Saturday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    },
                                                    {
                                                        day: 'Sunday',
                                                        status: 'true',
                                                        openingtime: '09:00 AM',
                                                        closingtime: '06:00 PM',

                                                    }

                                                ],


                                            });
                                            savestoretiming.save(function (err, logs) {
                                                if (!err) {
                                                    deferred.resolve(savestoretiming);
                                                } else {
                                                    console.log(err);
                                                    deferred.reject(err.name + ': ' + err.message);
                                                }
                                            });




                                        });
                                    } else {
                                        var data = {};
                                        data.string = 'Enter correct access code';
                                        deferred.resolve(data);
                                    }
                                });
                            }
                            else {

                                var data = {};
                                data.string = '';

                                savecompany.save(function (err, savecompany) {
                                    if (!err) {
                                        deferred.resolve(savecompany);
                                    } else {
                                        console.log('err');
                                        deferred.reject(err.name + ': ' + err.message);
                                    }

                                    var savelogs = new logs({

                                        logid: [{
                                            userid: new mongoose.Types.ObjectId(companydata.userId),
                                            targetid: new mongoose.Types.ObjectId(savecompany._id),
                                        }],
                                        description: 'Company ' + companydata.businessName + ' Added',
                                        action: 'Add'
                                    });
                                    savelogs.save(function (err, logs) {
                                        if (!err) {
                                            deferred.resolve(savelogs);
                                        } else {
                                            console.log(err);
                                            deferred.reject(err.name + ': ' + err.message);
                                        }
                                    });
                                });
                            }

                        }
                    })
                }
            })
        }

    }).sort({ dateadded: -1 });
    return deferred.promise;

}


function addproductcategories(productcategoriesdata) {
    var deferred = Q.defer();
    var saveproductcategories = new productcategories({
        catName: productcategoriesdata.catName,
        description: productcategoriesdata.description,
        status: productcategoriesdata.status,
        companyid: new mongoose.Types.ObjectId(productcategoriesdata.companyid),
    });

    var catName = new RegExp("^" + productcategoriesdata.catName + "$", "i")
    productcategories.find({ catName: catName }, function (err, companiesget) {

        if (companiesget.length > 0) {
            var data = {};
            data.string = 'Product name is already exist please enter another product name!';


            deferred.resolve(data);

        } else {

            saveproductcategories.save(function (err, saveproductcategories) {
                if (!err) {

                    deferred.resolve(saveproductcategories);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(productcategoriesdata.userId),
                        targetid: new mongoose.Types.ObjectId(saveproductcategories._id),
                    }],
                    description: 'Productcategory ' + productcategoriesdata.catName + ' Added',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });

            });
            return deferred.promise;
        }
    });
    return deferred.promise;

}


function addagaingallery(productgallerydata) {

    var imageData = [];
    for (let i = 0; i < productgallerydata.image.length; i++) {
        imageData.push({ 'url': productgallerydata.image[i].s3url, 'checkbox': productgallerydata.image[i].checkbox })
    }
    //return false;
    var deferred = Q.defer();
    var proName = new RegExp("^" + productgallerydata.proName + "$", "i")
    productgallery.find({ proName: proName}, function (err, companiesget) {

        if (companiesget.length > 0) {
            var data = {};
            data.string = 'Proname Is Already Exist Please Enter Another Proname Name!';

            deferred.resolve(data);

        } else {


            var saveagaingallery = new productgallery({

                image: productgallerydata.checkboxtoggle == true ? [] : imageData,
                youtube: productgallerydata.checkboxtoggle == false ? '' : productgallerydata.youtube,
                companyid: new mongoose.Types.ObjectId(productgallerydata.companyid),
                catNameid: new mongoose.Types.ObjectId(productgallerydata.catName),
                proName: productgallerydata.proName,
                customerlist: productgallerydata.customerlist,
                description: productgallerydata.description,
                currencynameid: new mongoose.Types.ObjectId(productgallerydata.currencyname),
                productprice: productgallerydata.productprice,
                discountprice: productgallerydata.discountprice,
                shippingcharge: productgallerydata.freeshipping == true ? '' : productgallerydata.shippingcharge,
                transactionprice: productgallerydata.transactionprice,
                netamount: productgallerydata.netamount,
                onlinelink: productgallerydata.onlinelink,
                priority: productgallerydata.priority,
                onweb: productgallerydata.onweb,
                onapp: productgallerydata.onapp,
                productavailability: productgallerydata.productavailability,
                freeshipping: productgallerydata.freeshipping,
                facebook: productgallerydata.facebook,
                checkboxtoggle: productgallerydata.checkboxtoggle,
                twitter: productgallerydata.twitter,
                subscribe: productgallerydata.subscribe,
                status: 'true',
            });



            saveagaingallery.save(function (err, saveagaingallery) {
                if (!err) {

                    deferred.resolve(saveagaingallery);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(productgallerydata.userId),
                        targetid: new mongoose.Types.ObjectId(saveagaingallery._id),
                    }],
                    description: 'Product ' + productgallerydata.proName + ' Added',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });
            });

            var i;
            var imageUrl;

            for (i in productgallerydata.image) {

                if (productgallerydata.image[i].checkbox == 'true') {
                    imageUrl = productgallerydata.image[i].s3url;

                }
            }

            if (productgallerydata.subscribe == true) {

                companies.find({ _id: productgallerydata.companyid }, function (err, thisData) {
                    var i;
                    for (i = 0; i < thisData.length; i++) {
                        var CompanyData = new companies();

                        CompanyData.domainName = thisData[i].domainName;
                        // CompanyData.save(function (err) { });


                        subscriber.find({ companyid: productgallerydata.companyid }, function (err, data) {


                            var i;
                            for (i = 0; i < data.length; i++) {
                                var emailData = new subscriber();
                                emailData.EmailAddress = data[i].EmailAddress;

                                var mailOptions = {
                                    from: 'admin@finikart.com',
                                    to: data[i].EmailAddress,
                                    subject: 'Finikart Subscribers',
                                    // text: 'Hello Subscriber This Is Finikart'
                                    html: 'One Product Is Addeed In   ' + CompanyData.domainName + '<p>Product Name:</p>' + productgallerydata.proName + '<br>' + '<p>Product Discription:</p>' + productgallerydata.description + '<p>Product Price:</p>' + productgallerydata.productprice + '<p>Image:</p>' + '<img src="' + imageUrl + '"/>'
                                };

                                transporter.sendMail(mailOptions, function (error, info) {
                                    if (error) {
                                        console.log(error);
                                    } else {
                                        console.log('Email sent: ' + info.response);
                                    }
                                });
                            }

                        });
                    }
                });
            }


        }

    });
    return deferred.promise;

}
// function getproductcategories() {
//     var deferred = Q.defer();
//     currency.find(function (err, fetchproductcategories) {
//         if (!err) {
//             console.log('fetchproductcategories');
//             console.log(fetchproductcategories);
//             deferred.resolve(fetchproductcategories);
//         } else {
//             deferred.reject(err.name + ': ' + err.message);
//         }
//     })
//     return deferred.promise;

// }

function getcurrencyname() {
    var deferred = Q.defer();

    currency.find(function (err, getcurrency) {

        if (!err) {

            deferred.resolve(getcurrency);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}




function getAllcompany() {


    var deferred = Q.defer();

    companies.aggregate([
        {
            $match: { $and: [{ "userType": 'Company' }] }
        },
        {
            $lookup: {
                from: "packages",
                localField: "packageid",
                foreignField: "_id",
                as: "packageName"
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, companies) {
            if (!err) {
                deferred.resolve(companies);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}



function getAllPackages() {
    var deferred = Q.defer();
    packages.find({ status: 'true' }, function (err, packages) {

        if (!err) {
            deferred.resolve(packages);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ packageName: 1 });
    return deferred.promise;

}

function getproductcategories(userId) {
    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(userId);

    productcategories.find({ $and: [{ companyid: userId }, { status: true }] }, function (err, fetchproductcategories) {
        //console.log(fetchproductcategories)
        if (!err) {
            deferred.resolve(fetchproductcategories);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ catName: 1 });
    return deferred.promise;

}


// function getproductname() {
//     var deferred = Q.defer();
//     productgallery.find(function (err, getname) {
//         if (!err) {
//             deferred.resolve(getname);
//         } else {
//             deferred.reject(err.name + ': ' + err.message);
//         }
//     })
//     return deferred.promise;

// }


function getAllproductcategories(userId) {
    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(userId);

    productcategories.find({ companyid: userId }, function (err, productcategories) {

        if (!err) {
            deferred.resolve(productcategories);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ dateadded: -1 });

    return deferred.promise;

}

function getAllproductgallery(userId) {

    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(userId);
    productgallery.aggregate([
        { "$match": { "companyid": userId } },
        // { $unwind: '$image' },
        // { $match: { 'image.checkbox': 'true' } },
        {
            $lookup: {
                from: "productcategories",
                localField: "catNameid",
                foreignField: "_id",
                as: "catName"
            }
        },
        { $sort: { dateadded: -1 } }]).exec(function (err, productgallery) {

            if (!err) {


                deferred.resolve(productgallery);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}





function getcompanybyId(companyId) {
    var deferred = Q.defer();
    var CompanyId = new mongoose.Types.ObjectId(companyId);

    companies.findOne(CompanyId, function (err, companies) {
        if (!err) {
            deferred.resolve(companies);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}

function getproductcategoriesbyId(productcategoriesId) {


    var deferred = Q.defer();
    var productcategoriesId = new mongoose.Types.ObjectId(productcategoriesId);

    productcategories.findOne(productcategoriesId, function (err, productcategories) {

        if (!err) {
            deferred.resolve(productcategories);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}


function getproductgallerybyId(productgalleryId) {

    var deferred = Q.defer();


    var productgalleryId = new mongoose.Types.ObjectId(productgalleryId);

    productgallery.findOne(productgalleryId, function (err, productgallery) {
        if (!err) {
            deferred.resolve(productgallery);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}



function filtercategory(categoryid) {
    var deferred = Q.defer();
    var categoryid = new mongoose.Types.ObjectId(categoryid);
    productgallery.aggregate([

        { "$match": { "catNameid": categoryid } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },
        {
            $lookup: {
                from: "productcategories",
                localField: "catNameid",
                foreignField: "_id",
                as: "catName"
            }
        }
    ]).exec(function (err, getcategory) {
        // console.log(getcategory);
        if (!err) {
            deferred.resolve(getcategory);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}


function updatecompany(companydata) {

    var hashUserPassword = bcrypt.hashSync(companydata.Password, 10);
    var deferred = Q.defer();


    // { $and: [{ username: companydata.userName }, {_id: {$ne: custompagedata._id }}] }
    var cmpEMAIL = new RegExp("^" + companydata.email + "$", "i")
    companies.find({ $and: [{ email: cmpEMAIL }, { _id: { $ne: companydata._id } }] }, function (err, companiesget) {

        if (companiesget.length > 0) {

            var data = {};
            data.string = 'Email Address Is Already Exist Please Enter Another Email Address!';
            deferred.resolve(data);

        } else if (companydata.businessName) {
            var cmpbusinessName = new RegExp("^" + companydata.businessName + "$", "i")
            companies.find({ $and: [{ businessName: cmpbusinessName }, { _id: { $ne: companydata._id } }] }, function (err, companiesget) {
                if (companiesget.length > 0) {

                    var data = {};
                    data.string = 'Business Name Is Already Exist Please Enter Another Business!';
                    deferred.resolve(data);

                } else if (companydata.userName) {
                    var username = new RegExp("^" + companydata.userName + "$", "i")
                    companies.find({ $and: [{ username: username }, { _id: { $ne: companydata._id } }] }, function (err, companiesget) {
                        if (companiesget.length > 0) {
                            var data = {};
                            data.string = 'User Name Is Already Exist Please Enter Another User Name!';
                            deferred.resolve(data);
                        }
                        else {
                            companies.findById(companydata._id, function (err, companies) {
                                if (!err) {

                                    companies.businessName = companydata.businessName;
                                    companies.packageid = companydata.packageName;
                                    companies.domainName = companydata.domainName;
                                    companies.email = companydata.email;
                                    companies.userName = companydata.userName;
                                    companies.password = hashUserPassword;
                                    companies.resellercode = companydata.resellercode;
                                    companies.status = companydata.status;
                                    companies.date_modified = Date.now();

                                    companies.save(function (err) {
                                        if (!err) {
                                            deferred.resolve(companies);
                                        } else {
                                            deferred.reject(err.name + ': ' + err.message);
                                        }
                                    });

                                } else {
                                    deferred.reject(err.name + ': ' + err.message);
                                }

                                var savelogs = new logs({

                                    logid: [{
                                        userid: new mongoose.Types.ObjectId(companydata.userId),
                                        targetid: new mongoose.Types.ObjectId(companies._id),
                                    }],
                                    description: 'Company ' + companydata.businessName + ' Updated',
                                    action: 'Company'
                                });
                                savelogs.save(function (err, logs) {
                                    if (!err) {
                                        deferred.resolve(savelogs);
                                    } else {
                                        console.log(err);
                                        deferred.reject(err.name + ': ' + err.message);
                                    }
                                });


                            });

                        }
                    })
                }

            })
        }
    });

    return deferred.promise;
}


function updatetoggle(companydata) {

    var deferred = Q.defer();

    companies.findById(companydata.id, function (err, companies) {

        if (!err) {

            companies.status = companydata.status;
            companies.date_modified = Date.now();

            companies.save(function (err) {
                if (!err) {
                    deferred.resolve(companies);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(companydata.userId),
                targetid: new mongoose.Types.ObjectId(companies._id),
            }],
            description: 'Status ' + companydata.status + ' Updated',
            action: 'Company'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}



function updateproductcategories(productcategoriesdata) {
    var deferred = Q.defer();
    var catName = new RegExp("^" + productcategoriesdata.catName + "$", "i")
    productcategories.find({ $and: [{ catName: catName }, { _id: { $ne: productcategoriesdata._id } }] }, function (err, getcategory) {

        if (getcategory.length > 0) {
            var data = {};
            data.string = 'Category Name already extis';
            deferred.resolve(data);
        } else {
            productcategories.findById(productcategoriesdata._id, function (err, productcategories) {
                if (!err) {

                    productcategories.catName = productcategoriesdata.catName;
                    productcategories.description = productcategoriesdata.description;
                    productcategories.status = productcategoriesdata.status;
                    productcategories.datemodified = Date.now();

                    productcategories.save(function (err) {
                        if (!err) {
                            deferred.resolve(productcategories);
                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(productcategoriesdata.userId),
                        targetid: new mongoose.Types.ObjectId(productcategories._id),
                    }],
                    description: 'productcategoy ' + productcategoriesdata.catName + ' Updated',
                    action: 'productcategories'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            });
        }
    });

    return deferred.promise;
}


function updateagainproductgallery(productgallerydata) {
    var deferred = Q.defer();
    // console.log('productgallerydataservice ')


    if (productgallerydata.checkboxtoggle == true) {

        var imageData = [];
        if (productgallerydata.imageuploaded) {
            for (let i = 0; i < productgallerydata.imageuploaded.length; i++) {

                imageData.push({ 'url': productgallerydata.imageuploaded[i] })
            }
        }
        var proName = new RegExp("^" + productgallerydata.proName + "$", "i")
        productgallery.find({ $and: [{ proName: proName }, { _id: { $ne: productgallerydata._id } }] }, function (err, getdata) {

            if (getdata.length > 0) {
                var data = {};
                data.string = 'Product Name is already exixt';
                deferred.resolve(data);
            } else {
                productgallery.findOneAndUpdate({ _id: productgallerydata._id }, {

                    image: [],
                    youtube: productgallerydata.checkboxtoggle == false ? '' : productgallerydata.youtube,
                    catNameid: productgallerydata.catName,
                    proName: productgallerydata.proName,
                    description: productgallerydata.description,
                    currencynameid: new mongoose.Types.ObjectId(productgallerydata.currencyname),
                    productprice: productgallerydata.productprice,
                    discountprice: productgallerydata.discountprice,
                    shippingcharge: productgallerydata.freeshipping == true ? '' : productgallerydata.shippingcharge,
                    transactionprice: productgallerydata.transactionprice,
                    netamount: productgallerydata.netamount,
                    onlinelink: productgallerydata.onlinelink,
                    priority: productgallerydata.priority,
                    onweb: productgallerydata.onweb,
                    onapp: productgallerydata.onapp,
                    productavailability: productgallerydata.productavailability,
                    freeshipping: productgallerydata.freeshipping,
                    facebook: productgallerydata.facebook,
                    checkboxtoggle: productgallerydata.checkboxtoggle,
                    twitter: productgallerydata.twitter,
                    datemodified: Date.now(),

                }, function (err, Photogallery) {

                    if (err) {

                        console.log(err)
                        return;
                    }
                });

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(productgallerydata.userId),
                        targetid: new mongoose.Types.ObjectId(productgallery._id),
                    }],
                    description: 'Product Gallery ' + productgallerydata.proName + ' Updated',
                    action: 'Update'
                });

                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });

            }
        });




    } else {


        // var imageData = [];
        // for (let i = 0; i < productgallerydata.image.length; i++) {
        //     imageData.push({ 'url': productgallerydata.image[i].url,'checkbox': productgallerydata.image[i].checkbox })
        // }

        var imageData = [];
        if (productgallerydata.imageuploaded) {
            for (let i = 0; i < productgallerydata.imageuploaded.length; i++) {

                imageData.push({ 'url': productgallerydata.imageuploaded[i].s3url, 'checkbox': productgallerydata.imageuploaded[i].checkbox })
            }
        }
        var proName = new RegExp("^" + productgallerydata.proName + "$", "i")
        productgallery.find({ $and: [{ proName: proName}, { _id: { $ne: productgallerydata._id } }] }, function (err, getdata) {

            if (getdata.length > 0) {
                var data = {};
                data.string = 'Product Name is already exixt';
                deferred.resolve(data);
            } else {

                productgallery.findOneAndUpdate({ _id: productgallerydata._id }, {

                    $push: {
                        image: imageData
                    },

                    // image:imageData,
                    youtube: productgallerydata.checkboxtoggle == false ? '' : productgallerydata.youtube,
                    catNameid: productgallerydata.catName,
                    proName: productgallerydata.proName,
                    description: productgallerydata.description,
                    currencynameid: productgallerydata.currencyname,
                    productprice: productgallerydata.productprice,
                    discountprice: productgallerydata.discountprice,
                    shippingcharge: productgallerydata.freeshipping == true ? '' : productgallerydata.shippingcharge,
                    transactionprice: productgallerydata.transactionprice,
                    netamount: productgallerydata.netamount,
                    onlinelink: productgallerydata.onlinelink,
                    priority: productgallerydata.priority,
                    onweb: productgallerydata.onweb,
                    onapp: productgallerydata.onapp,
                    productavailability: productgallerydata.productavailability,
                    freeshipping: productgallerydata.freeshipping,
                    facebook: productgallerydata.facebook,
                    checkboxtoggle: productgallerydata.checkboxtoggle,
                    twitter: productgallerydata.twitter,
                    datemodified: Date.now(),

                }, function (err, Photogallery) {

                    if (err) {

                        console.log(err)
                        return;
                    }
                });
                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(productgallerydata.userId),
                        targetid: new mongoose.Types.ObjectId(productgallery._id),
                    }],
                    description: 'Product Gallery ' + productgallerydata.proName + ' Updated',
                    action: 'Update'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });

            }
        })


    }


    return deferred.promise;
}


function deletearray(productgalleryid, productgalleryimageid) {


    var maindata = new mongoose.Types.ObjectId(productgalleryid.maindata);
    var imagedata = new mongoose.Types.ObjectId(productgalleryid.imagedata);

    var deferred = Q.defer();

    productgallery.findOne({ _id: maindata }).then(function (getproductgallery) {

        getproductgallery.image.pull({ _id: imagedata });
        getproductgallery.save().then(function (getproductgallery) {
            //do something smart
            if (getproductgallery) {

                return;
            }
        });
    });


    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(productgalleryid.userId),
            targetid: new mongoose.Types.ObjectId(productgallery._id),
        }],
        description: 'Image Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });



    return deferred.promise;
}


function updatetoggleone(productcategoriesdata) {
    var deferred = Q.defer();

    productcategories.findById(productcategoriesdata.id, function (err, productcategories) {
        if (!err) {

            productcategories.status = productcategoriesdata.status;
            productcategories.datemodified = Date.now();

            productcategories.save(function (err) {
                if (!err) {
                    deferred.resolve(productcategories);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(productcategoriesdata.userId),
                targetid: new mongoose.Types.ObjectId(productcategories._id),
            }],
            description: 'Status ' + productcategoriesdata.status + ' Updated',
            action: 'Product Categories'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}



function deletecompany(companyId, userId, name) {
    var companydomainid = new mongoose.Types.ObjectId(companyId);

    var deferred = Q.defer();
    domains.find({ companyId: companydomainid }, function (err, domainsget) {


        if (domainsget.length > 0) {
            var data = {};
            data.string = 'Assign another company to domain then delete the company';
            deferred.resolve(data);

        } else {

            var savelogs = new logs({

                logid: [{
                    userid: new mongoose.Types.ObjectId(userId),
                    targetid: new mongoose.Types.ObjectId(companyId._id),
                }],
                description: 'Company ' + name + ' Deleted',
                action: 'Delete'
            });
            savelogs.save(function (err, logs) {
                if (!err) {
                    deferred.resolve(savelogs);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

            companies.deleteOne(
                { _id: new mongoose.Types.ObjectId(companyId) },
                function (err) {
                    if (err) {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else {
                        var data = {};
                        data.string = 'Company deleted successfully';
                        deferred.resolve();
                    }
                });
        }
    });
    return deferred.promise;

}

function deleteproductcategories(productcategoriesId, userId, name) {

    var productcategoryId = new mongoose.Types.ObjectId(productcategoriesId);

    var deferred = Q.defer();
    productgallery.find({ catNameid: productcategoryId }, function (err, getCategories) {

        if (getCategories.length > 0) {

            var data = {};
            data.string = 'Assign another category to gallery then delete the product category';
            deferred.resolve(data);

        } else {

            var savelogs = new logs({

                logid: [{
                    userid: new mongoose.Types.ObjectId(userId),
                    targetid: new mongoose.Types.ObjectId(productcategoriesId._id),
                }],
                description: 'Product Category ' + name + ' Deleted',
                action: 'Delete'
            });
            savelogs.save(function (err, logs) {
                if (!err) {
                    deferred.resolve(savelogs);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

            productcategories.deleteOne(
                { _id: new mongoose.Types.ObjectId(productcategoriesId) },
                function (err) {
                    if (err) {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else {
                        deferred.resolve();
                    }

                });

        }

    });

    return deferred.promise;

}


function deleteproductgallery(productgalleryId, userId, name) {

    var deferred = Q.defer();
    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(userId),
            targetid: new mongoose.Types.ObjectId(productgalleryId._id),
        }],
        description: 'Product Gallery  ' + name + ' Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    productgallery.deleteOne(
        { _id: new mongoose.Types.ObjectId(productgalleryId) },
        function (err) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
            else {
                deferred.resolve();
            }

        });
    return deferred.promise;

}

function productgalleryimagestatus(data) {


    var deferred = Q.defer();

    var categoryid = new mongoose.Types.ObjectId(data.id);

    var ObjectId = new mongoose.Types.ObjectId(data.objid)
    productgallery.aggregate([

        { "$match": { "_id": ObjectId } },
        { $unwind: '$image' },
        //  { $match: {'image._id': categoryid}}

    ]).exec(function (err, getcategory) {

        if (!err) {
            const updates = getcategory;
            const allupdates = [];
            updates.forEach(element => {

                element.image.checkbox = 'false';

                if (element.image._id == data.id) {

                    element.image.checkbox = 'true';
                }
                allupdates.push(element);

            });


            var imageData = []
            for (let j = 0; j < allupdates.length; j++) {

                imageData.push({ 'url': allupdates[j].image.url, 'checkbox': allupdates[j].image.checkbox, '_id': allupdates[j].image._id })
            }
            productgallery.update({ _id: ObjectId }, {

                $set: {
                    image: imageData
                },
            }, function (err, Photogallery) {

                if (err) {

                    deferred.reject(err.name + ': ' + err.message);
                } else {


                    deferred.resolve(Photogallery);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;


}



function onwebupdatetoggle(updatedata) {

    var deferred = Q.defer();

    productgallery.findById(updatedata.id, function (err, data) {

        if (!err) {

            data.onweb = updatedata.onweb;
            data.datemodified = Date.now();

            data.save(function (err) {
                if (!err) {
                    deferred.resolve(data);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(updatedata.userId),
                targetid: new mongoose.Types.ObjectId(data._id),
            }],
            description: 'Onweb ' + updatedata.status + ' Updated',
            action: 'productgallery'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}


function onAPPupdatetoggle(updatedata) {

    var deferred = Q.defer();

    productgallery.findById(updatedata.id, function (err, data) {

        if (!err) {

            data.onapp = updatedata.onapp;
            data.datemodified = Date.now();

            data.save(function (err) {
                if (!err) {
                    deferred.resolve(data);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(updatedata.userId),
                targetid: new mongoose.Types.ObjectId(data._id),
            }],
            description: 'Onapp: ' + updatedata.status + ' Updated',
            action: 'productgallery'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}




function Statusupdatetoggle(updatedata) {

    var deferred = Q.defer();

    productgallery.findById(updatedata.id, function (err, data) {

        if (!err) {

            data.status = updatedata.status;
            data.datemodified = Date.now();

            data.save(function (err) {
                if (!err) {
                    deferred.resolve(data);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(updatedata.userId),
                targetid: new mongoose.Types.ObjectId(data._id),
            }],
            description: 'Onapp: ' + updatedata.status + ' Updated',
            action: 'productgallery'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}


module.exports = service;
