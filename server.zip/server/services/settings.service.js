var _ = require('lodash');
var jwt = require('jsonwebtoken');
var Q = require('q');
var mongoose = require('mongoose');
var usage = require('../controllers/settings/usage.model');
// var db = mongo.db(config.connectionString, { native_parser: true });
var logs = require('../controllers/logs/logs.model');

// db.bind('users');

var service = {};

service.getAllusage = getAllusage;
service.deleteusage = deleteusage;
service.updatetoggle = updatetoggle;

service.getUsagebyId = getUsagebyId;
service.updateusage = updateusage;
function getAllusage() {
   
    console.log('test');
    var deferred = Q.defer();
    usage.find(function (err, usage) {
        if (!err) {
           
            deferred.resolve(usage);
           
        } else {
            
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;
  

}


function deleteusage(id,userid,name) {

var deferred = Q.defer();
usage.deleteOne(
    { _id: new mongoose.Types.ObjectId(id) },
    function (err) {
        if (err) {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
        else {
            var data = {};
            data.string = 'Usage deleted successfully';
            deferred.resolve(data);
           
        }
    });
    return deferred.promise;
}


function updatetoggle (usagedata) {
    var deferred = Q.defer();

    usage.findById(usagedata.id, function (err, usagecategories) {
        if (!err) {

            usagecategories.status = usagedata.status;
            usagecategories.datemodified = Date.now();

            usagecategories.save(function (err) {
                if (!err) {
                    deferred.resolve(usagecategories);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(usagedata.userId),
                targetid: new mongoose.Types.ObjectId(usagedata._id),
            }],
            description: 'Status ' + usagedata.status + ' Updated',
            action: 'Product Categories'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}


function getUsagebyId (UsageId) {
    var deferred = Q.defer();
    var UsageId = new mongoose.Types.ObjectId(UsageId);

    usage.findOne(UsageId, function (err, usage) {
        if (!err) {
          
            deferred.resolve(usage);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;
}
 


function updateusage(usagedata) {

    var deferred = Q.defer();
   

    usage.findById(usagedata._id, function (err, usage) {
        if (!err) {

            usage.pagename = usagedata.pagename;
            usage.description = usagedata.htmlContent;
            usage.status = usagedata.Status;

            usage.save(function (err) {
                if (!err) {
                    deferred.resolve(usage);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(usagedata.userId),
                targetid: new mongoose.Types.ObjectId(usagedata._id),
            }],
            description: 'Usage Page ' + usagedata.pagename + ' Updated',
            action: 'Usage Page'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });   
    return deferred.promise;

}
module.exports = service;
