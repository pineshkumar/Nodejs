var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var siteappearance = require('../controllers/siteappearance/siteappearance.model');// get our mongoose model
var themes = require('../controllers/theme/theme.model');

var users = require('../controllers/Users/users.model');
var mongoose = require('mongoose');

var service = {};

service.getalltheme = getalltheme;
service.getlogos = getlogos


function getalltheme(link) {

 console.log('link');
 console.log(link);
 var defaults = 1;
 var deferred = Q.defer();

 users.aggregate([

        { "$match":{ "$and": [{ "domainName": link }] }},
    {
        $lookup: {
            from: "themeview",
            localField: "themeid",
            foreignField: "_id",
            as: "themes.themename"
        }
    }
]).exec(function (err, getthemecategory) {
   
    if (!err) {

        console.log('getthemecategory');
        console.log(getthemecategory[0].themeid);
          
        var themeid = '12'
        if(getthemecategory[0].themeid == '') {
            //  console.log('sdd')
            themes.findOne({default: 1}, function (err, data) {
                if (!err) {
                   
                    console.log('themes');
                    console.log(data);
                     deferred.resolve(data);

                    
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });
            return deferred.promise;


        } else {
        
        console.log('testing123')
        deferred.resolve(getthemecategory);

        }
      
        deferred.resolve(getthemecategory);
       
    } else {

        deferred.reject(err.name + ': ' + err.message);
    }
});
return deferred.promise;

}



function getlogos(userid) {

var deferred = Q.defer();

users.find({ _id: userid }, function (err, userlogo) {
    if (!err) {

       deferred.resolve(userlogo);
       
    } else {
        deferred.reject(err.name + ': ' + err.message);
    }
})
return deferred.promise;  



}

module.exports = service;