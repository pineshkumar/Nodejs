var _ = require('lodash');
var jwt = require('jsonwebtoken');
// var bcrypt = require('bcryptjs');
var Q = require('q');
var thirdparty = require('../controllers/thirdpartyintergration/thirdpartyintergration.model');
var mongoose = require('mongoose');
var domains = require('../controllers/domains/domains.model');
var companies = require('../controllers/Users/users.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');
var service = {};
service.submitFacebookdetails = submitFacebookdetails;
service.getDomainAndEmail = getDomainAndEmail;

function submitFacebookdetails(data) {
 
    var deferred = Q.defer();
    var companyid = new mongoose.Types.ObjectId(data.companyid);
   
    thirdparty.findOne({ companyid: data.companyid }, function (err, againdata) {


        if (againdata) {
           
            thirdparty.findOneAndUpdate({ _id: againdata._id }, {

                facebookId: data.facebookData.facebookId,
                fullName: data.facebookData.fullName,
                firstName: data.facebookData.firstName,
                lastName: data.facebookData.lastName,
                email: data.facebookData.email,
                photoUrl: data.facebookData.photoUrl,
                provider: data.facebookData.provider,
                companyid: companyid

            }, function (err, doc) {
                if (err) {
                    throw err;
                }
                else {
             
                }
            });

        } else {
         
            var savethirdParty = new thirdparty({

                facebookId: data.facebookData.facebookId,
                fullName: data.facebookData.fullName,
                firstName: data.facebookData.firstName,
                lastName: data.facebookData.lastName,
                email: data.facebookData.email,
                photoUrl: data.facebookData.photoUrl,
                provider: data.facebookData.provider,
                companyid: companyid
            });


            savethirdParty.save(function (err, savethirdParty) {
                if (!err) {

                    deferred.resolve(savethirdParty);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }
            });
        }
    })

    return deferred.promise;
}



function getDomainAndEmail(userId) {

    var deferred = Q.defer();

    var userId = new mongoose.Types.ObjectId(userId);
    domains.aggregate([
        {
            $match: {
                $and: [
                    { companyId: userId }
                ]
            }
        },
        {
            $lookup: {
                from: "users",       // other table name
                localField: "companyId",   // name of users table field
                foreignField: "_id",
                as: "companies"
            }
        }, {
            $lookup: {
                from: "packages",
                localField: "companies.packageid",
                foreignField: "_id",
                as: "companies.packageName",
            }
        }
    ]).exec(function (err, data) {
        if (!err) {
            deferred.resolve(data);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;


}

module.exports = service;
