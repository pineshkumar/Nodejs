var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var Password = require('../controllers/Users/users.model');// get our mongoose model
var mongoose = require('mongoose');
var nodemailer = require('nodemailer');
var sesTransport = require('nodemailer-ses-transport');
var smtpPassword = require('aws-smtp-credentials');

var service = {};
service.passwordmatch = passwordmatch;
service.sendlink = sendlink;
service.resetpassword = resetpassword;

function callback(error, info) {
    if (error) {
        console.log(error);
    } else {
        console.log('Message sent: ' + info.response);
    }
}


function passwordmatch(passworddata) {
  
    var deferred = Q.defer();
    var oldPassword = passworddata.passworddata.oldPassword;
    var userId = passworddata.userId;
    var newPassword = passworddata.passworddata.newPassword;

    var _id = new mongoose.Types.ObjectId(passworddata.userId)

    Password.findOne(_id, function (err, user) {

        if (user && bcrypt.compareSync(oldPassword, user.password)) {
         
            var data = {};
            data.string = 'Password Matched Successfully!';
            if (bcrypt.compareSync(newPassword, user.password)) {

                var data = {};
                data.string = 'Your Password Is Same As Old Password Please Enter Another Password';
                deferred.resolve(data);
            }
            else {
                var hashUserPassword = bcrypt.hashSync(newPassword, 10);
                Password.findById(_id, function (err, Password) {
                    Password.password = hashUserPassword;
                    Password.save(function (err) {
                        if (!err) {

                            deferred.resolve(Password);
                        } else {

                            console.log(err);
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                })
            }
        } else {
            var data = {};
            data.string = 'Password UnMatched!';
            deferred.resolve(data);
        }

    });
    return deferred.promise;
}

function sendlink(sendlinkdata, baseurl) {
    var deferred = Q.defer();
   
    Password.findOne({ email: sendlinkdata.email }, function (err, password) {

        if (password) {

            var userid = password._id;
            //Send e-mail using SMTP, Don't remove -----

            var mailOptions = {
                from: 'admin@finikart.com',
                to: sendlinkdata.email,
                text: 'This Is Your Link To Reset Password',
                html: '<a href="' + baseurl + '/resetpassword/' + userid + '">Reset Password Link</a>',

            };

            mailOptions.subject = 'Nodemailer SMTP transporter';
            var smtpTransporter = nodemailer.createTransport({
                port: 465,
                host: 'email-smtp.us-east-1.amazonaws.com',
                secure: true,
                auth: {
                    user: 'AKIAJDASXIM5S7ELYWWQ',
                    pass: smtpPassword('UvXNHbCMRcDVlHOjZjjsncDg90LNmjYmqbIvUqoL'),
                },
                debug: true
            });
            smtpTransporter.sendMail(mailOptions, callback);

            var data = {};
            data.string = 'Message send successfully!';
            deferred.resolve(data);

        } else {

            var data = {};
            data.string = 'Account does not exist!';
            deferred.resolve(data);

        }
    });
    return deferred.promise;
}

function resetpassword(resetpassworddata) {

    var deferred = Q.defer();


    var hashUserPassword = bcrypt.hashSync(resetpassworddata.newPassword, 10);

    Password.findById(resetpassworddata.userid, function (err, Password) {
        Password.password = hashUserPassword;
        Password.save(function (err) {
            if (!err) {

                deferred.resolve(Password);
            } else {

                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    })

    return deferred.promise;
}


module.exports = service;