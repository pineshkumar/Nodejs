﻿var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var domains = require('../controllers/domains/domains.model');// get our mongoose model
var companies = require('../controllers/Users/users.model');
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.adddomainrequest = adddomainrequest;
service.getAllDomainRequests = getAllDomainRequests;
service.getDomainRequestsbyId = getDomainRequestsbyId;
service.updateDomainRequests = updateDomainRequests;
service.deleteDomainRequests = deleteDomainRequests;

service.getAllcompany = getAllcompany;


function adddomainrequest(domaindata) {
    var deferred = Q.defer();

    var domain = new RegExp("^" + domaindata.domainname + "$", "i")
    domains.find({ domainName:domain}, function (err, data) {


        if (data.length > 0) {
            var data = {};
            data.string = 'Domain Name Is Already Exist Please Enter Another Domain Name!';
            deferred.resolve(data);

        } else {

            var saveDomain = new domains({

                companyId: new mongoose.Types.ObjectId(domaindata.companyName),
                domainName: domaindata.domainname,

            });
            saveDomain.save(function (err, saveDomain) {
                if (!err) {
                    deferred.resolve(saveDomain);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(domaindata.userId),
                        targetid: new mongoose.Types.ObjectId(saveDomain._id),
                    }],
                    description: 'Domain ' + domaindata.domainname + ' Added',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            });
            return deferred.promise;

        }
    }).sort({ dateadded: -1 });
    return deferred.promise;

}

function getAllDomainRequests() {
    var deferred = Q.defer();

    domains.aggregate([
        {
            $lookup: {
                from: "users",
                localField: "companyId",
                foreignField: "_id",
                as: "company"
            }
        }, {
            $project: {
                company: {
                    $arrayElemAt: ['$company', 0]
                },
                companyId: 1,
                domainName: 1,
                createddate: 1,
                date_modified: 1,
            }
        },
        {
            $lookup: {
                from: "packages",
                localField: "company.packageid",
                foreignField: "_id",
                as: "company.packageName",
            }
        },
        { $sort: { createddate: -1 } }]).exec(function (err, companies) {
            if (!err) {
                deferred.resolve(companies);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;

}


function getAllcompany() {
    var deferred = Q.defer();
    companies.find({ "status": true, "userType": 'Company' }, function (err, companies) {

        if (!err) {
            deferred.resolve(companies);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ businessName: 1 });
    return deferred.promise;

}

function getDomainRequestsbyId(domainId) {

    var deferred = Q.defer();
    var DomainId = new mongoose.Types.ObjectId(domainId);
    domains.findOne(DomainId, function (err, domains) {
        if (!err) {
            deferred.resolve(domains);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}

function updateDomainRequests(domaindata) {

    var deferred = Q.defer();
    var domain = new RegExp("^" + domaindata.domainName + "$", "i")
    domains.find({ $and: [{ domainName:domain }, { _id: { $ne: domaindata._id } }] }, function (err, data) {
       
        if (data.length > 0) {
            var data = {};
            data.string = 'Domain Name Is Already Exist Please Enter Another Domain Name!';
            deferred.resolve(data);

        } else {
            domains.findById(domaindata._id, function (err, domains) {
                if (!err) {

                    domains.companyId = domaindata.companyName;
                    domains.domainName = domaindata.domainName;
                    domains.date_modified = Date.now();

                    domains.save(function (err) {
                        if (!err) {
                            deferred.resolve(domains);
                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }


                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(domaindata.userId),
                        targetid: new mongoose.Types.ObjectId(domains._id),
                    }],
                    description: 'Domain ' + domaindata.domainName + ' Updated',
                    action: 'Update'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });
            });

        }


    });
    return deferred.promise;
}


function deleteDomainRequests(domainId, userId, name) {
    var deferred = Q.defer();
    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(userId),
            targetid: new mongoose.Types.ObjectId(domainId._id),
        }],

        description: 'Domain ' + name + ' Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    domains.deleteOne(
        { _id: new mongoose.Types.ObjectId(domainId) },
        function (err) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
            else {
                deferred.resolve();
            }

        });
    return deferred.promise;
}
module.exports = service;
