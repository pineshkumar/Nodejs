var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var resellers = require('../controllers/resellers/resellers.model');// get our mongoose model
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.addresellers = addresellers;
service.getAllresellers = getAllresellers;
service.getresellersbyId = getresellersbyId;
service.updateresellers = updateresellers;
service.updatetoggle = updatetoggle;
service.deleteresellers = deleteresellers;


function addresellers(resellersdata) {
    var deferred = Q.defer();
    var email = new RegExp("^" + resellersdata.Email + "$", "i")
    resellers.find({ email: email }, function (err, resellersget) {
        //   console.log(resellersget.length);
        if (resellersget.length > 0) {
            var data = {};
            data.string = 'Email Address Is Already Exist Please Enter Another Email Address!';
            deferred.resolve(data);

        } else if (resellersdata.Username) {
            var username = new RegExp("^" + resellersdata.Username + "$", "i")
            resellers.find({ username: username }, function (err, resellersget) {
                //   console.log(resellersget.length);
                if (resellersget.length > 0) {
                    var data = {};
                    data.string = 'User Name Is Already Exist Please Enter Another User Name!';
                    deferred.resolve(data);
                }
                else {
                    var hashUserPassword = bcrypt.hashSync(resellersdata.Password, 10);
                    var saveResellers = new resellers({


                        firstname: resellersdata.Name,
                        address: resellersdata.Address,
                        city: resellersdata.City,
                        primaryNumber: resellersdata.Phone,
                        email: resellersdata.Email,
                        userType: 'Reseller',
                        password: hashUserPassword,
                        username: resellersdata.Username,
                        accesscode: resellersdata.AccessCode,
                        status: resellersdata.Status
                    });
                    saveResellers.save(function (err, saveResellers) {
                        if (!err) {
                            deferred.resolve(saveResellers);
                        } else {
                            console.log(err);
                            deferred.reject(err.name + ': ' + err.message);
                        }

                        var savelogs = new logs({

                            logid: [{
                                userid: new mongoose.Types.ObjectId(resellersdata.userId),
                                targetid: new mongoose.Types.ObjectId(saveResellers._id),
                            }],
                            description: 'Reseller ' + resellersdata.Name + ' Added',
                            action: 'Add'
                        });
                        savelogs.save(function (err, logs) {
                            if (!err) {
                                deferred.resolve(savelogs);
                            } else {
                                console.log(err);
                                deferred.reject(err.name + ': ' + err.message);
                            }
                        });



                    });
                }
            })
        }
    }).sort({ dateadded: -1 });
    return deferred.promise;
}


function getAllresellers() {
    var deferred = Q.defer();

    resellers.find({ userType: 'Reseller' }, function (err, resellers) {
        if (!err) {
            deferred.resolve(resellers);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ dateadded: -1 });
    return deferred.promise;

}

function getresellersbyId(resellersId) {
    var deferred = Q.defer();
    var resellersId = new mongoose.Types.ObjectId(resellersId);

    resellers.findOne(resellersId, function (err, resellers) {
        if (!err) {
            deferred.resolve(resellers);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}


function updateresellers(resellersdata) {
    var deferred = Q.defer();
    var hashUserPassword = bcrypt.hashSync(resellersdata.Password, 10);

    // { $and: [{  username: resellersdata.Username  }, {_id: {$ne: resellersdata._id }}] }
    var email = new RegExp("^" + resellersdata.Email + "$", "i")
    resellers.find({ $and: [{ email: email }, { _id: { $ne: resellersdata._id } }] }, function (err, resellersget) {
        if (resellersget.length > 0) {
            var data = {};
            data.string = 'Email Address Is Already Exist Please Enter Another Email Address!';
            deferred.resolve(data);

        } else if (resellersdata.Username) {
            var username = new RegExp("^" + resellersdata.Username + "$", "i")
            resellers.find({ $and: [{ username: username }, { _id: { $ne: resellersdata._id } }] }, function (err, resellersget) {
                if (resellersget.length > 0) {
                    var data = {};
                    data.string = 'User Name Is Already Exist Please Enter Another User Name!';
                    deferred.resolve(data);
                }

                else {

                    resellers.findById(resellersdata._id, function (err, resellers) {
                        if (!err) {
                            if (resellersdata.Password) {
                                resellers.firstname = resellersdata.Name;
                                resellers.address = resellersdata.Address;
                                resellers.city = resellersdata.City;
                                resellers.primaryNumber = resellersdata.Phone;
                                resellers.email = resellersdata.Email;
                                resellers.password = hashUserPassword;
                                resellers.username = resellersdata.Username;
                                resellers.accesscode = resellersdata.AccessCode;
                                resellers.status = resellersdata.Status;
                                resellers.datemodified = Date.now();
                            }
                            else {
                                resellers.firstname = resellersdata.Name;
                                resellers.address = resellersdata.Address;
                                resellers.city = resellersdata.City;
                                resellers.primaryNumber = resellersdata.Phone;
                                resellers.email = resellersdata.Email;
                                resellers.username = resellersdata.Username;
                                resellers.accesscode = resellersdata.AccessCode;
                                resellers.status = resellersdata.Status;
                                resellers.datemodified = Date.now();
                            }


                            resellers.save(function (err) {
                                if (!err) {
                                    deferred.resolve(resellers);
                                } else {
                                    deferred.reject(err.name + ': ' + err.message);
                                }
                            });

                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }

                        var savelogs = new logs({

                            logid: [{
                                userid: new mongoose.Types.ObjectId(resellersdata.userId),
                                targetid: new mongoose.Types.ObjectId(resellers._id),
                            }],
                            description: 'Reseller ' + resellersdata.Name + ' Updated',
                            action: 'Reseller'
                        });
                        savelogs.save(function (err, logs) {
                            if (!err) {
                                deferred.resolve(savelogs);
                            } else {
                                console.log(err);
                                deferred.reject(err.name + ': ' + err.message);
                            }
                        });

                    });
                }
            })
        }
    });
    return deferred.promise;
}


function updatetoggle(resellersdata) {
    var deferred = Q.defer();
    resellers.findById(resellersdata.id, function (err, resellers) {
        if (!err) {
            resellers.status = resellersdata.status;
            resellers.datemodified = Date.now();

            resellers.save(function (err) {
                if (!err) {
                    deferred.resolve(resellers);

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(resellersdata.userId),
                targetid: new mongoose.Types.ObjectId(resellers._id),
            }],
            description: 'Status ' + resellersdata.status + ' Updated',
            action: 'Reseller'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}



function deleteresellers(resellersId, userId, name) {
    // console.log(resellersId);
    // console.log(userId);
    // console.log(name);
    // return false;
    var deferred = Q.defer();
    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(userId),
            targetid: new mongoose.Types.ObjectId(resellersId._id),
        }],
        description: 'Reseller  ' + name + ' Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    resellers.deleteOne(
        { _id: new mongoose.Types.ObjectId(resellersId) },
        function (err) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
            else {
                deferred.resolve();
            }

        });
    return deferred.promise;

}


module.exports = service;
