var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var packages = require('../controllers/packages/packages.model');// get our mongoose model
var domains = require('../controllers/domains/domains.model');// get our mongoose model
var companies = require('../controllers/Users/users.model');
var resellers = require('../controllers/Users/users.model');// get our mongoose model
var allupdates = require('../controllers/allupdates/allupdates.model');// get our mongoose model
var productgallery = require('../controllers/productgallery/productgallery.model');
var subscriber = require('../controllers/subscriber/subscriber.model');
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.getAllcountspackges = getAllcountspackges;
service.getAllcountsdomainRequest = getAllcountsdomainRequest;
service.getAllcountscompanies = getAllcountscompanies;
service.getAllcountsResellers = getAllcountsResellers;
service.getAllcountsUpdates = getAllcountsUpdates;
service.getAllcountsProducts = getAllcountsProducts;
service.getAllcountsSubscriber = getAllcountsSubscriber;

function getAllcountspackges(id) {


    var deferred = Q.defer();
    packages.count(function (err, countpackage) {
        if (!err) {
        
            deferred.resolve(countpackage);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getAllcountsdomainRequest(id) {


    var deferred = Q.defer();
    domains.count(function (err, count) {
        if (!err) {
         
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function getAllcountscompanies(id) {


    var deferred = Q.defer();
    companies.count({ userType: 'Company' }, function (err, count) {
        if (!err) {
           
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function getAllcountsResellers(id) {


    var deferred = Q.defer();
    resellers.count({ userType: 'Reseller' }, function (err, count) {
        if (!err) {
          
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getAllcountsUpdates(id) {

    var deferred = Q.defer();
    var id = new mongoose.Types.ObjectId(id);
    allupdates.count({ companyid: id },function (err, count) {
        if (!err) {
           
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function getAllcountsProducts(id) {


    var deferred = Q.defer();
    var id = new mongoose.Types.ObjectId(id);
    productgallery.count({ companyid: id },function (err, count) {
        if (!err) {
         
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getAllcountsSubscriber(id) {


    var deferred = Q.defer();
    var id = new mongoose.Types.ObjectId(id);
    subscriber.count({ companyid: id },function (err, count) {
        if (!err) {
          
            deferred.resolve(count);
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

module.exports = service;