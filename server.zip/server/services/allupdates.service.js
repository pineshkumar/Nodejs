var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var allupdates = require('../controllers/allupdates/allupdates.model');// get our mongoose model
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
var companies = require('../controllers/Users/users.model');
var subscriber = require('../controllers/subscriber/subscriber.model');
// var db = mongo.db(config.connectionString, { native_parser: true });
var nodemailer = require('nodemailer');
// db.bind('users');

var service = {};
service.addagainallupdates = addagainallupdates;
service.getAllallupdates = getAllallupdates;
// service.getresellersbyId = getresellersbyId;
// service.updateresellers = updateresellers;
service.deleteallupdates = deleteallupdates;
service.updatetoggle = updatetoggle;
service.updatetoggleagain = updatetoggleagain;
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'swatisuthar1494@gmail.com',
        pass: 'swati1494'
    }
});

function addagainallupdates(allupdatesdata) {

    var deferred = Q.defer();

    var imageData = [];
    for (let i = 0; i < allupdatesdata.image.length; i++) {
        imageData.push({ 'url': allupdatesdata.image[i].s3url, 'flag': allupdatesdata.image, 'checkbox': allupdatesdata.image[i].checkbox })
    }


    var saveallupdates = new allupdates({

        image: imageData,
        companyid: new mongoose.Types.ObjectId(allupdatesdata.companyid),
        message: allupdatesdata.message,
        customerlist: allupdatesdata.customerlist,
        onweb: allupdatesdata.onweb,
        onapp: allupdatesdata.onapp,
        facebook: allupdatesdata.facebook,
        twitter: allupdatesdata.twitter,
        subscribe: allupdatesdata.subscribe,
        checkedbox: allupdatesdata.checkedbox,
        timer: allupdatesdata.timer,
    });



    saveallupdates.save(function (err, saveallupdates) {
        if (!err) {

            deferred.resolve(saveallupdates);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(allupdatesdata.userId),
                targetid: new mongoose.Types.ObjectId(saveallupdates._id),
            }],
            description: 'Update ' + allupdatesdata.message + ' Added',
            action: 'Add'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {

                deferred.reject(err.name + ': ' + err.message);
            }
        });

    });

    var i;
    var imageUrl;

    for (i in allupdatesdata.image) {

        if (allupdatesdata.image[i].checkbox == 'true') {
            imageUrl = allupdatesdata.image[i].s3url;

        }
    }

    if (allupdatesdata.subscribe == true) {

        companies.find({ _id: allupdatesdata.companyid }, function (err, thisData) {
            var i;
            for (i = 0; i < thisData.length; i++) {
                var CompanyData = new companies();

                CompanyData.domainName = thisData[i].domainName;
                // CompanyData.save(function (err) { });

                subscriber.find({ companyid: allupdatesdata.companyid }, function (err, data) {


                    var i;
                    for (i = 0; i < data.length; i++) {
                        var emailData = new subscriber();
                        emailData.EmailAddress = data[i].EmailAddress;
                        // emailData.save(function (err) { });

                        var mailOptions = {
                            from: 'admin@finikart.com',
                            to: data[i].EmailAddress,
                            subject: 'Finikart Subscribers',
                            // text: 'Hello Subscriber This Is Finikart'
                            html: 'One Update Is Addeed In   ' + CompanyData.domainName + '<p>Message:</p>' + allupdatesdata.message + '<p>Image:</p>' + '<img src="' + imageUrl + '"/>'
                        };

                        transporter.sendMail(mailOptions, function (error, info) {
                            if (error) {
                                console.log(error);
                            } else {
                                console.log('Email sent: ' + info.response);
                            }
                        });
                    }

                });
            }
        });

    }
    return deferred.promise;

}

function getAllallupdates(userId) {

    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(userId);
    allupdates.aggregate([
        { "$match": { "companyid": userId } },
        { $unwind: '$image' },
        { $match: { 'image.checkbox': 'true' } },

        { $sort: { dateadded: -1 } }]).exec(function (err, allupdates) {

            if (!err) {

                deferred.resolve(allupdates);
            } else {
                deferred.reject(err.name + ': ' + err.message);
            }
        });
    return deferred.promise;


}



function updatetoggle(updatedata) {

    var deferred = Q.defer();

    allupdates.findById(updatedata.id, function (err, data) {

        if (!err) {

            data.onweb = updatedata.onweb;
            data.datemodified = Date.now();

            data.save(function (err) {
                if (!err) {
                    deferred.resolve(data);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(updatedata.userId),
                targetid: new mongoose.Types.ObjectId(data._id),
            }],
            description: 'onweb ' + updatedata.status + ' Updated',
            action: 'AllUpdates'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}


function updatetoggleagain(updatedata) {
  
    var deferred = Q.defer();

    allupdates.findById(updatedata.id, function (err, data) {
       
        if (!err) {

            data.onapp = updatedata.onapp;
            data.datemodified = Date.now();

            data.save(function (err) {
                if (!err) {
                    deferred.resolve(data);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(updatedata.userId),
                targetid: new mongoose.Types.ObjectId(data._id),
            }],
            description: 'onapp ' + updatedata.status + ' Updated',
            action: 'AllUpdates'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}



function deleteallupdates(allupdatesId, userId, name) {

    var deferred = Q.defer();
    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(userId),
            targetid: new mongoose.Types.ObjectId(allupdatesId._id),
        }],
        description: 'Allupdates  ' + name + ' Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    allupdates.deleteOne(
        { _id: new mongoose.Types.ObjectId(allupdatesId) },
        function (err) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
            else {
                deferred.resolve();
            }

        });
    return deferred.promise;

}


module.exports = service;
