var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var custompage = require('../controllers/custompage/custompage.model');// get our mongoose model
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};
service.addcustompage = addcustompage;
service.getAllcustompage = getAllcustompage;
service.getcustompagebyId = getcustompagebyId;
service.updatecustompage = updatecustompage;
service.updatetoggle = updatetoggle;
service.deletecustompage = deletecustompage;


// { $and: [ { Name: custompagedata.Name },{Name:{$regex:custompagedata.Name , $options:'i'}}] }
function addcustompage(custompagedata) {

    var deferred = Q.defer();
    var Name = new RegExp("^" + custompagedata.Name + "$", "i")
    custompage.find({ Name: Name }, function (err, custompageget) {
        if (custompageget.length > 0) {
            var data = {};
            data.string = 'Page Name already extis';
            deferred.resolve(data);
        }
        else {
            var savecustompage = new custompage({
                companyid: new mongoose.Types.ObjectId(custompagedata.companyid),
                Name: custompagedata.Name,
                htmlContent: custompagedata.htmlContent,
                Status: custompagedata.Status,
            });
            savecustompage.save(function (err, savecustompage) {
                if (!err) {

                    deferred.resolve(savecustompage);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(custompagedata.userId),
                        targetid: new mongoose.Types.ObjectId(savecustompage._id),
                    }],
                    description: 'Custompage ' + custompagedata.Name + ' Added',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            })
        }

    });
    return deferred.promise;

}

function getAllcustompage(userId) {
    var deferred = Q.defer();
    var userId = new mongoose.Types.ObjectId(userId);

    custompage.find({ companyid: userId }, function (err, custompage) {
        if (!err) {
            deferred.resolve(custompage);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    }).sort({ dateadded: -1 });
    return deferred.promise;

}


function getcustompagebyId(custompageId) {
    var deferred = Q.defer();
    var custompageId = new mongoose.Types.ObjectId(custompageId);

    custompage.findOne(custompageId, function (err, custompage) {
        if (!err) {
            deferred.resolve(custompage);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}

function updatecustompage(custompagedata) {

    var deferred = Q.defer();
    var Name = new RegExp("^" + custompagedata.Name + "$", "i")
    custompage.find({ $and: [{ Name: Name }, { _id: { $ne: custompagedata._id } }] }, function (err, custompageget) {

        if (custompageget.length > 0) {
            var data = {};
            data.string = 'Page Name already extis';
            deferred.resolve(data);
        }
        else {
            custompage.findById(custompagedata._id, function (err, custompage) {
                if (!err) {

                    custompage.Name = custompagedata.Name;
                    custompage.htmlContent = custompagedata.htmlContent;
                    custompage.Status = custompagedata.Status;

                    custompage.save(function (err) {
                        if (!err) {
                            deferred.resolve(custompage);
                        } else {
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });

                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(custompagedata.userId),
                        targetid: new mongoose.Types.ObjectId(custompage._id),
                    }],
                    description: 'Custom Page ' + custompagedata.Name + ' Updated',
                    action: 'Custom Page'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            });
        }
    });

    return deferred.promise;
}

function updatetoggle(custompagedata) {
    var deferred = Q.defer();

    custompage.findById(custompagedata.id, function (err, custompage) {
        if (!err) {

            custompage.Status = custompagedata.Status;

            custompage.save(function (err) {
                if (!err) {
                    deferred.resolve(custompage);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(custompagedata.userId),
                targetid: new mongoose.Types.ObjectId(custompage._id),
            }],
            description: 'Status ' + custompagedata.status + ' Updated',
            action: 'Custompage'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


    });
    return deferred.promise;
}




function deletecustompage(custompageId, userId, name) {
    var deferred = Q.defer();

    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(userId),
            targetid: new mongoose.Types.ObjectId(custompageId._id),
        }],
        description: 'Custom Page ' + name + ' Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    custompage.deleteOne(
        { _id: new mongoose.Types.ObjectId(custompageId) },
        function (err) {
            if (err) {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
            else {
                deferred.resolve();
            }

        });
    return deferred.promise;

}


module.exports = service;