var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');

var users = require('../controllers/Users/users.model')



var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
var custompages = require('../controllers/custompage/custompage.model');
var subscriber = require('../controllers/subscriber/subscriber.model');
var StoreTiming = require('../controllers/storetimings/stroretimings.model');
// var db = mongo.db(config.connectionString, { native_parser: true });
var nodemailer = require('nodemailer');
// db.bind('users');

var service = {};
service.getFooterBusinessName = getFooterBusinessName;
service.getAboutUsData = getAboutUsData;
service.addSubscriber = addSubscriber;
service.addContactData = addContactData;
service.getStoreTimingData = getStoreTimingData;

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'swatisuthar1494@gmail.com',
        pass: 'swati1494'
    }
});

service.getcustompagesdetail = getcustompagesdetail

function getFooterBusinessName(usersid) {


    var deferred = Q.defer();
    users.find({ _id: usersid }, function (err, getName) {


        if (!err) {
            deferred.resolve(getName);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getAboutUsData(usersid) {

  
    var deferred = Q.defer();
    custompages.find({ companyid: usersid }, function (err, GetDATA) {


        if (!err) {
            deferred.resolve(GetDATA);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}


function addSubscriber(subscriberData) {

    var deferred = Q.defer();
    subscriber.find({ EmailAddress: subscriberData.EmailAddress }, function (err, getData) {

        if (getData.length > 0) {
            var data = {};
            data.string = 'Email already extis';
            deferred.resolve(data);
        }
        else {
            var saveSubscriber = new subscriber({
                companyid: new mongoose.Types.ObjectId(subscriberData.companyid),
                EmailAddress: subscriberData.EmailAddress,

            });
            saveSubscriber.save(function (err, saveSubscriber) {
                if (!err) {
                    
                    deferred.resolve(saveSubscriber);
                } else {
                    console.log(err);
                    deferred.reject(err.name + ': ' + err.message);
                }

                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(subscriberData.userId),
                        targetid: new mongoose.Types.ObjectId(saveSubscriber._id),
                    }],
                    description: 'Subscriber ' + subscriberData.EmailAddress + ' Added',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });


            })
        }

    });
    return deferred.promise;

}

function addContactData(contactdetail) {

    var deferred = Q.defer();
  
    var mailOptions1 = {
        from: contactdetail.email,
        to: 'swatisuthar1494@gmail.com',
        subject: 'Finikart Contact Us',
        // text: '<p></p>',
        html: '<p>Email:</p>' + contactdetail.email + '<br>' + '<p>Message:</p>' + contactdetail.message
    };

    transporter.sendMail(mailOptions1, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
            deferred.resolve(info);
        }
    });
    return deferred.promise;
}




function getcustompagesdetail(pageid) {

    var deferred = Q.defer();
    custompages.find({ _id: pageid }, function (err, custompagedetail) {


        if (!err) {
            deferred.resolve(custompagedetail);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getStoreTimingData(companyid) {

    var deferred = Q.defer();
    StoreTiming.find( {companyid:companyid },function (err, storetiming) {
       
        if (!err) {
           
            deferred.resolve(storetiming);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}
module.exports = service;