var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var siteappearance = require('../controllers/siteappearance/siteappearance.model');// get our mongoose model
var companies = require('../controllers/Users/users.model');
var mongoose = require('mongoose');
var logs = require('../controllers/logs/logs.model');
// var db = mongo.db(config.connectionString, { native_parser: true });

// db.bind('users');

var service = {};

service.getsiteappearance = getsiteappearance;
service.getsiteappearancebyitsID = getsiteappearancebyitsID;
service.updatesiteappearance = updatesiteappearance;



function getsiteappearance() {
    var deferred = Q.defer();

    siteappearance.find(function (err, getdata) {

        if (!err) {

            deferred.resolve(getdata);
            
        } else {

            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function getsiteappearancebyitsID(siteappearanceDATA) {
  
    var deferred = Q.defer();

    var userID = new mongoose.Types.ObjectId(siteappearanceDATA);

    companies.findOne(userID, function (err, data) {

        if (!err) {
            deferred.resolve(data);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    });
    return deferred.promise;

}


function updatesiteappearance(sitedata) {

    var deferred = Q.defer();
    var UserId = new mongoose.Types.ObjectId(sitedata.UserId);

    
    companies.findById(UserId, function (err, getsitedata) {

        if (!err) {

            getsitedata.themeid = sitedata.themename;
           
            getsitedata.save(function (err) {
                if (!err) {
                    deferred.resolve(getsitedata);
                } else {
                    deferred.reject(err.name + ': ' + err.message);
                }
            });

        } else {
            deferred.reject(err.name + ': ' + err.message);
        }

        var savelogs = new logs({

            logid: [{
                userid: new mongoose.Types.ObjectId(sitedata.userId),
                targetid: new mongoose.Types.ObjectId(getsitedata._id),
            }],
            description: 'Theme Updated',
            action: 'Theme Page'
        });
        savelogs.save(function (err, logs) {
            if (!err) {
                deferred.resolve(savelogs);
            } else {
                console.log(err);
                deferred.reject(err.name + ': ' + err.message);
            }
        });


   });


    return deferred.promise;
}


module.exports = service;