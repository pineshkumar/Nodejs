var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var photogallery = require('../controllers/photogallery/photogallery.model');
var logs = require('../controllers/logs/logs.model');
var mongoose = require('mongoose');


var service = {};

service.addagainphotpgallery = addagainphotpgallery;
service.getAllphotogallery = getAllphotogallery;
service.deletearray = deletearray;
service.checkboxbutton = checkboxbutton;

function addagainphotpgallery(photogallerydata) {

    var deferred = Q.defer();
    photogallery.findOne({ userId: photogallerydata.userId }, function (err, Photogallery) {

        if (!err) {
            if (Photogallery) {

                var imageData = [];
                for (let i = 0; i < photogallerydata.image.length; i++) {

                    imageData.push({ 'url': photogallerydata.image[i] })
                }
                // Photogallery.save(function (err) {
                photogallery.findOneAndUpdate({ _id: Photogallery._id },
                    {
                        $push: {
                            image: imageData
                        }
                    }, function (err, Photogallery) {

                        if (err) {

                            console.log(err)
                            return;
                        }
                    });
                var savelogs = new logs({

                    logid: [{
                        userid: new mongoose.Types.ObjectId(photogallerydata.userId),
                        targetid: new mongoose.Types.ObjectId(photogallery._id),
                    }],
                    description: 'PhotoGallery Added In Existing User',
                    action: 'Add'
                });
                savelogs.save(function (err, logs) {
                    if (!err) {
                        deferred.resolve(savelogs);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                });

            }
            else {
                var imageData = [];
                for (let i = 0; i < photogallerydata.image.length; i++) {

                    imageData.push({ 'url': photogallerydata.image[i] })

                }
                  
                var savePhotogallery = new photogallery({

                    userId: new mongoose.Types.ObjectId(photogallerydata.userId),
                    image: imageData

                });
                savePhotogallery.save(function (err, savePhotogallery) {
                    if (!err) {
                        deferred.resolve(savePhotogallery);
                    } else {
                        console.log(err);
                        deferred.reject(err.name + ': ' + err.message);
                    }

                    var savelogs = new logs({

                        logid: [{
                            userid: new mongoose.Types.ObjectId(photogallerydata.userId),
                            targetid: new mongoose.Types.ObjectId(savePhotogallery._id),
                        }],
                        description: 'PhotoGallery Added In New User',
                        action: 'Add'
                    });
                    savelogs.save(function (err, logs) {
                        if (!err) {
                            deferred.resolve(savelogs);
                        } else {
                            console.log(err);
                            deferred.reject(err.name + ': ' + err.message);
                        }
                    });


                });
            }
        }
        else {
            deferred.reject(err.name + ': ' + err.message);
        }
    })

    return deferred.promise;
}


function getAllphotogallery(userId) {
    var deferred = Q.defer();
    
    photogallery.findOne({ userId: userId }, function (err, getphotogallery) {
        if (!err) {

            deferred.resolve(getphotogallery);
        } else {
            deferred.reject(err.name + ': ' + err.message);
        }
    })
    return deferred.promise;

}

function deletearray(photoid, photoimageid) {

    var maindata = new mongoose.Types.ObjectId(photoid.maindata);
    var imagedata = new mongoose.Types.ObjectId(photoid.imagedata);

    var deferred = Q.defer();

    photogallery.findOne({ userId: maindata }).then(function (getphotogallery) {

        getphotogallery.image.pull({ _id: imagedata });
        getphotogallery.save().then(function (getphotogallery) {
            //do something smart
            if (getphotogallery) {

                return;
            }
        });
    });

    var savelogs = new logs({

        logid: [{
            userid: new mongoose.Types.ObjectId(photoid.userId),
            targetid: new mongoose.Types.ObjectId(photogallery._id),
        }],
        description: 'Image Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    return deferred.promise;
}


function checkboxbutton(checkboxmainid) {

    var userId = new mongoose.Types.ObjectId(checkboxmainid.mainid);

    var deferred = Q.defer();


    photogallery.findOne({ userId: userId }).then(function (getphotogallery) {
        for (let i = 0; i < checkboxmainid.imageid.length; i++) {
            var imageid = new mongoose.Types.ObjectId(checkboxmainid.imageid[i]);
            // checkboximage.pull({ _id: imageid })

            getphotogallery.image.pull({ _id: imageid });

        }
        getphotogallery.save().then(function (getphotogallery) {
            //do something smart
            if (getphotogallery) {

                return;
            }
        });
    });

    // photogallery.findOne({ userId: userId }).then(function (getphotogallery) {
    // for (let i = 0; i < checkboxmainid.imageid.length; i++) {

    // var imageid = new mongoose.Types.ObjectId(checkboxmainid.imageid);

    // getphotogallery.image.pull({ _id: imageid });
    // getphotogallery.save().then(function (getphotogallery) {
    //     //do something smart
    //     if (getphotogallery) {

    //         return;
    //     }
    // });
    // }
    // });

    var savelogs = new logs({
        logid: [{
            userid: new mongoose.Types.ObjectId(userId.userId),
            targetid: new mongoose.Types.ObjectId(photogallery._id),
        }],
        description: 'Image Deleted',
        action: 'Delete'
    });
    savelogs.save(function (err, logs) {
        if (!err) {
            deferred.resolve(savelogs);
        } else {
            console.log(err);
            deferred.reject(err.name + ': ' + err.message);
        }
    });

    return deferred.promise;
}
module.exports = service;