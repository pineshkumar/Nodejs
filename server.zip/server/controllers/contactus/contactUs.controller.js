var express = require('express');
var router = express.Router();

var FooterService = require('../../services/contactUs.service');

router.post('/getFooterBusinessName', getFooterBusinessName)
router.post('/getAboutUsData', getAboutUsData)
router.post('/addSubscriber', addSubscriber)
router.post('/addContactData', addContactData)
router.post('/getStoreTimingData', getStoreTimingData)
router.post('/getcustompagesdetail', getcustompagesdetail)
module.exports = router;


function getFooterBusinessName(req, res) {


    FooterService.getFooterBusinessName(req.body.FooterDetails).then(function (FooterDetails) {
        if (FooterDetails) {

            res.send(FooterDetails);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAboutUsData(req, res) {

    FooterService.getAboutUsData(req.body.AboutUsData).then(function (AboutUsData) {
        if (AboutUsData) {

            res.send(AboutUsData);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// exports.addSubscriber = function (req, res) {
//   console.log('controllerus')
//     FooterService.addSubscriber(req.body)
//         .then(function (getSubscriber) {
//             if (getSubscriber) {
//                 res.send(getSubscriber);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }



function addSubscriber(req, res) {

    FooterService.addSubscriber(req.body).then(function (getSubscriber) {
        if (getSubscriber) {

            res.send(getSubscriber);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getcustompagesdetail(req ,res) {

    FooterService.getcustompagesdetail(req.body.pageid).then(function (customepagedetail) {
        if (customepagedetail) {

            res.send(customepagedetail);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });

}


function addContactData(req, res) {

    FooterService.addContactData(req.body.contactdetail).then(function (contactdetail) {
        if (contactdetail) {

            res.send(contactdetail);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getStoreTimingData(req, res) {

    FooterService.getStoreTimingData(req.body.StoreData).then(function (StoreData) {
        if (StoreData) {

            res.send(StoreData);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}