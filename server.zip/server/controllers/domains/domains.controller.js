var express = require('express');
var router = express.Router();
var domainService = require(  '../../services/domains.service');

// router.post('/adddomainrequest', adddomainrequest);
// router.get('/getAllDomainRequests', getAllDomainRequests);
// router.get('/getAllcompany', getAllcompany);
// router.get('/getDomainRequestsbyId/:domainId', getDomainRequestsbyId);
// router.post('/updateDomainRequests', updateDomainRequests);
// router.delete('/deleteDomainRequests/:domainId/:userId/:name', updateDomainRequests);

exports.adddomainrequest = function(req, res) {
  
    domainService.adddomainrequest(req.body)
    .then(function (domainrequest) {
        if (domainrequest) {
            res.send(domainrequest);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}

exports.getAllDomainRequests = function(req, res) {
  
    domainService.getAllDomainRequests()
    .then(function (domainrequest) {
        if (domainrequest) {
            res.send(domainrequest);
           
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });   
}

exports.getAllcompany = function(req, res) {
  
    domainService.getAllcompany()
    .then(function (company) {
        if (company) {
           
            res.send(company);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
    
}

exports.getDomainRequestsbyId = function(req, res) {
 
    domainService.getDomainRequestsbyId(req.params.domainId)
    .then(function (domainrequest) {
        if (domainrequest) {
            res.send(domainrequest);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });   
}

exports.updateDomainRequests = function(req, res) {
  
    domainService.updateDomainRequests(req.body)
    .then(function (domainrequest) {
        if (domainrequest) {
            res.send(domainrequest);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
    
    
}

exports.deleteDomainRequests = function(req, res) {
    
    domainService.deleteDomainRequests(req.params.domainId,req.params.userId,req.params.name)
    .then(function () {
        res.json('success');
    })
    .catch(function (err) {
        res.status(400).send(err);
    });  

}





    
    






