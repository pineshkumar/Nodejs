var express = require('express');
var router = express.Router();
var siteappearanceService = require('../../services/siteappearance.service');

 //router.post('/getsiteappearances', getsiteappearances);
// router.get('/getsiteappearancebyitsID/:siteappearanceDATA', getsiteappearancebyitsID);
// router.post('/updatesiteappearance', updatesiteappearance);
// module.exports = router;


exports.getsiteappearance = function (req, res) {
    siteappearanceService.getsiteappearance()
        .then(function (getdata) {

            if (getdata) {

                res.send(getdata);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getsiteappearancebyitsID = function (req, res) {

    siteappearanceService.getsiteappearancebyitsID(req.params.siteappearanceDATA)
        .then(function (data) {
            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.updatesiteappearance = function (req, res) {
 
    siteappearanceService.updatesiteappearance(req.body)
        .then(function (data) {
            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}



// function getsiteappearances(req , res) {



// }
// module.exports = router;

// function getsiteappearance(req, res) {

//     siteappearanceService.getsiteappearance()
//         .then(function (getdata) {

//             if (getdata) {

//                 res.send(getdata);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function getsiteappearancebyitsID(req, res) {

//     siteappearanceService.getsiteappearancebyitsID(req.params.siteappearanceDATA)
//         .then(function (data) {
//             if (data) {
//                 res.send(data);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function updatesiteappearance(req, res) {

//     siteappearanceService.updatesiteappearance(req.body)
//         .then(function (data) {
//             if (data) {
//                 res.send(data);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }