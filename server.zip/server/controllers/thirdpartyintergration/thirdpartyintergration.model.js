var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;

var ThirdPartyIntergration = new Schema({

    facebookId: String,
    fullName: String,
    firstName: String,
    lastName: String,
    email: String,
    photoUrl: String,
    provider: String,
    companyid: ObjectId,
    dateadded: { type: Date, default: Date.now },
    datemodified: { type: Date, default: Date.now }
})


module.exports = mongoose.model('thirdpartyintergration', ThirdPartyIntergration);