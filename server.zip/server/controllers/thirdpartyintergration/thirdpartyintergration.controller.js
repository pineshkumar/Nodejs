var express = require('express');
var router = express.Router();
var thirdpartyintergration = require('../../services/thirdpartyintergration.service');

// router.post('/submitFacebookdetails', submitFacebookdetails);


exports.submitFacebookdetails = function (req, res) {
  
    thirdpartyintergration.submitFacebookdetails(req.body)
        .then(function (data) {
            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.getDomainAndEmail = function (req, res) {
    thirdpartyintergration.getDomainAndEmail(req.params.userId)
        .then(function (data) {
            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

