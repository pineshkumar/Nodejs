var express = require('express');
var router = express.Router();
var custompageService = require('../../services/custompage.service');

// router.post('/addcustompage', addcustompage);
// router.get('/getAllcustompage/:userId', getAllcustompage);
// router.get('/getcustompagebyId/:custompageId', getcustompagebyId);
// router.post('/updatecustompage', updatecustompage);
// router.post('/updatetoggle', updatetoggle);
// router.delete('/deletecustompage/:custompageId/:userId/:name', deletecustompage);


exports.addcustompage = function (req, res) {
    custompageService.addcustompage(req.body)
        .then(function (custompage) {
            if (custompage) {
                res.send(custompage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getAllcustompage = function (req, res) {
    custompageService.getAllcustompage(req.params.userId)
        .then(function (custompage) {
            if (custompage) {
                res.send(custompage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.getcustompagebyId = function (req, res) {
    custompageService.getcustompagebyId(req.params.custompageId)
        .then(function (custompage) {
            if (custompage) {
                res.send(custompage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.updatecustompage = function (req, res) {
    custompageService.updatecustompage(req.body)
        .then(function (custompage) {
            if (custompage) {
                res.send(custompage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.updatetoggle = function (req, res) {
    custompageService.updatetoggle(req.body)
        .then(function (custompage) {
            if (custompage) {
                res.send(custompage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.deletecustompage = function (req, res) {
    custompageService.deletecustompage(req.params.custompageId, req.params.userId, req.params.name)
        .then(function () {
            res.json('success');
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


// module.exports = router;
// function addcustompage(req,res)
// {
//     custompageService.addcustompage(req.body)
//     .then(function (custompage) {
//         if (custompage) {
//             res.send(custompage);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getAllcustompage(req,res)
// {
//     custompageService.getAllcustompage(req.params.userId)
//     .then(function (custompage) {
//         if (custompage) {
//             res.send(custompage);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getcustompagebyId(req,res)
// {
//     custompageService.getcustompagebyId(req.params.custompageId)
//     .then(function (custompage) {
//         if (custompage) {
//             res.send(custompage);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updatecustompage(req,res)
// {
//     custompageService.updatecustompage(req.body)
//     .then(function (custompage) {
//         if (custompage) {
//             res.send(custompage);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updatetoggle(req,res)
// {
//     custompageService.updatetoggle(req.body)
//     .then(function (custompage) {
//         if (custompage) {
//             res.send(custompage);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function deletecustompage(req,res)
// {
//     custompageService.deletecustompage(req.params.custompageId,req.params.userId,req.params.name)
//     .then(function () {
//         res.json('success');
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }