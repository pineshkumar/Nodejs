var express = require('express');
var router = express.Router();
var packagesService = require('../../services/packages.service');


//module.exports = router;
exports.getAllPackages = function (req, res) {
   
    return packagesService.getAllPackages()
        .then(function (packages) {
            if (packages) {
                res.send(packages);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
};
// router.post('/addpackage', addpackage);
// //router.get('/getAllPackages', getAllPackages);
// router.get('/getPackagebyId/:packageId', getPackagebyId);
// router.post('/updatepackage', updatepackage);
// router.post('/updatetoggle', updatetoggle);
// router.delete('/deletepackage/:packageId/:userId/:name', deletepackage);



exports.addpackage = function (req, res) {


    packagesService.addpackage(req.body)
        .then(function (package) {
            if (package) {

                res.send(package);
            } else {

                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}



exports.getPackagebyId = function (req, res) {

    packagesService.getPackagebyId(req.params.packageId)
        .then(function (packages) {
            if (packages) {
                res.send(packages);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.updatepackage = function (req, res) {

    packagesService.updatepackage(req.body)
        .then(function (package) {
            if (package) {
                res.send(package);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.updatetoggle = function (req, res) {

    packagesService.updatetoggle(req.body)
        .then(function (package) {

            if (package) {
                res.send(package);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}


exports.deletepackage = function (req, res) {
    packagesService.deletepackage(req.params.packageId, req.params.userId, req.params.name)
        .then(function (data) {
           
            res.json(data);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}




// function getPackagebyId(req,res)
// {
//     packagesService.getPackagebyId(req.params.packageId)
//     .then(function (packages) {
//         if (packages) {
//             res.send(packages);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updatepackage(req,res)
// {
//     packagesService.updatepackage(req.body)
//     .then(function (package) {
//         if (package) {
//             res.send(package);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updatetoggle(req,res)
// {

//     packagesService.updatetoggle(req.body)
//     .then(function (package) {

//         if (package) {
//             res.send(package);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }


// function deletepackage(req,res)
// {
//     packagesService.deletepackage(req.params.packageId,req.params.userId,req.params.name)
//     .then(function () {

//         res.json('data');
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }



