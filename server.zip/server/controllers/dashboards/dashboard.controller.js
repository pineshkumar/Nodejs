var express = require('express');
var router = express.Router();
var dashboardService = require('../../services/dashboards.service');

exports.getAllcountspackges = function (req, res) {

    dashboardService.getAllcountspackges(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
         
                res.send({ 'Packages': allcounts });
               
            } else {
                res.send({ 'Packages': 0 });
            }
        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send(err);
        });
}

exports.getAllcountsdomainRequest = function (req, res) {

    dashboardService.getAllcountsdomainRequest(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
               
                res.send({ 'countDomainRequest': allcounts });
            } else {
                res.send({ 'countDomainRequest': 0 });
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllcountscompanies = function (req, res) {

    dashboardService.getAllcountscompanies(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
               
                res.send({ 'countCompanies': allcounts });
            } else {
                res.send({ 'countCompanies': 0 });
                // res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllcountsResellers = function (req, res) {

    dashboardService.getAllcountsResellers(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
                
                res.send({ 'countReseller': allcounts });
            } else {
                res.send({ 'countReseller': 0 });
                // res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllcountsUpdates = function (req, res) {

    dashboardService.getAllcountsUpdates(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
                
                res.send({ 'countUpdates': allcounts });
            } else {
                res.send({ 'countUpdates': 0 });
                // res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllcountsProducts = function (req, res) {

    dashboardService.getAllcountsProducts(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
                
                res.send({ 'countProducts': allcounts });
            } else {
                res.send({ 'countProducts': 0 });
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.getAllcountsSubscriber = function (req, res) {

    dashboardService.getAllcountsSubscriber(req.params.userId)

        .then(function (allcounts) {
            if (allcounts) {
               
                res.send({ 'countSubscriber': allcounts });
            } else {
                res.send({ 'countSubscriber': 0 });
                //res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}