var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;

var ResellersSchema = new Schema({
    firstname: String,
    address: String,
    city: String,
    primaryNumber: Number,
    userType: String,
    email: String,
    username: String,
    password: String,
    accesscode: String,
    status: Boolean,
    dateadded: { type: Date, default: Date.now },
    datemodified: { type: Date, default: Date.now },

})
// set up a mongoose model

module.exports = mongoose.model('users', ResellersSchema);