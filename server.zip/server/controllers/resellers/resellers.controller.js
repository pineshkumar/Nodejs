var express = require('express');
var router = express.Router();
var resellersService = require('../../services/resellers.service');

// router.post('/addresellers', addresellers);
// router.get('/getAllresellers', getAllresellers);
// router.get('/getresellersbyId/:resellersId', getresellersbyId);
// router.post('/updateresellers', updateresellers);
// router.post('/updatetoggle', updatetoggle);
// router.delete('/deleteresellers/:resellersId/:userId/:name', deleteresellers);


exports.addresellers = function (req, res) {

    resellersService.addresellers(req.body)
        .then(function (reseller) {
            if (reseller) {
                res.send(reseller);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllresellers = function (req, res) {

    resellersService.getAllresellers()
        .then(function (resellers) {
            if (resellers) {
                res.send(resellers);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });


}

exports.getresellersbyId = function (req, res) {

    resellersService.getresellersbyId(req.params.resellersId)
        .then(function (resellers) {
            if (resellers) {
                res.send(resellers);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.updateresellers = function (req, res) {

    resellersService.updateresellers(req.body)
        .then(function (resellers) {
            if (resellers) {
                res.send(resellers);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.updatetoggle = function (req, res) {

    resellersService.updatetoggle(req.body)
        .then(function (resellers) {
            if (resellers) {
                res.send(resellers);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}
exports.deleteresellers = function (req, res) {

   
    resellersService.deleteresellers(req.params.resellersId, req.params.userId, req.params.name)
        .then(function () {
            res.json('success');
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}







// module.exports = router;
// function addresellers(req,res)
// {
//     resellersService.addresellers(req.body)
//     .then(function (reseller) {
//         if (reseller) {
//             res.send(reseller);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getAllresellers(req,res)
// {
//     resellersService.getAllresellers()
//     .then(function (resellers) {
//         if (resellers) {
//             res.send(resellers);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getresellersbyId(req,res)
// {
//     resellersService.getresellersbyId(req.params.resellersId)
//     .then(function (resellers) {
//         if (resellers) {
//             res.send(resellers);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updateresellers(req,res)
// {
//     resellersService.updateresellers(req.body)
//     .then(function (resellers) {
//         if (resellers) {
//             res.send(resellers);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }


// function updatetoggle(req,res)
// {
//     resellersService.updatetoggle(req.body)
//     .then(function (resellers) {
//         if (resellers) {
//             res.send(resellers);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }



// function deleteresellers(req,res)

// {

//     resellersService.deleteresellers(req.params.resellersId,req.params.userId,req.params.name)
//     .then(function () {
//         res.json('success');
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

