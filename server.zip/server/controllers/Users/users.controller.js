var express = require('express');
var router = express.Router();
var userService = require('../../services/users.service');

router.post('/authenticate', authenticate);
router.get('/getprofileInfo/:loginId', getprofileInfo);
router.post('/updateprofile', updateprofile);

module.exports = router;

function authenticate(req, res) {
    userService.authenticate(req.body.username, req.body.password)

        .then(function (user) {
            if (user) {

                res.send(user);
            } else {
                // authentication failed
                res.status(400).send('Username or password is incorrect');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getprofileInfo(req, res) {
    userService.getprofileInfo(req.params.loginId)
        .then(function (user) {
            if (user) {
                res.send(user);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateprofile(req, res) {
   
    userService.updateprofile(req.body)
        .then(function (user) {
            if (user) {
                res.send(user);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}



