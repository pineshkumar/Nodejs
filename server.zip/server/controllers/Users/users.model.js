var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;

var UserSchema = new Schema({
    firstname: String,
    lastname: String,
    businessName: String,
    address: String,
    city: String,
    latitude: String,
    longitude: String,
    country: String,
    pinCode: Number,
    description:String,
    primaryNumber: Number,
    alternativeNumber: Number,
    otherWebsite: String,
    facebookUrl: String,
    twitterUrl: String,
    userType: String,
    username: String,
    email: String,
    password: String,
    status: Boolean,
    packageid: ObjectId,
    themeid: ObjectId,
    domainName: String,
    accesscode: String,
    imagelogo: [{
		url: { type: String },
		dateadded: { type: Date, default: Date.now },
    }],
    faviconlogo: [{
		url: { type: String },
		dateadded: { type: Date, default: Date.now },
  }],
 
  bannerImage: [{
		url: { type: String },
		dateadded: { type: Date, default: Date.now },
	}],
    dateadded: { type: Date, default: Date.now },
    datemodified: { type: Date, default: Date.now }
})
// set up a mongoose model

module.exports = mongoose.model('Users', UserSchema);