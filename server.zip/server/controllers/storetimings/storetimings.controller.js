var express = require('express');
var router = express.Router();
var storetimingService = require('../../services/storetiming.service');


exports.getmystoretiming = function (req, res) {


    storetimingService.getmystoretiming(req.params.companyid)
        .then(function (usage) {
            if (usage) {
                res.send(usage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.getAllDatatiming = function (req, res) {
  
    storetimingService.getAllDatatiming(req.params.userId)
        .then(function (data) {
         
            if (data) {

                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}
// exports.updatestoretime = function (req, res) {


//     storetimingService.updatestoretime(req.params.companyid)
//         .then(function (usage) {
//             if (usage) {
//                 res.send(usage);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }
exports.updatestoretime = function (req, res) {
    
    storetimingService.updatestoretime(req.body)
        .then(function (storetiming) {
            if (storetiming) {
                res.send(storetiming);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}