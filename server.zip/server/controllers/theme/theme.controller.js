var express = require('express');
var router = express.Router();
// var siteappearanceService = require('../../services/siteappearance.service');

var themeService = require('../../services/themes.service');


router.post('/getalltheme', getalltheme);
router.post('/getlogos', getlogos);

module.exports = router;

function getalltheme(req , res) {

    themeService.getalltheme(req.body.urlname).then(function (gettheme) {
        if (gettheme) {

            res.send(gettheme);
        } else {
            // authentication failed
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });

    
}
function getlogos(req , res) {

    
    themeService.getlogos(req.body.userId).then(function (gettheme) {
        if (gettheme) {

            res.send(gettheme);
        } else {
            // authentication failed
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });

    
}




