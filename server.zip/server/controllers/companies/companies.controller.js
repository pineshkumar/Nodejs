var express = require('express');
var router = express.Router();
var companiesService = require('../../services/companies.service');


// router.post('/addcompany', addcompany);
// router.get('/getAllcompany', getAllcompany);
// router.get('/getAllPackages', getAllPackages);
// router.get('/getcompanybyId/:companyId', getcompanybyId);
// router.get('/getthemebyID/', getthemebyID);
// router.post('/updatecompany', updatecompany);
// router.post('/updatetoggle', updatetoggle);
// router.delete('/deletecompany/:companyId/:userId/:name', deletecompany);

exports.addcompany = function (req, res) {
    // console.log(req.body);
    // return false;
    companiesService.addcompany(req.body)
        .then(function (company) {
            if (company) {
                res.send(company);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.getAllcompany = function (req, res) {

    companiesService.getAllcompany()
        .then(function (company) {
            if (company) {
                res.send(company);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.getAllPackages = function (req, res) {

    companiesService.getAllPackages()
        .then(function (packages) {
            if (packages) {
                res.send(packages);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.getcompanybyId = function (req, res) {

    companiesService.getcompanybyId(req.params.companyId)
        .then(function (company) {
            if (company) {
                res.send(company);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.getthemebyID = function (req, res) {

    companiesService.getthemebyID(req.params)
        .then(function (theme) {
            if (theme) {
                res.send(theme);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.updatecompany = function (req, res) {

    companiesService.updatecompany(req.body)
        .then(function (company) {
            if (company) {
                res.send(company);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.updatetoggle = function (req, res) {

    companiesService.updatetoggle(req.body)
        .then(function (company) {
            if (company) {
                res.send(company);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.deletecompany = function (req, res) {


    // return false;
    companiesService.deletecompany(req.params.companyId, req.params.userId, req.params.name)
        .then(function (data) {
            res.json(data);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


