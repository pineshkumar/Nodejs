var express = require('express');
var router = express.Router();
var settingService = require('../../services/settings.service')

 
exports.getAllusage = function (req, res) {


    settingService.getAllusage()
    .then(function (usage) {
        if (usage) {    
            res.send(usage);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        console.log(err);
        res.status(400).send(err);
    });


}

exports.deleteusage = function (req, res) {

    settingService.deleteusage(req.params.id,req.params.userId,req.params.name)
    .then(function (data) {
      
        res.json(data);
    })
    .catch(function (err) {
        res.status(400).send(err);
    });


}

exports.updatetoggle = function (req, res) {
  
    settingService.updatetoggle(req.body)
        .then(function (usage) {
            if (usage) {
                res.send(usage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });   
}


exports.getUsagebyId = function (req, res) {
  
    settingService.getUsagebyId(req.params.UsageId)
        .then(function (usage) {
            if (usage) {
                res.send(usage);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    
}
exports.updateusage = function (req , res) {

    settingService.updateusage(req.body)
   .then(function (usage) {
       if (usage) {
           res.send(usage);
       } else {
           res.sendStatus(404);
       }
   })
   .catch(function (err) {
       res.status(400).send(err);
   });   
}
// updateusage

