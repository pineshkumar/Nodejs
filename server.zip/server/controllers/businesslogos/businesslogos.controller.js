var express = require('express');
var router = express.Router();
var businesslogoService = require('../../services/businesslogos.service');


exports.addagainbusinesslogo = function (req, res) {
   
    businesslogoService.addagainbusinesslogo(req.body)
        .then(function (businesslogo) {
            if (businesslogo) {
          
                res.send(businesslogo);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        }); 
}

exports.getallbusinesslogo = function (req, res) {
    
    businesslogoService.getallbusinesslogo(req.params.userId)
        .then(function (businesslogo) {
           
            if (businesslogo) {
                res.send(businesslogo);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        }); 
}


exports.addBenerLogoMultiple = function(req, res) {
 
    businesslogoService.addBenerLogoMultiple(req.body)
        .then(function (data) {
            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    }


    exports.deleteBannerarray = function(req, res) {
 
        businesslogoService.deleteBannerarray(req.body)
            .then(function (bannerArray) {
                if (bannerArray) {
                    res.send(bannerArray);
                } else {
                    res.sendStatus(404);
                }
            })
            .catch(function (err) {
                res.status(400).send(err);
            });
    
    }






