var express = require('express');
var router = express.Router();
var passwordService = require('../../services/password.service');

router.post('/passwordmatch', passwordmatch);
router.post('/sendlink', sendlink);
router.post('/resetpassword', resetpassword);

module.exports = router;

// exports.passwordmatch = function(req,res) {

//    //return false;
//     passwordService.passwordmatch(req.body)
  
//         .then(function (password) {
//             if (password) {
                
//                 res.send(password);
//             } else {
//                 // authentication failed
//                 res.status(400).send('Username or password is incorrect');
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }
// exports.sendlink = function(req,res) {

// //    return false;
//     passwordService.sendlink(req.body,req.headers.origin)
  
//         .then(function (sendlink) {
//             if (sendlink) {
                
//                 res.send(sendlink);
//             } else {
//                 // authentication failed
//                 res.status(400).send('email');
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });  
// }
// exports.resetpassword = function(req,res) {

//     passwordService.resetpassword(req.body)
  
//         .then(function (resetpassword) {
//             if (resetpassword) {
                
//                 res.send(resetpassword);
//             } else {
//                 // authentication failed
//                 res.status(400).send('Password Reset');
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }






function passwordmatch(req,res)
{

    passwordService.passwordmatch(req.body)
  
        .then(function (password) {
            if (password) {
                
                res.send(password);
            } else {
                // authentication failed
                res.status(400).send('Username or password is incorrect');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function sendlink(req,res)
{

    passwordService.sendlink(req.body,req.headers.origin)
  
        .then(function (sendlink) {
            if (sendlink) {
                
                res.send(sendlink);
            } else {
                // authentication failed
                res.status(400).send('email');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}



function resetpassword(req,res)
{

    passwordService.resetpassword(req.body)
  
        .then(function (resetpassword) {
            if (resetpassword) {
                
                res.send(resetpassword);
            } else {
                // authentication failed
                res.status(400).send('Password Reset');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

