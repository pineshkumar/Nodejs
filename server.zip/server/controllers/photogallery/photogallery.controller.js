var express = require('express');
var router = express.Router();
var photogalleryService = require('../../services/photogallery.service');


// router.post('/addagainphotpgallery', addagainphotpgallery);
// router.get('/getAllphotogallery/:userId', getAllphotogallery);
// router.post('/deletearray', deletearray);
// router.post('/checkboxbutton', checkboxbutton);

// module.exports = router;

exports.addagainphotpgallery = function(req, res) {

    photogalleryService.addagainphotpgallery(req.body)
        .then(function (photogallery) {
            if (photogallery) {
                res.send(photogallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.getAllphotogallery = function(req, res) {
    
    photogalleryService.getAllphotogallery(req.params.userId)
        .then(function (photogallery) {
            if (photogallery) {
               
                res.send(photogallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

exports.deletearray = function(req, res) {
    
    photogalleryService.deletearray(req.body)
        .then(function (photogallery) {
            if (photogallery) {
                res.send(photogallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.checkboxbutton = function(req, res) {
    
    photogalleryService.checkboxbutton(req.body)
        .then(function (photogallery) {
            if (photogallery) {
                res.send(photogallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });   
}







// function addagainphotpgallery(req, res) {

//     photogalleryService.addagainphotpgallery(req.body)
//         .then(function (photogallery) {
//             if (photogallery) {
//                 res.send(photogallery);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }


// function getAllphotogallery(req, res) {
//     photogalleryService.getAllphotogallery(req.params.userId)
//         .then(function (photogallery) {
//             if (photogallery) {

//                 res.send(photogallery);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function deletearray(req, res) {

//     photogalleryService.deletearray(req.body)
//         .then(function (photogallery) {
//             if (photogallery) {
//                 res.send(photogallery);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function checkboxbutton(req, res) {

//     photogalleryService.checkboxbutton(req.body)
//         .then(function (photogallery) {
//             if (photogallery) {
//                 res.send(photogallery);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }
