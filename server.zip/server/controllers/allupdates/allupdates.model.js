var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;

var AllupdatesSchema = new Schema({

    image: [{
        url: { type: String },
        checkbox: { type: String }
    }],
    companyid: ObjectId,
    message: String,
    customerlist: String,
    onweb: Boolean,
    onapp: Boolean,
    facebook: Boolean,
    twitter: Boolean,
    subscribe: Boolean,
    timer: String,
    view: Number,
    dateadded: { type: Date, default: Date.now },
    datemodified: { type: Date, default: Date.now },


})
// set up a mongoose model

module.exports = mongoose.model('allupdates', AllupdatesSchema);