var express = require('express');
var router = express.Router();
var allupdateService = require('../../services/allupdates.service');

// router.post('/addagainallupdates', addagainallupdates);
// router.get('/getAllallupdates/:userId', getAllallupdates);
// router.delete('/deleteallupdates/:allupdatesId/:userId/:name', deleteallupdates);


exports.addagainallupdates = function (req, res) {

    allupdateService.addagainallupdates(req.body)
        .then(function (allupdates) {
            if (allupdates) {
                res.send(allupdates);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getAllallupdates = function (req, res) {
    allupdateService.getAllallupdates(req.params.userId)
        .then(function (allupdates) {
            if (allupdates) {
                res.send(allupdates);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.updatetoggle = function (req, res) {

    allupdateService.updatetoggle(req.body)
        .then(function (data) {

            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.updatetoggleagain = function (req, res) {

    allupdateService.updatetoggleagain(req.body)
        .then(function (data) {

            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}


exports.deleteallupdates = function (req, res) {

    allupdateService.deleteallupdates(req.params.allupdatesId, req.params.userId, req.params.name)
        .then(function () {
            res.json('success');
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// module.exports = router;

// function addagainallupdates(req, res) {

//     allupdateService.addagainallupdates(req.body)
//         .then(function (allupdates) {
//             if (allupdates) {
//                 res.send(allupdates);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function getAllallupdates(req, res) {
//     allupdateService.getAllallupdates(req.params.userId)
//         .then(function (allupdates) {
//             if (allupdates) {
//                 res.send(allupdates);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

// function deleteallupdates(req, res) {

//     // return false;
//     allupdateService.deleteallupdates(req.params.allupdatesId, req.params.userId, req.params.name)
//         .then(function () {
//             res.json('success');
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }