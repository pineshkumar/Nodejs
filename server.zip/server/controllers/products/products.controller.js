var express = require('express');
var router = express.Router();
var productsService = require('../../services/products.services');

router.post('/getallproducts', getallproducts);
router.post('/getReservedBusinessName', getReservedBusinessName);
// router.post('/addcontactdetail' , addcontactdetail);
router.post('/getproduct', getproduct);
router.post('/addquerydetail', addquerydetail);
router.post('/getproductcategorieslist', getproductcategorieslist);
router.post('/getselectproductlist' , getselectproductlist);
router.post('/getupdatesproductslist' , getupdatesproductslist);
router.post('/getupdateproduct' , getupdateproduct);
router.post('/getgallerylist' , getgallerylist);
router.post('/updateproductvalue' , updateproductvalue);
router.post ('/updateallproductvalue' , updateallproductvalue);
router.post('/getlogos' , getlogos);
router.post('/gethomegallerylist' , gethomegallerylist);
router.post('/gethomeupdatesproductslist' , gethomeupdatesproductslist);
router.post('/gethomeselectproductlist' , gethomeselectproductlist);
router.post('/gethomeproductslist', gethomeproductslist);
router.post('/gethomepagebanner', gethomepagebanner);
router.post('/gethomepageagainproductslist' , gethomepageagainproductslist);
router.post('/getagainupdatesproductslist' , getagainupdatesproductslist);
router.post('/getagainproductlist' , getagainproductlist);


module.exports = router;

function getallproducts(req, res) {

    productsService.getallproducts(req.body.companyid).then(function (allproduct) {
        if (allproduct) {

            res.send(allproduct);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });


}



function getReservedBusinessName(req, res) {



    productsService.getReservedBusinessName(req.body.userId).then(function (conatctdetail) {
        if (conatctdetail) {

            res.send(conatctdetail);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


// function addcontactdetail(req, res) {

//     productsService.addcontactdetail(req.body.contactdetail).then(function (conatctdetail) {
//         if (conatctdetail) {

//             res.send(conatctdetail);
//         } else {            

//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }


function getproduct(req, res) {


    productsService.getproduct(req.body.productid).then(function (product) {
        if (product) {

            res.send(product);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function addquerydetail(req, res) {


    productsService.addquerydetail(req.body.query).then(function (query) {
        if (query) {

            res.send(query);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}



function getproductcategorieslist(req, res) {

    productsService.getproductcategorieslist(req.body.companyid).then(function (productcat) {
        if (productcat) {

            res.send(productcat);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });


}


function getselectproductlist(req, res) {

    productsService.getselectproductlist(req.body.productid).then(function (selectproduct) {
        if (selectproduct) {

            res.send(selectproduct);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getupdatesproductslist(req, res) {


    productsService.getupdatesproductslist(req.body.companyid).then(function (updateproduct) {
        if (updateproduct) {

            res.send(updateproduct);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getupdateproduct(req, res) {

    productsService.getupdateproduct(req.body.productid).then(function (updatepro) {
        if (updatepro) {

            res.send(updatepro);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function getgallerylist(req, res) {

    productsService.getgallerylist(req.body.companyid).then(function (selectproduct) {
        if (selectproduct) {

            res.send(selectproduct);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function updateproductvalue(req , res) {
  
    productsService.updateproductvalue(req.body.count ,req.body.productid).then(function (updateproducts) {
        if (updateproducts) {

          
            res.send(updateproducts);
        } else {            

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function updateallproductvalue(req , res) {
  
    productsService.updateallproductvalue(req.body.count ,req.body.productid).then(function (allupdateproducts) {
        if (allupdateproducts) {

            res.send(allupdateproducts);
        } else {            

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function getlogos(req, res) {
 
    productsService.getlogos(req.body.userId).then(function (logo) {
        if (logo) {

            res.send(logo);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}

function gethomegallerylist (req , res) {
 
 
    productsService.gethomegallerylist(req.body.companyid).then(function (gallerylist) {
        if (gallerylist) {

            res.send(gallerylist);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function gethomeupdatesproductslist(req , res) {
   


    productsService.gethomeupdatesproductslist(req.body.companyid).then(function (productlist) {
        if (productlist) {

            res.send(productlist);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function gethomeselectproductlist(req, res) {

   
    productsService.gethomeselectproductlist(req.body.productid).then(function (selectproductlist) {
        if (selectproductlist) {

            res.send(selectproductlist);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}

function gethomeproductslist(req, res) {

    productsService.gethomeproductslist(req.body.companyid ).then(function (product) {
        if (product) {

            res.send(product);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function gethomepagebanner(req, res) {
    
    productsService.gethomepagebanner(req.body.userId).then(function (homepagebanner) {
        if (homepagebanner) {

            res.send(homepagebanner);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });

}

function gethomepageagainproductslist(req, res) {
    
    productsService.gethomepageagainproductslist(req.body.companyid).then(function (product) {
        if (product) {

            res.send(product);
        } else {

            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}


function getagainupdatesproductslist(req, res) {

    productsService.getagainupdatesproductslist(req.body.companyid).then(function (againupdateproduct) {
        if (againupdateproduct) {

            res.send(againupdateproduct);
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

function getagainproductlist(req , res) {
  
   
    productsService.getagainproductlist(req.body.catNameid , req.body.productid).then(function (againproductlist) {
        if (againproductlist) {

         
            res.send(againproductlist); 
        } else {

            res.sendStatus(404);
        }
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}