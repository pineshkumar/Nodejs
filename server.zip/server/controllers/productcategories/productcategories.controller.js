var express = require('express');
var router = express.Router();
var companiesService = require('../../services/companies.service');


// router.post('/addproductcategories', addcategory);

// router.post('/addproductcategories', addproductcategories);
// router.get('/getAllproductcategories/:userId', getAllproductcategories);
// router.get('/getproductcategoriesbyId/:productcategoriesId', getproductcategoriesbyId);
// router.post('/updateproductcategories', updateproductcategories);
// router.post('/updatetoggleone', updatetoggleone);
// router.delete('/deleteproductcategories/:productcategoriesId/:userId/:name', deleteproductcategories);

// exports.addcategory = function (req,res) {
// error1
// }
exports.addproductcategories = function (req,res) { 
   
    companiesService.addproductcategories(req.body)
    .then(function (productcategories) {
        if (productcategories) {
            res.send(productcategories);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });     
}
exports.getAllproductcategories = function (req,res) { 
    
   
    companiesService.getAllproductcategories(req.params.userId)
    .then(function (productcategories) {
        
        if (productcategories) {
            res.send(productcategories);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });  
}

exports.getproductcategoriesbyId = function (req,res) {  
  
    companiesService.getproductcategoriesbyId(req.params.productcategoriesId)
    .then(function (productcategories) {
        if (productcategories) {
            res.send(productcategories);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    }); 
}
exports.updateproductcategories = function (req,res) { 
    

    companiesService.updateproductcategories(req.body)
    .then(function (productcategories) {
        if (productcategories) {
            res.send(productcategories);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });     
}
exports.updatetoggleone = function (req,res) {
  
    companiesService.updatetoggleone(req.body)
    .then(function (productcategories) {
      
        if (productcategories) {
            res.send(productcategories);
        } else {
            res.sendStatus(404);
        }
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
    
}
exports.deleteproductcategories = function (req,res) {
 
    companiesService.deleteproductcategories(req.params.productcategoriesId,req.params.userId,req.params.name)
    .then(function (data) {
        res.json(data);
    })
    .catch(function (err) {
        res.status(400).send(err);
    });    
}

// module.exports = router;

// function addproductcategories(req,res)
// {

//     companiesService.addproductcategories(req.body)
//     .then(function (productcategories) {
//         if (productcategories) {
//             res.send(productcategories);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getAllproductcategories(req,res)
// {
    

//     companiesService.getAllproductcategories(req.params.userId)
//     .then(function (productcategories) {
        
//         if (productcategories) {
//             res.send(productcategories);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function getproductcategoriesbyId(req,res)
// {
//     companiesService.getproductcategoriesbyId(req.params.productcategoriesId)
//     .then(function (productcategories) {
//         if (productcategories) {
//             res.send(productcategories);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updateproductcategories(req,res)
// {
//     companiesService.updateproductcategories(req.body)
//     .then(function (productcategories) {
//         if (productcategories) {
//             res.send(productcategories);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }

// function updatetoggleone(req,res)
// {
//     companiesService.updatetoggleone(req.body)
//     .then(function (productcategories) {

//         if (productcategories) {
//             res.send(productcategories);
//         } else {
//             res.sendStatus(404);
//         }
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }



// function deleteproductcategories(req,res)
// {
//     companiesService.deleteproductcategories(req.params.productcategoriesId,req.params.userId,req.params.name)
//     .then(function () {
//         res.json('Success');
//     })
//     .catch(function (err) {
//         res.status(400).send(err);
//     });
// }


