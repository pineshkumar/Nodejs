var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;

var ProductgallerySchema = new Schema({

    companyid: ObjectId,
    catNameid: ObjectId,
    proName: String,
    description: String,
    currencynameid: ObjectId,
    image: [{
        url: { type: String },
        checkbox: { type: String }
    }],
    youtube: String,
    checkboxtoggle: Boolean,
    productprice: String,
    discountprice: String,
    shippingcharge: String,
    transactionprice: String,
    netamount: String,
    onlinelink: String,
    priority: String,
    onweb: Boolean,
    onapp: Boolean,
    productavailability: Boolean,
    freeshipping: Boolean,
    facebook: Boolean,
    twitter: Boolean,
    subscribe: Boolean,
    view: Number,
    status:Boolean,
    dateadded: { type: Date, default: Date.now },
    datemodified: { type: Date, default: Date.now }


})
// set up a mongoose model

module.exports = mongoose.model('productgalleries', ProductgallerySchema);