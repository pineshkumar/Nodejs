var express = require('express');
var router = express.Router();
var companiesService = require('../../services/companies.service');


// router.post('/addagaingallery', addagaingallery);
// router.get('/getAllproductgallery/:userId', getAllproductgallery);
// router.get('/getproductcategories/:userId', getproductcategories);
// // router.get('/getcurrencyname', getcurrencyname);
// // router.get('/getproductname', getproductname);
// router.get('/getproductgallerybyId/:productgalleryId', getproductgallerybyId);
// router.get('/filtercategory/:categoryid', filtercategory);
// router.post('/updateagainproductgallery', updateagainproductgallery);
// router.post('/deletearray', deletearray);
// router.delete('/deleteproductgallery/:productgalleryId/:userId/:name', deleteproductgallery);


exports.addagaingallery = function (req, res) {

    companiesService.addagaingallery(req.body)
        .then(function (productgallery) {
            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getAllproductgallery = function (req, res) {

    companiesService.getAllproductgallery(req.params.userId)
        .then(function (productgallery) {
            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getproductcategories = function (req, res) {

    companiesService.getproductcategories(req.params.userId)
        .then(function (productcategories) {
            if (productcategories) {

                res.send(productcategories);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.getproductgallerybyId = function (req, res) {

    companiesService.getproductgallerybyId(req.params.productgalleryId)
        .then(function (productgallery) {

            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.filtercategory = function (req, res) {

    companiesService.filtercategory(req.params.categoryid)
        .then(function (productgallery) {

            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
exports.updateagainproductgallery = function (req, res) {

    companiesService.updateagainproductgallery(req.body)
        .then(function (productgallery) {
            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}
exports.deletearray = function (req, res) {

    companiesService.deletearray(req.body)
        .then(function (productgallery) {
            if (productgallery) {
                res.send(productgallery);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.onwebupdatetoggle = function (req, res) {

    companiesService.onwebupdatetoggle(req.body)
        .then(function (data) {

            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.onAPPupdatetoggle = function (req, res) {
  
    companiesService.onAPPupdatetoggle(req.body)
        .then(function (data) {

            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.Statusupdatetoggle = function (req, res) {
 
    companiesService.Statusupdatetoggle(req.body)
        .then(function (data) {

            if (data) {
                res.send(data);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

exports.deleteproductgallery = function (req, res) {
    companiesService.deleteproductgallery(req.params.productgalleryId, req.params.userId, req.params.name)
        .then(function () {
            res.json('success');
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


exports.productgalleryimagestatus = function (req, res) {

    companiesService.productgalleryimagestatus(req.body)
        .then(function (productcategories) {

            if (productcategories) {
                res.send(productcategories);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

}

