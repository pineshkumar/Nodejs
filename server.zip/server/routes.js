var express = require('express');
var router = express.Router();

// Require controller modules.
var packagedata = require('./controllers/packages/packages.controller');

router.get('/packages/getAllPackages', packagedata.getAllPackages);
router.post('/packages/addpackage', packagedata.addpackage);
router.get('/packages/getPackagebyId/:packageId', packagedata.getPackagebyId);
router.post('/packages/updatepackage', packagedata.updatepackage)
router.post('/packages/updatetoggle', packagedata.updatetoggle)
router.delete('/packages/deletepackage/:packageId/:userId/:name', packagedata.deletepackage)


var resellerdata = require('./controllers/resellers/resellers.controller');

router.post('/resellers/addresellers', resellerdata.addresellers);
router.get('/resellers/getAllresellers', resellerdata.getAllresellers);
router.get('/resellers/getresellersbyId/:resellersId', resellerdata.getresellersbyId);
router.post('/resellers/updateresellers', resellerdata.updateresellers);
router.post('/resellers/updatetoggle', resellerdata.updatetoggle);
router.delete('/resellers/deleteresellers/:resellersId/:userId/:name', resellerdata.deleteresellers);


var companiedata = require('./controllers/companies/companies.controller');

router.post('/companies/addcompany', companiedata.addcompany);
router.get('/companies/getAllcompany', companiedata.getAllcompany);
router.get('/companies/getAllPackages', companiedata.getAllPackages);
router.get('/companies/getcompanybyId/:companyId', companiedata.getcompanybyId);
router.get('/companies/getthemebyID', companiedata.getthemebyID);
router.post('/companies/updatecompany', companiedata.updatecompany);
router.post('/companies/updatetoggle', companiedata.updatetoggle);
router.delete('/companies/deletecompany/:companyId/:userId/:name', companiedata.deletecompany);


var domaindata = require('./controllers/domains/domains.controller');

router.post('/domains/adddomainrequest', domaindata.adddomainrequest);
router.get('/domains/getAllDomainRequests', domaindata.getAllDomainRequests);
router.get('/domains/getAllcompany', domaindata.getAllcompany);
router.get('/domains/getDomainRequestsbyId/:domainId', domaindata.getDomainRequestsbyId);
router.post('/domains/updateDomainRequests', domaindata.updateDomainRequests);
router.delete('/domains/deleteDomainRequests/:domainId/:userId/:name', domaindata.deleteDomainRequests);




var productcategoriedata = require('./controllers/productcategories/productcategories.controller');

router.post('/productcategories/addproductcategories', productcategoriedata.addproductcategories);
router.get('/productcategories/getAllproductcategories/:userId', productcategoriedata.getAllproductcategories);
router.get('/productcategories/getproductcategoriesbyId/:productcategoriesId', productcategoriedata.getproductcategoriesbyId);
router.post('/productcategories/updateproductcategories', productcategoriedata.updateproductcategories);
router.post('/productcategories/updatetoggleone', productcategoriedata.updatetoggleone);
router.delete('/productcategories/deleteproductcategories/:productcategoriesId/:userId/:name', productcategoriedata.deleteproductcategories);



var productgallerydata = require('./controllers/productgallery/productgallery.controller');

router.post('/productgallery/addagaingallery', productgallerydata.addagaingallery);
router.get('/productgallery/getAllproductgallery/:userId', productgallerydata.getAllproductgallery);
router.get('/productgallery/getproductcategories/:userId', productgallerydata.getproductcategories);
router.get('/productgallery/getproductgallerybyId/:productgalleryId', productgallerydata.getproductgallerybyId);
router.get('/productgallery/filtercategory/:categoryid', productgallerydata.filtercategory);
router.post('/productgallery/updateagainproductgallery', productgallerydata.updateagainproductgallery);
router.post('/productgallery/deletearray', productgallerydata.deletearray);
router.delete('/productgallery/deleteproductgallery/:productgalleryId/:userId/:name', productgallerydata.deleteproductgallery);
router.post('/productgallery/productgalleryimagestatus', productgallerydata.productgalleryimagestatus);
router.post('/productgallery/onwebupdatetoggle', productgallerydata.onwebupdatetoggle);
router.post('/productgallery/onAPPupdatetoggle', productgallerydata.onAPPupdatetoggle);
router.post('/productgallery/Statusupdatetoggle', productgallerydata.Statusupdatetoggle);

var photogallerydata = require('./controllers/photogallery/photogallery.controller');

router.post('/photogallery/addagainphotpgallery', photogallerydata.addagainphotpgallery);
router.get('/photogallery/getAllphotogallery/:userId', photogallerydata.getAllphotogallery);
router.post('/photogallery/deletearray', photogallerydata.deletearray);
router.post('/photogallery/checkboxbutton', photogallerydata.checkboxbutton);


var allupdatedata = require('./controllers/allupdates/allupdates.controller');

router.post('/allupdates/addagainallupdates', allupdatedata.addagainallupdates);
router.get('/allupdates/getAllallupdates/:userId', allupdatedata.getAllallupdates);
router.delete('/allupdates/deleteallupdates/:allupdatesId/:userId/:name', allupdatedata.deleteallupdates);
router.post('/allupdates/updatetoggle', allupdatedata.updatetoggle);
router.post('/allupdates/updatetoggleagain', allupdatedata.updatetoggleagain);

var currencydata = require('./controllers/currency/currency.controller');
router.get('/currency/getcurrencyname', currencydata.getcurrencyname)

var custompagedata = require('./controllers/custompage/custompage.controller');

router.post('/custompage/addcustompage', custompagedata.addcustompage);
router.get('/custompage/getAllcustompage/:userId', custompagedata.getAllcustompage);
router.get('/custompage/getcustompagebyId/:custompageId', custompagedata.getcustompagebyId);
router.post('/custompage/updatecustompage', custompagedata.updatecustompage);
router.post('/custompage/updatetoggle', custompagedata.updatetoggle);
router.delete('/custompage/deletecustompage/:custompageId/:userId/:name', custompagedata.deletecustompage);



var siteappearancedata = require('./controllers/siteappearance/siteappearance.controller');

router.get('/siteappearance/getsiteappearance', siteappearancedata.getsiteappearance);
router.get('/siteappearance/getsiteappearancebyitsID/:siteappearanceDATA', siteappearancedata.getsiteappearancebyitsID);
router.post('/siteappearance/updatesiteappearance', siteappearancedata.updatesiteappearance);




var settingdata = require('./controllers/settings/settings.controller');

router.get('/settings/finikartusage/getAllUsage', settingdata.getAllusage);
router.delete('/settings/finikartusage/deleteusage/:id/:userId/:name', settingdata.deleteusage);
router.post('/settings/finikartusage/updatetoggle', settingdata.updatetoggle);
router.get('/settings/finikartusage/getUsagebyId/:UsageId', settingdata.getUsagebyId);
router.post('/settings/finikartusage/updateusage', settingdata.updateusage);


var dashboard = require('./controllers/dashboards/dashboard.controller')

router.get('/dashboard/getAllcountspackges/:userId', dashboard.getAllcountspackges);
router.get('/dashboard/getAllcountsdomainRequest/:userId', dashboard.getAllcountsdomainRequest);
router.get('/dashboard/getAllcountscompanies/:userId', dashboard.getAllcountscompanies);
router.get('/dashboard/getAllcountsResellers/:userId', dashboard.getAllcountsResellers);
router.get('/dashboard/getAllcountsUpdates/:userId', dashboard.getAllcountsUpdates);
router.get('/dashboard/getAllcountsProducts/:userId', dashboard.getAllcountsProducts);
router.get('/dashboard/getAllcountsSubscriber/:userId', dashboard.getAllcountsSubscriber);


var storetimings = require('./controllers/storetimings/storetimings.controller')

router.get('/storetiming/getmystoretiming/:companyid', storetimings.getmystoretiming);
router.post('/storetiming/updatestoretime', storetimings.updatestoretime);
router.get('/storetiming/getAllDatatiming/:userId', storetimings.getAllDatatiming);


var businesslogos = require('./controllers/businesslogos/businesslogos.controller')

router.post('/businesslogo/addagainbusinesslogo', businesslogos.addagainbusinesslogo);
router.get('/businesslogo/getallbusinesslogo/:userId', businesslogos.getallbusinesslogo);
router.post('/businesslogo/addBenerLogoMultiple', businesslogos.addBenerLogoMultiple);
router.post('/businesslogo/deleteBannerarray', businesslogos.deleteBannerarray);

var thirdpartyintergration = require('./controllers/thirdpartyintergration/thirdpartyintergration.controller')

router.post('/thirdpartyintergration/submitFacebookdetails', thirdpartyintergration.submitFacebookdetails);
router.get('/thirdpartyintergration/getDomainAndEmail/:userId', thirdpartyintergration.getDomainAndEmail);

module.exports = router;