require('rootpath')();
var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('./config.json');
var mongoose = require('mongoose');
var session = require('express-session');
var fs = require('fs');
var forceSsl = require('express-force-ssl');
const multer = require('multer');
var AWS = require('aws-sdk');
var sharp = require('sharp');
//var Jimp = require('jimp');
const path = require('path');
// const fs = require('fs');
const DIR = './uploads';
// var gm = require('gm');
gm = require('gm');
// var im = require('imagemagick');
//var storage = multer.memoryStorage();

// var mongodbUrl = 'mongodb://' + config.DB_User + ':' + encodeURIComponent(config.DB_Pass) + '@' + config.DB_HOST + ':' + config.DB_PORT + '/' + config.DB_NAME;
var mongodbUrl = 'mongodb://' + config.DB_HOST + ':' + config.DB_PORT + '/' + config.DB_NAME;
// Database options
// Option auto_reconnect is defaulted to true
var dbOptions = {
  server: {
    reconnectTries: -1, // always attempt to reconnect
    socketOptions: {
      keepAlive: 120
    }
  }
};

// Events on db connection
mongoose.connection.on('error', function (err) {
  console.error('MongoDB connection error. Please make sure MongoDB is running. -> ' + err);
});

mongoose.connection.on('disconnected', function () {
  console.error('MongoDB connection disconnected.')
});

mongoose.connection.on('reconnected', function () {
  console.error('MongoDB connection reconnected.')
});

// Connect to db
var connectWithRetry = function () {
  return mongoose.connect(mongodbUrl, dbOptions, function (err) {
    if (err) {
      console.error('Failed to connect to mongo on startup - retrying in 5 sec. -> ' + err);
      setTimeout(connectWithRetry, 5000);
    }
  });
};

connectWithRetry();
var http = require('https');
var https = require('https');
var options = {
  key: fs.readFileSync('./ssl/privkey.pem'),
  cert: fs.readFileSync('./ssl/fullchain.pem')
};
var app = express();
//app.use(forceSsl);
//var server = https.createServer(options,app).listen(3000);
var server = http.createServer(app);
//var io = ios.listen(server);
var routes = require('./routes');
//app.set('socketio', io);
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(session({ secret: 'secret', resave: 'false', saveUninitialized: 'false' }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
// Enable CORS
app.use(cors());

// Bootstrap routes


// Static files
app.use('/', express.static(__dirname + '/../public'));


// use JWT auth to secure the api, the token can be passed in the authorization header or querystring
app.use(expressJwt({
  secret: config.secret,
  getToken: function (req) {
    //console.log(req.headers.authorization);
    if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
      return req.headers.authorization.split(' ')[1];
    } else if (req.query && req.query.token) {
      return req.query.token;
    }
    return null;
  }
}).unless({
  path: ['/users/authenticate',
    '/password/passwordmatch',
    '/password/sendlink',
    '/password/resetpassword',
    '/siteappearance/getalltheme',
    '/contactUs/getFooterBusinessName',
    '/products/getReservedBusinessName',
    '/products/getallproducts',
    '/products/getlogos',
    '/products/getproduct',
    '/products/addquerydetail',
    '/products/getproductcategorieslist',
    '/products/getselectproductlist',
    '/products/getupdatesproductslist',
    '/products/getupdateproduct',
    '/products/getgallerylist',
    '/products/updateproductvalue',
    '/products/updateallproductvalue',
    '/products/gethomegallerylist',
    '/products/gethomeupdatesproductslist',
    '/products/gethomeselectproductlist',
    '/products/gethomeproductslist',
    '/contactUs/getAboutUsData',
    '/contactUs/addSubscriber',
    '/contactUs/addContactData',
    '/contactUs/getStoreTimingData',
    '/contactUs/getcustompagesdetail',
    '/products/gethomepagebanner',
    '/products/gethomepageagainproductslist',
    '/products/getagainupdatesproductslist',
    '/products/getagainproductlist'
    
  ]
}));


// Comment 1
// '/packages/getPackagebyId/:packageId', '/packages/updatepackage', '/packages/deletepackage/packageId/userId/name',
//'/resellers/addresellers', '/resellers/getAllresellers', '/resellers/getresellersbyId/:resellersId', '/resellers/updateresellers', '/resellers/deleteresellers/resellersId/userId/name',
//'/companies/addcompany', '/companies/getAllcompany', '/companies/getcompanybyId/:companyId', '/companies/updatecompany', '/companies/deletecompany/companyId/userId/name', '/users/getprofileInfo/:loginId', '/users/updateprofile',
//'/domains/adddomainrequest', '/domains/getAllDomainRequests', '/domains/getDomainRequestsbyId/:domainId', '/domains/updateDomainRequests', '/domains/deleteDomainRequests/domainId/userId/name',
//'/productcategories/addproductcategories', '/productcategories/getAllproductcategories', '/productcategories/getproductcategoriesbyId/:productcategoriesId', '/productcategories/updateproductcategories', '/productcategories/deleteproductcategories/productcategoriesId/userId/name',
//'/productgallery/addagaingallery', '/productgallery/addproductgallery', '/productgallery/updateproductgallery', '/productgallery/getproductgallerybyId/:productgalleryId', '/productgallery/deleteproductgallery/productgalleryId/userId/name',
//'/allupdates/addallupdates', '/allupdates/getAllallupdates', '/allupdates/deleteallupdates/allupdatesId/userId/name', '/allupdates/addagainallupdates',
// '/custompage/addcustompage', '/custompage/getAllcustompage', '/custompage/getcustompagebyId/:custompageId', '/custompage/updatecustompage', '/custompage/deletecustompage/custompageId/userId/name',
// '/photogallery/addphotogallery', '/photogallery/getAllphotogallery', '/photogallery/addagainphotpgallery',



// routes
app.use(routes);
app.use('/users', require('./controllers/Users/users.controller'));

app.use('/siteappearance', require('./controllers/theme/theme.controller'));
app.use('/products', require('./controllers/products/products.controller'));

app.use('/contactUs', require('./controllers/contactUs/contactUs.controller'));

// app.use('/contactUs' , require('./controllers/contactUs/contactUs.controller'));



// app.use('/resellers', require('./controllers/resellers/resellers.controller'));
// app.use('/companies', require('./controllers/companies/companies.controller'));
// app.use('/domains', require('./controllers/domains/domains.controller'));
// app.use('/productcategories', require('./controllers/productcategories/productcategories.controller'));
// app.use('/productgallery', require('./controllers/productgallery/productgallery.controller'));
// app.use('/allupdates', require('./controllers/allupdates/allupdates.controller'));

// app.use('/custompage', require('./controllers/custompage/custompage.controller'));

// app.use('/photogallery', require('./controllers/photogallery/photogallery.controller'));

app.use('/password', require('./controllers/password/password.controller'));
// app.use('/siteappearance', require('./controllers/siteappearance/siteappearance.controller'));

// app.use('/currency', require('./controllers/currency/currency.controller'));


// error handler
app.use(function (err, req, res, next) {
  console.log(err);
  if (err.name === 'UnauthorizedError') {
    res.status(401).send('Invalid Token');
  } else {
    throw err;
  }

});

// app.post('/addproductgallery', upload.any(), function (req, res)  {
//   console.log(req);
//   //console.log(req); // the uploaded file object
//   //res.json({'message': req.body.file});
// });


// //aws credentials
// AWS.config = new AWS.Config();
// AWS.config.accessKeyId = "AKIAJDASXIM5S7ELYWWQ";
// AWS.config.secretAccessKey = "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";
// AWS.config.region = "us-east-1";
// AWS.config.apiVersions = {
//   "s3": "2012-10-17"
// }



var storage = multer.diskStorage({
  // destination
  // destination: function (req, file, cb) {
  //   console.log(DIR);
  //   cb(null, DIR);
  // },
  // filename: function (req, file, cb) {
  //   cb(null, file.originalname);
  // }

});

var upload = multer({ storage: storage });

app.post('/uploadfiles', upload.any('uploads[]'), function (req, res) {
  var s3data = [];

  var uploadedfiles = req.files;
  var datetime = new Date(new Date).valueOf();
  var randomnumber = Math.floor((Math.random() * 100) + 1);

  //var i=0;
  for (let i = 0; i < uploadedfiles.length; i++) {
    var s3 = new AWS.S3();
    // console.log('req.body.uploadsagain');
    // console.log(req.body.uploads[i]);

    // console.log(dimensions.width, dimensions.height);

    if (req.body.uploads[i] == 0) {
      // console.log('flag0')
      var nodewidth = 400;
      var nodeheight = 400;
      sharp(uploadedfiles[i].path).jpeg({ compressionLevel: 9, adaptiveFiltering: true, force: true })
        .flatten(true)
        .background('white')
        .embed().
        resize(nodewidth, nodeheight).toBuffer(function (err, data) {

          var datetime = new Date(new Date).valueOf();
          var randomnumber = Math.floor((Math.random() * 100) + 1);


          var seperate = uploadedfiles[i].originalname;
          var sep = seperate.split(".");

          var params = {
            'Bucket': 'finikartbucket',
            'Key': 'finikartbucket/uploads/' + datetime + randomnumber + '.' + sep[1],
            'Body': data,
            'ContentEncoding': 'base64',
            ACL: 'public-read',
            Metadata: {
              'Content-Type': 'image/' + sep[1]
            }
          };

          s3.upload(params, function (err, resultdata) {
            if (err) {
              console.log(err);
            }
            else {

              s3data.push(resultdata.Location)
              // console.log(resultdata.Location)
              if (s3data.length == uploadedfiles.length) {
                res.send(s3data);
              }
            }
          })
        })
    } else if (req.body.uploads[i] == 1) {
      // console.log('flag1')
      var logowidth = 100;
      var logoheight = 100;
      sharp(uploadedfiles[i].path).jpeg({ compressionLevel: 9, adaptiveFiltering: true, force: true })
        .flatten(true)
        .background('white')
        .embed().
        resize(logowidth, logoheight).toBuffer(function (err, data) {
          var datetime = new Date(new Date).valueOf();
          var randomnumber = Math.floor((Math.random() * 100) + 1);


          var seperate = uploadedfiles[i].originalname;
          var sep = seperate.split(".");

          var params = {
            'Bucket': 'finikartbucket',
            'Key': 'finikartbucket/uploads/' + datetime + randomnumber + '.' + sep[1],
            'Body': data,
            'ContentEncoding': 'base64',
            ACL: 'public-read',
            Metadata: {
              'Content-Type': 'image/' + sep[1]
            }
          };

          s3.upload(params, function (err, resultdata) {
            if (err) {
              console.log(err);
            }
            else {

              s3data.push(resultdata.Location)
              // console.log(resultdata.Location)
              if (s3data.length == uploadedfiles.length) {
                res.send(s3data);
              }
            }
          })
        })
    } else {
      // console.log('flag2')
      var sizeOf = require('image-size');
      var dimensions = sizeOf(uploadedfiles[i].path);
      sharp(uploadedfiles[i].path).jpeg({ compressionLevel: 9, adaptiveFiltering: true, force: true })
        .flatten(true)
        .background('white')
        .embed().
        resize(dimensions.width, dimensions.height).toBuffer(function (err, data) {
          var datetime = new Date(new Date).valueOf();
          var randomnumber = Math.floor((Math.random() * 100) + 1);


          var seperate = uploadedfiles[i].originalname;
          var sep = seperate.split(".");

          var params = {
            'Bucket': 'finikartbucket',
            'Key': 'finikartbucket/uploads/' + datetime + randomnumber + '.' + sep[1],
            'Body': data,
            'ContentEncoding': 'base64',
            ACL: 'public-read',
            Metadata: {
              'Content-Type': 'image/' + sep[1]
            }
          };

          s3.upload(params, function (err, resultdata) {
            if (err) {
              console.log(err);
            }
            else {
              // console.log(resultdata.Location)
              s3data.push(resultdata.Location)

              if (s3data.length == uploadedfiles.length) {
                res.send(s3data);
              }
            }
          })
        })
    }

  }

});

app.post('/uploadcheckedfiles', upload.any('uploads[]'), function (req, res) {
  var s3data = [];

  var uploadedfiles = req.files;
  var datetime = new Date(new Date).valueOf();
  var randomnumber = Math.floor((Math.random() * 100) + 1);

  //var i=0;
  for (let i = 0; i < uploadedfiles.length; i++) {
    var s3 = new AWS.S3();

    sharp(uploadedfiles[i].path).jpeg({ compressionLevel: 9, adaptiveFiltering: true, force: true })
      .flatten(true)
      .background('white')
      .embed().
      resize(400, 400).toBuffer(function (err, data) {
        var datetime = new Date(new Date).valueOf();
        var randomnumber = Math.floor((Math.random() * 100) + 1);


        var seperate = uploadedfiles[i].originalname;
        var sep = seperate.split(".");

        var params = {
          'Bucket': 'finikartbucket',
          'Key': 'finikartbucket/uploads/' + datetime + randomnumber + '.' + sep[1],
          'Body': data,
          'ContentEncoding': 'base64',
          ACL: 'public-read',
          Metadata: {
            'Content-Type': 'image/' + sep[1]
          }
        };


        s3.upload(params, function (err, resultdata) {

          if (err) {
            console.log(err);
          }
          else {
            //console.log(req.body.uploads[i]);
            s3data.push({ 's3url': resultdata.Location, 'checkbox': req.body.uploads[i] });

            if (s3data.length == uploadedfiles.length) {
              //console.log(s3data);
              res.send(s3data);
            }
          }
        })
      })
  }


});

// var s3 = new AWS.S3();
// var bodystream = fs.createReadStream('uploads\\Hydrangeas.jpg');
// var params = {
//       'Bucket': 'finikartbucket',
//       'Key': 'finikartbucket/uploads/' + 'Hy.jpg',
//       'Body': bodystream,
//       'ContentEncoding': 'base64', 
//       ACL: 'public-read',
//       Metadata: {
//           'Content-Type': 'image/jpeg'
//       }

//    };

//    //also tried with s3.putObject
//    s3.upload(params, function(err, data){
//        if(err)
//        {

//            console.log(err);
//        }
//        else
//        {
//            console.log(data);
//        }
//       console.log('after s3 upload====', err, data);
//    }) 
// //console.log('files', req.files);
// res.send(req.files);



// start server
var port = process.env.NODE_ENV === 'production' ? 80 : 3000;
// Once database open, start server
mongoose.connection.once('open', function callback() {
  console.log('Connection with database succeeded.');

  var server = app.listen(port, function () {
    console.log('Server listening on port ' + port);
  });
});
